package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.util.Map;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;

/**
 * 
 * This class contains Common Data Persisting logic implementation
 * processing job.
 * 
 * @since 2023
 *
 */
public class CommonDataPersister {

	
	private CommonDataPersister() {}
    private static CommonLogger logger = new CommonLogger(CommonDataPersister.class);
    
    /**
  	 * 
  	 * This method provides  implementation of Txn data persisting logic
  	 * processing job.
  	 * @exception TechnicalException
  	 * 
  	 */
	public static void txnDataPersister(Map<String, String> errorMap, TransactionDTO transactionDTO , Connection connection) throws TechnicalException  {
		String traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "CommonDataPersister : txnDataPersister :Started");
		try {
			if(!errorMap.entrySet().isEmpty()) {
				//non processing transaction data will be processed here
				new TxnMerchantStatus(traceId, transactionDTO, connection);
				new TxnInterchangeStatus(traceId, transactionDTO, connection);
				TxnSettlementExc.add(transactionDTO, connection);
				for (Map.Entry<String, String> entry : errorMap.entrySet()) {
			        
			        TxnNonProcessable.add(transactionDTO, entry.getKey(), connection);
				}
				
			}
		}catch(Exception e) {
			logger.logError(traceId, "Error while persisting data at txnDataPersister: " + e.getLocalizedMessage());
            TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data at txnDataPersister: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		}
		
		
	}
}
