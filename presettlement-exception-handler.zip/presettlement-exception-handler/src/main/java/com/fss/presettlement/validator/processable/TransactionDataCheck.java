package com.fss.presettlement.validator.processable;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.BusinessException;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TrxMerchantStatusDTO;
import com.fss.presettlement.dto.TxnUniqueDataDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.persistence.TxnMerchantStatus;
import com.fss.presettlement.persistence.TxnUniqueData;

/**
 * 
 * This class contains the implementation of Transaction data check. 
 * @since 2023
 * @see <a href="https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/101711884/AMM+B0003+-+0002-0019+PG+Processable+exception+-+Master+Data+Transaction+Check">Confluence Page</a>
 * 
 */
public class TransactionDataCheck {

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TransactionDataCheck.class);
	
	/**
	 * 
	 * This method takes care of performing non processable refund request specific checks on incoming transactions data.
	 * @param TransactionDTO .
	 * @throws TechnicalException, JsonProcessingException, ValidationException, BusinessException, ParseException, SQLException 
	 * 
	 */ 
	public void validateTransactionDetails(Map<String, String> errorMap, TransactionDTO transactionDTO, Connection connection) throws TechnicalException, JsonProcessingException, ValidationException, BusinessException, ParseException, SQLException {
		logger.logInfo(traceId, "TransactionDataCheck: validateAndEnrichTransactionDetails: Started");
		
		validateTrxDate(errorMap, transactionDTO);
		validateOrgTrxStatus(errorMap, transactionDTO, connection);
	}
	
	
	
	/**
	 * 
	 * This method takes care of validating Trx Date.
	 * @param TransactionDTO, errorMap, connection.
	 * @throws ParseException 
	 * 
	 */ 
	private void validateTrxDate(Map<String, String> errorMap, TransactionDTO transactionDTO) throws ParseException {
		
		logger.logInfo(traceId, "TransactionDataCheck : validateTrxDate check:"+ Constants.ERR_MSG_PRERR000009);
		//BodDetailsExtractor.getCurrBusinessDate(transactionDTO.getData().getTenantCode());
		
		// Compare the two dates using the compareTo method
        // Returns a positive value if dateA is later than dateB
        // Returns 0 if the dates are equal
        // Returns a negative value if dateA is earlier than dateB
		if(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().compareTo( extractDate(transactionDTO.getData().getTranDatTim()))>0) {
			logger.logInfo(traceId, "TransactionDataCheck:"+ Constants.ERR_MSG_PRERR000009);
		    errorMap.put(Constants.PRERR000009, Constants.ERR_MSG_PRERR000009);
		}
		
	}
	
	/**
	 * 
	 * This method takes care of validating Orginal Trx Status.
	 * @param TransactionDTO, errorMap, connection.
	 * @throws TechnicalException, ValidationException, SQLException 
	 * 
	 */ 
	private void validateOrgTrxStatus(Map<String, String> errorMap, TransactionDTO transactionDTO,  Connection connection) throws TechnicalException, ValidationException, SQLException {
		
		logger.logInfo(traceId, "TransactionDataCheck : validateOrgTrxStatus check:"+ Constants.ERR_MSG_PRERR000013);
		String orgRrn = transactionDTO.getData().getBody().getStdFlds().getOrgRrn();
		String sid = transactionDTO.getData().getBody().getAddnlFlds().getStoreCode();
		String tenantCode = transactionDTO.getData().getBody().getDb().getTenantCode();
		String terminalId = transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId();
		
		if(applicableTxnType(transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode())) {
			
			TxnUniqueDataDTO originalTxnDto = TxnUniqueData.fetchOrgTxnData(terminalId,orgRrn, sid, tenantCode, connection);
			TrxMerchantStatusDTO trxMerchantStatusDTO = TxnMerchantStatus.getTxnMerchantStatusCode(originalTxnDto.getSettlementTxnKey(), transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(), connection);
			if(trxMerchantStatusDTO == null || trxMerchantStatusDTO.getTxnStatusCode() == null || trxMerchantStatusDTO.getTxnStatusCode().equalsIgnoreCase(Constants.TXN_STATUS_PROCESSABLE_EXCEPTION)) {
				errorMap.put(Constants.PRERR000013, Constants.ERR_MSG_PRERR000013);
				logger.logInfo(traceId, "TransactionDataCheck:validateOrgTrxStatus :failed due to"+ Constants.ERR_MSG_PRERR000013);
				
			}
		}
		
	}

	/**
	 * 
	 * This method takes care of extracting Date from String.
	 * @param inputDateTime .
	 * @return Date
	 * @throws ParseException 
	 * 
	 */ 
	public static Date extractDate(String inputDateTime) throws ParseException {
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // Parse the input string to Date
        return inputFormat.parse(inputDateTime);
    }
	
	/**
	 * 
	 * This method takes care of valdating applicable transaction types.
	 * @param txnType .
	 * @return boolean
	 * 
	 */ 
	private static boolean applicableTxnType(String txnType) {
		return txnType != null && (txnType.equalsIgnoreCase(Constants.REFUND_CODE)
	            || txnType.equalsIgnoreCase(Constants.PURCHASE_VOID_CODE)
	            || txnType.equalsIgnoreCase(Constants.REFUND_VOID_CODE)
	            || txnType.equalsIgnoreCase(Constants.PURCHASE_REVERSAL_CODE)
	            || txnType.equalsIgnoreCase(Constants.REFUND_REVERSAL_CODE));
	}
	
}
