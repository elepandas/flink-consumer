package com.fss.presettlement.persistence;

import java.net.InetSocketAddress;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.BoundStatement;
import com.datastax.oss.driver.api.core.cql.PreparedStatement;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;

public class MerchantTransaction {
	
	private static CommonLogger logger = new CommonLogger(MerchantTransaction.class);
	
	private MerchantTransaction() {
		
	}
	
	public static void add(String traceId, TransactionDTO transactionDTO, Connection connection) {
		logger.logInfo(traceId, "MerchantTransaction : add() - Entered.");
        try (CqlSession session = CqlSession.builder()
                .addContactPoint(new InetSocketAddress(Constants.CASSANDRA_IP_HOST, Constants.CASSANDRA_PORT_NUMBER))
                .withKeyspace(Constants.MERCHANT_TXN_KEYSPACE)
                .build()) {

            // Define the CQL statement for the insert
            String insertCql = "INSERT INTO " + Constants.MERCHANT_TXN_TABLE_NAME + " (merchant_id, store_id, terminal_id, txn_key, business_date, process_date, "
            		+ "txn_datetime, txn_currency_code, txn_amt, payment_channel_code, txn_type_code, payment_method_code, "
            		+ "acquiring_type_code, interchange_code, txn_trade_code, txn_response_code, capture_mode, delivery_channel_code, "
            		+ "rrn, settlement_currency_code, settlement_amt, mcc, issuer_country_code, issuer_currency_code, is_sms, is_dcc, "
            		+ "txn_status_code, interchange_status_code, fee_type, fee_currency_code, fee_amt, tax_type, tax_currency_code, tax_amt, tenant_code, dml_by, dml_type, dml_on) "
            		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = session.prepare(insertCql);

            BoundStatement boundStatement = preparedStatement.bind(transactionDTO.getData().getMerchantId(), 
            		transactionDTO.getData().getBody().getAddnlFlds().getStoreCode(),
            		transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId(),
            		transactionDTO.getSettlementTxnKey(),
            		transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate(),
            		String.valueOf(LocalDate.ofInstant(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().toInstant(), 
       					 ZoneId.systemDefault())),
            		transactionDTO.getData().getTranDatTim(),
            		transactionDTO.getData().getBody().getStdFlds().getTxnCrncyCode(),
            		transactionDTO.getData().getAmt(),
            		transactionDTO.getData().getBody().getAddnlFlds().getChannel(),
            		transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode(),
            		transactionDTO.getData().getBody().getTxnEnrData().getPaymentMethod(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinStoreOnusIndicator(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinInterchangeCode(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinDestinationCategory(),
            		transactionDTO.getData().getBody().getStdFlds().getResponseCode(),
            		transactionDTO.getData().getBody().getTxnEnrData().getTxnPOSEntryMdCaptureMode(),
            		transactionDTO.getData().getBody().getTxnEnrData().getDeliveryChannel(),
            		transactionDTO.getData().getBody().getStdFlds().getRrn(),
            		transactionDTO.getData().getBody().getTxnEnrData().getMerchantSettlementCurrency(),
            		transactionDTO.getData().getBody().getTxnEnrData().getSettlementAmount(),
            		transactionDTO.getData().getBody().getStdFlds().getMerchType(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinIssuerCountry(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinIssuerCurrency(),
            		transactionDTO.getData().getBody().getTxnEnrData().getBinSMSIndicator(),
            		"",
            		transactionDTO.getData().getBody().getTxnEnrData().getTxnMerchantStatusCode(),
            		"",
            		transactionDTO.getData().getBody().getTxnEnrData().getFeeType(),
            		transactionDTO.getData().getBody().getTxnEnrData().getFeeCurrency(),
            		transactionDTO.getData().getBody().getTxnEnrData().getFeeAmount(),
            		transactionDTO.getData().getBody().getTxnEnrData().getTaxType(),
            		transactionDTO.getData().getBody().getTxnEnrData().getTaxCurrency(),
            		transactionDTO.getData().getBody().getTxnEnrData().getTaxAmount(),
            		transactionDTO.getData().getTenantCode(),
            		transactionDTO.getData().getDmlBy(),
            		Constants.DML_TYPE,
            		new Date());

            // Execute the insert statement
            session.execute(boundStatement);

           logger.logInfo(traceId, "Data inserted successfully.");
           logger.logInfo(traceId, "MerchantTransaction : add() - Returned.");
        } catch (Exception e) {
            e.printStackTrace();
        }
		
	}

}
