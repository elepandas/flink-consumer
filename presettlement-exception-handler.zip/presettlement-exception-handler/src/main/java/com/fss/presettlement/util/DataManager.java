package com.fss.presettlement.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fss.platform.exception.type.TechnicalException;

/**
 * 
 * This class contains method implementations which basically takes care of data gathering it specified time interval  
 * which is required in processing the transaction data for presettlement.
 * @since 2023
 *
 */
public class DataManager {
	
	private DataManager() {}
	
    /**
   	 * 
   	 * This method provides logic implementation for fetching BOD details 
   	 * processing job.
   	 * @exception TechnicalException
   	 * 
   	 */
    private static String fetchCurrBusinessDate() throws TechnicalException {
    	
    	return BodDetailsExtractor.bODDetailsExtractor();
    }

    private static Map<String, String> fetchTxnSrcCode() {
        Map<String, String> txnSrcCode = new HashMap<>();
        txnSrcCode.put("TS001", "FSS_PG");
        txnSrcCode.put("TS002", "FSS_POS");
        txnSrcCode.put("TS003", "FSS_RTP");
        txnSrcCode.put("TS004", "Cybersource");
        txnSrcCode.put("TS005", "MPGS");
        return txnSrcCode;
    }

    private static List<String> fetchTxnTypeCode() {
        List<String> txnTypeCodeList = new ArrayList<>();
        txnTypeCodeList.add("TT002");
        return txnTypeCodeList;
    }

    private static List<String> fetchTenantCode() {
        List<String> tenCode = new ArrayList<>();
        tenCode.add("HDF");
        tenCode.add("HDF1");
        tenCode.add("HDF2");
        tenCode.add("HDF3");// institution_code
        return tenCode;
    }

    public static String getCurrBusinessDate() throws TechnicalException {
        return fetchCurrBusinessDate();
    }

    public static Map<String, String> getTxnSrcCode() {
        return fetchTxnSrcCode();
    }

    public static List<String> getTxnTypeCodex() {
        return fetchTxnTypeCode();
    }

    public static List<String> getTenantCode() {
        return fetchTenantCode();
    }
}
