package com.fss.presettlement.util;

import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;

import redis.clients.jedis.Jedis;

public class CacheService {
	
	private CacheService() {
		
	}
	
	public static Jedis getJedis(String rawtrx, String traceId) throws TechnicalException {
		try(Jedis jedis = new Jedis(Constants.REDIS_HOST, Constants.REDIS_PORT)) {
			return jedis;
		} catch (Exception e) {
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(rawtrx));
	    	techenicalExceptionDTO.setTransactionRecord(rawtrx);
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while getting JEDIS connection: "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		}
	}
	
	public static String deleteFromCache(String key, String rawtrx, String traceId) throws TechnicalException {
		Jedis jedis = getJedis(rawtrx, traceId);
		jedis.del(key);
		return "Data cleared successfully from cache.";
	}
	
	
	public static Object getFromCache(String key, String rawtrx, String traceId) throws TechnicalException {
		Jedis jedis = getJedis(rawtrx, traceId);
		return jedis.get(key);
	}
	
	public static String saveIntoCache(String key, String value, String rawtrx, String traceId) throws TechnicalException {
		Jedis jedis = getJedis(rawtrx, traceId);
		jedis.set(key, value);
		return "Data successfully saved into cache.";
	}
	public static void closeCacheSession(Jedis jedis)  {
		if(jedis != null) {
			jedis.close();
		}
	}

}
