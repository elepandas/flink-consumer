package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Vip private user fields
 * @since 2023
 *
 */
@Getter
@Setter
public class VipPrivUseFld{
    private String rvslCode;
    private String stip;
    private String feePrgmInd;
}
