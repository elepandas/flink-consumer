package com.fss.presettlement.util;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.kafka.clients.consumer.OffsetResetStrategy;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;

public class KafkaSourceFactory {
	
	private KafkaSourceFactory() {}
	
	/*****************************************************************************************************
	 *  Kafka source configuration: we need to specify the kafka topic name,
	 *  host details and group id in kafka source configuration so that
	 *  we can obtain the incoming data stream and also we can specify the offset commit strategies as per our
	 *  requirement, we are using Earliest as offset resett strategy which will get used wile extracting
	 *  the packages from kafka topic
	 *****************************************************************************************************/
    private static String traceId = Constants.EMPTY_STR;
    private static CommonLogger logger = new CommonLogger(KafkaSourceFactory.class);
	
    //TODO conver as factory by name
	public static KafkaSource<String> getKafkaSource(String kafkaHost, String topicName, String groupId) throws TechnicalException{
		
		KafkaSource<String> ks = null;
		
		try {
		ks = KafkaSource.<String>builder()
		        .setBootstrapServers(kafkaHost)
		        .setTopics(topicName)
		        .setGroupId(groupId)
		        .setStartingOffsets(OffsetsInitializer.committedOffsets(OffsetResetStrategy.EARLIEST)) // Using committedOffsets strategy
		        .setValueOnlyDeserializer(new SimpleStringSchema())
		        .build();
		}catch (Exception e) {
		    logger.logError(traceId, "Error in getKafkaSource: " + e.getMessage());
		    TxnExceptionlogger.techErrTransactions(kafkaHost + Constants.ERROR_MSG_SEPERATER +  e.getMessage());
		    throw new TechnicalException("Error in getKafkaSource: " + e.getMessage());
		
		}
		return ks;

	}
}
