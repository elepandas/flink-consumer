package com.fss.presettlement.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AggregationSameMerchantLocationSameAmountDto {
	
	private long storeTxndateCardCntId;
	private String merchantId;
	private String storeId;
	private String terminalId;
	private LocalDate txnDate;
	private String encryptCardNo;
	private String hashKey;
	private String txnCurrency;
	private double txnAmt;
	private double noOfSwipes;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;

}
