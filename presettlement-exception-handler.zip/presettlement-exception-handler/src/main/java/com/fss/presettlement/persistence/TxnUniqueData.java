package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TxnUniqueDataDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.AESEncryptionDecryption;
import com.fss.presettlement.util.CardHashing;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnUniqueData {
	
	private TxnUniqueData() {}
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnUniqueData.class);

	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on txn_unique_data table 
	 * @param transactionDTO
	 * @exception Exception 
	 */
	public static String txnPersister(TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
	    logger.logInfo(traceId, "TxnUniqueData: txnPersister: Started");
	    String status = Constants.SUCCESS;
	    PreparedStatement preparedStatement = null;
	    
	    try {
	        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
	        // Get the current date and time
	        Date currentDate = new Date();
	        // Format the date and time to the desired format
	        String formattedDate = dateFormat.format(currentDate);

	        String sql = "INSERT INTO txn_unique_data " +
	                     "(settlement_txn_key, process_date, business_date, pg_payment_id, store_id, " +
	                     "terminal_id, txn_source_code, rrn, stan, processing_code, " +
	                     "hash_card_no, txn_date, txn_time, txn_amt, hash_key, " +
	                     "tenant_code, dml_type, dml_by, dml_on) " +
	                     "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	        preparedStatement = connection.prepareStatement(sql);
	        preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());
	        preparedStatement.setString(2, formattedDate);
	        preparedStatement.setString(3, formattedDate);

	        preparedStatement.setString(4, transactionDTO.getData().getBody().getAddnlFlds().getPgPmntId());
	        preparedStatement.setString(5, transactionDTO.getData().getBody().getAddnlFlds().getStoreCode());
	        preparedStatement.setString(6, transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId());
	        preparedStatement.setString(7, transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc());
	        preparedStatement.setString(8, transactionDTO.getData().getBody().getStdFlds().getRrn());
	        preparedStatement.setString(9, transactionDTO.getData().getBody().getStdFlds().getStan());
	        preparedStatement.setString(10, transactionDTO.getData().getBody().getStdFlds().getProcCode());

	        preparedStatement.setString(11, getHashValue(getDecryptedPan(transactionDTO.getData().getPan())));
	        preparedStatement.setString(12, transactionDTO.getData().getTranDatTim());

	        preparedStatement.setString(14, transactionDTO.getData().getBody().getStdFlds().getTxnAmt());

	        preparedStatement.setString(16, transactionDTO.getData().getBody().getDb().getTenantCode());
	        preparedStatement.setString(17, Constants.DML_TYPE);
	        preparedStatement.setString(18, Constants.DML_BY);
	        preparedStatement.setString(19, formattedDate);

	        try {
	            preparedStatement.setString(13, timeExtractor(transactionDTO));
	            preparedStatement.setString(15, getTxnHashKey(transactionDTO));
	        } catch (TechnicalException e) {
	            e.printStackTrace();
	        }

	        int rowsInserted = preparedStatement.executeUpdate();

	        if (rowsInserted > 0) {
	            logger.logInfo(traceId, "Data inserted successfully.");
	        } else {
	            logger.logError(traceId, "Failed to insert data into txn_unique_data.");
	            status = Constants.FAILED;
	        }

	    } catch (SQLException e) {
	        // Handle SQL exception
	        if (e instanceof SQLIntegrityConstraintViolationException) {
	            logger.logError(traceId, "SQL Integrity Constraint Violation Exception occurred: " + e.getMessage());
	            // Perform specific logic based on the unique constraint violation
	            if (e.getMessage().contains("Duplicate entry")) {
	                status = Constants.FAILED;
	            }
	        } else {
	            logger.logError(traceId, "SQL Exception occurred at txnPersister: " + e.getLocalizedMessage(), e);
	        }
	    } catch (Exception ex) {
	        // Handle other exceptions here
	        logger.logError(traceId, "Exception occurred at txnPersister: " + ex.getLocalizedMessage(), ex);
	       
	        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting trx unique data at txnPersister: " + ex.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
	    
	    
	    } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }

	    return status;
	}

	/**
	 * 
	 * This method contains the implementation of getting the hash key 
	 * @param transactionDTO
	 * @return String (hash key of passed properties)
	 * @throws TechnicalException 
	 */
	private static String getTxnHashKey(TransactionDTO transactionDTO) throws TechnicalException {
		
		logger.logInfo(traceId, "TxnUniqueData: getTxnHashKey:Started");
		String inputString = null;
		try {
		inputString = transactionDTO.getData().getBody().getAddnlFlds().getChannel()+
				transactionDTO.getData().getBody().getAddnlFlds().getStoreCode()+
				transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId()+
				transactionDTO.getData().getBody().getAddnlFlds().getUrn()+
				transactionDTO.getData().getBody().getStdFlds().getCrdSeqNum()+
				transactionDTO.getData().getTranDatTim()+
				transactionDTO.getData().getBody().getAddnlFlds().getActionCode()+
				transactionDTO.getData().getBody().getStdFlds().getTxnAmt();
		
		}catch (Exception ex) {
	        // Handle other exceptions here
	        logger.logError(traceId, "Exception occurred: " + ex.getMessage(), ex);
	    
	        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting trx uniq data: " + ex.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		
		}
		return getHashValue(inputString);
	}
	
	/**
	 * 
	 * This method contains the implementation of time Extractor from passed data and time property
	 * @param transactionDTO
	 * @return String time
	 * @throws TechnicalException 
	 */
	private static String timeExtractor(TransactionDTO transactionDTO) throws TechnicalException {
		 String time = "";
		try {
	        String tranDatTim = transactionDTO.getData().getTranDatTim();
	        // Split the date-time string by space
	        String[] parts = tranDatTim.split(" ");
	
	        if (parts.length == 2) {
	            // The second part contains the time
	        	time = parts[1];
	        }
	        
			}catch (Exception ex) {
		        // Handle other exceptions here
		        logger.logError(traceId, "Exception occurred: " + ex.getMessage(), ex);
		      
		        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("Error while persisting trx uniq data: " + ex.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
			
			}
        return time;
    }

	/**
	 * 
	 * This method contains the implementation of jdbc operations on txn_unique_data table 
	 * @param terminalId, orgRrn, sid, tenantCode
	 * @exception SQLException 
	 * @throws ValidationException 
	 */
    public static TxnUniqueDataDTO fetchOrgTxnData(String terminalId, String orgRrn, String sid, String tenantCode, Connection connection) throws SQLException, ValidationException {
    	
    	logger.logInfo(traceId, "TxnUniqueData: fetchOrgTxnData:Started");
    	
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establish a JDBC connection.

            String sqlQuery = "SELECT txn_unique_data_id, settlement_txn_key FROM txn_unique_data WHERE terminal_id = ? AND store_id = ? AND rrn = ? AND tenant_code = ?";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, terminalId);
            preparedStatement.setString(2, sid);
            preparedStatement.setString(3, orgRrn);
            preparedStatement.setString(4, tenantCode);

            // Execute the query.
            resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
                // Populate a TxnUniqueDataDTO object with the retrieved data.
                TxnUniqueDataDTO txnUniqueDataDTO = new TxnUniqueDataDTO();
                txnUniqueDataDTO.setTxnUniqueDataId(resultSet.getLong("txn_unique_data_id"));
                txnUniqueDataDTO.setSettlementTxnKey(resultSet.getString("settlement_txn_key"));
                return txnUniqueDataDTO;
            } else {
                return null;
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while fetchOrgTxnData: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(orgRrn + Constants.ERROR_MSG_SEPERATER+ sid+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in fetchOrgTxnData: " + e.getMessage());
        } finally {
            // Close database resources.
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
        }
    }
	/**
	 * 
	 * This method contains the implementation of getting Decrypted pan
	 * @param pan (string)
	 * @return String decrepted pan
	 */
	private static String getDecryptedPan(String pan) {
		
		return AESEncryptionDecryption.decryptAES256Safe(pan, Constants.SECRET_KEY);
		
    }
	
	
	/**
	 * 
	 * This method contains the implementation of getting hash value of passed decrypted pan
	 * @param decrepted pan (string)
	 * @return String (hash value of pan)
	 */
	private static String getHashValue(String pan) {
		
		return CardHashing.getHashValue(pan);
		
    }
	
	/**
	 * 
	 * This method provides the implementation to update refund_amt in txn_unique_data table by
	 * accepting traceId, transactionDTO, connection and txnUniqueDataDTO as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @param txnUniqueDataDTO
	 * @return response message
	 * @throws TechnicalException
	 * 
	 */
	public static void updateRefundAmnt(String traceId, TransactionDTO transactionDTO, Connection connection, TxnUniqueDataDTO txnUniqueDataDTO) throws TechnicalException {
		logger.logInfo(traceId, "TxnUniqueData : updateRefundAmnt() - Entered.");
		PreparedStatement preparedStatement = null;
		try {
			//update query
			String query = "update txn_unique_data set refund_amt = ? where settlement_txn_key = ?";
			
			//set query params data to prepared statment object
			preparedStatement = connection.prepareStatement(query);     
            preparedStatement.setString(1, transactionDTO.getData().getBody().getTxnEnrData().getRefundedAmount());
            preparedStatement.setString(2, txnUniqueDataDTO.getSettlementTxnKey());
			
            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                logger.logInfo(traceId, "Data updated successfully.");
            } else {
            	logger.logError(traceId, "Failed to update data refund_amt in txn_unique_data table.");

		        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("Failed to update data refund_amt in txn_unique_data table.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
            
            }
            logger.logInfo(traceId, "TxnUniqueData : updateRefundAmnt() - Returned.");
		} catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		} finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
	}
	
	
	/**
	 * 
	 * This method provides the implementation to fetch txn_unique_data_id from the database by
	 * accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @return TxnUniqueDataDTO
	 * @throws TechnicalException
	 * 
	 */
	public static TxnUniqueDataDTO getTxnUniqueData(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnUniqueData : getTxnUniqueData() - Entered.");
		PreparedStatement preparedStatement = null;
		TxnUniqueDataDTO txnUniqueDataDTO = new TxnUniqueDataDTO();
		try {
			//select query
			String query = "select txn_unique_data_id, settlement_txn_key from txn_unique_data where store_id = ?"
					+ " and terminal_id = ? and rrn = ? and processing_code = ?";
			//set query params data to prepared statment object
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, transactionDTO.getData().getBody().getAddnlFlds().getStoreCode());
			preparedStatement.setString(2, transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId());
			preparedStatement.setString(3, transactionDTO.getData().getBody().getStdFlds().getRrn());
			preparedStatement.setString(4, Constants.PURCHASE_TRANSACTION_CODE);
			
			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();
			
			// Check if a record is found.
			if (resultSet.next()) {
				txnUniqueDataDTO.setTxnUniqueDataId(resultSet.getLong("txn_unique_data_id"));
				txnUniqueDataDTO.setSettlementTxnKey(resultSet.getString("settlement_txn_key"));
				logger.logInfo(traceId, "TxnUniqueData : getTxnUniqueData() - Returned.");
				return txnUniqueDataDTO;
			} else {
				logger.logError(traceId, "No data found in the txn_unique_data table.");
				
				TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("No data found in the txn_unique_data table.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
			}
		} catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());

			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		} finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
		
	}
	
	
	
	
}
