package com.fss.presettlement.dto;

import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of body fields
 * @since 2023
 *
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Body {

    @JsonProperty("StdFlds")
    private StdFlds stdFlds;
    @JsonProperty("DB")
    private DB db;
    @JsonProperty("AddnlFlds")
    private AddnlFlds addnlFlds;

}
