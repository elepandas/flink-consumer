package com.fss.presettlement.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction Engine log fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnEngineLog {

    private String pgPmntId;
    private String merchTrackId;
    private String discrim;
    private String tranDatTim;
    private String amt;
    private String pan;
    private String merchantId;
    private String paymentCode;
    private String subChannel;
    private String subChannelRequestId;
    private String tenantCode;
    private String dmlBy;
    private MessageBody body;
    private String pgTxnID;
    private String currency;
    @JsonProperty("sub_channel_txn_reference")
    private String subChannelTxnReference;
    @JsonProperty("sub_channel_txn_category")
    private String subChannelTxnCategory;
    

}
