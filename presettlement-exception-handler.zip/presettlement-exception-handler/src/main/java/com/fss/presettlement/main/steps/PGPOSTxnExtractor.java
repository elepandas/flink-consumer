package com.fss.presettlement.main.steps;

import java.io.IOException;
import java.sql.Connection;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.exception.handlers.FormatException;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PresettlementExceptionPersister;

/**
 * 
 * This class contains PG/POS Txn Extractor logic implementation
 * processing job.
 * @see <a https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3285455/AMM+B0003+-+0002-0001+Transaction+Extraction+of+PG">Confluence Page</a>
 * @since 2023
 *
 */
public class PGPOSTxnExtractor {
	
	private PGPOSTxnExtractor() {}
	
    private static String traceId = Constants.EMPTY_STR;
    private static CommonLogger logger = new CommonLogger(PGPOSTxnExtractor.class);
	
    /**
	 * 
	 * This method provides logic implementation of Txn Extractor and data persisting part
	 * processing job.
	 * @exception TechnicalException
     * @throws com.fss.presettlement.exception.handlers.TechnicalException 
     * @throws FormatException 
	 * 
	 */
	
	public static void txnExtractorProcess(String rawTrx, Connection connection) throws TechnicalException, IOException, ValidationException, FormatException, com.fss.presettlement.exception.handlers.TechnicalException {
		
		logger.logInfo(traceId, "PGPOSTxnExtractor txnExtractorProcess:Started");
		
		try {
		
		//this step will handle the parsing of incoming trx data to respective dto object and persist the data to respective table
		PresettlementExceptionPersister.trxParser(rawTrx, connection);
		
		
		}catch (Exception e) {
		e.fillInStackTrace();
	    logger.logError(traceId, "Error at OLTPTransactionsExtractor and error message is: " + e.getMessage());
		
		}
			
	}

}
