package com.fss.presettlement.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnSettlementRiskDto {
	
	private long txnSettlementRiskId;
	private long txnSettlementId;
	private String settlementTxnKey;
	private LocalDate holdDate;
	private LocalDate suspectDate;
	private LocalDate suspenseDate;
	private LocalDate releaseDate;
	private String holdBy;
	private String suspectBy;
	private String suspenseBy;
	private String releaseBy;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;
	
}
