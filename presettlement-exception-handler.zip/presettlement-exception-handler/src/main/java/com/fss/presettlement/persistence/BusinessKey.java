package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;

/**
 * 
 * This class contains method which perform data base operation on business_key table.
 * @author ramcharanr
 *
 */
public class BusinessKey {
	
	private static CommonLogger logger = new CommonLogger(BusinessKey.class);
	
	private BusinessKey() {
		
	}
	
	/**
	 * 
	 * This method fetch sequence no from database by accepting traceId, keyName and tenantCode as input
	 * parameters.
	 * @param keyName
	 * @param tenantCode
	 * @return SequenceNo
	 * @throws TechnicalException
	 * @throws SQLException
	 * 
	 */
	public static String getSequenceNo(String traceId, String keyName, String tenantCode, Connection connection, TransactionDTO transactionDTO) throws TechnicalException, SQLException {
		PreparedStatement preparedStatement = null;
		logger.logInfo(traceId, "BusinessKey : getSequenceNo() - Entered.");
		try {
			if(keyName != null && !keyName.isEmpty() && tenantCode != null && !tenantCode.isEmpty()) {
				String query = "select sequence from business_key where key_name = ? and tenant_code = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, keyName);
				preparedStatement.setString(2, tenantCode);
				ResultSet resultSet = preparedStatement.executeQuery();
				if(resultSet.next()) {
					logger.logInfo(traceId, "BusinessKey : getSequenceNo() - Returned.");
					return resultSet.getString("sequence");
				} else {
					logger.logError(traceId, "Error while fetching sequence from business_key table.");
					
					TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
			    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
			    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
			    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
			    	throw new TechnicalException("Error while fetching sequence from business_key table.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
						
				}
			} else {
				logger.logError(traceId, "keyName/tenantCode is null/empty.");
				
				TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("keyName/tenantCode is null/empty.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
				
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while fetching sequence_no from database: "+e.getLocalizedMessage());
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while fetching sequence_no from database:  "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		
		} finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
	}
	
	/**
	 * 
	 * This method update the sequence no in the database by accepting traceId, sequenceNo, keyName and tenantCode
	 * as input parameter.
	 * @param traceId
	 * @param sequenceNo
	 * @param keyName
	 * @param tenantCode
	 * @return message
	 * @throws SQLException
	 * @throws TechnicalException
	 * 
	 */
	public static String updateSequenceNo(String traceId, String sequenceNo, String keyName, String tenantCode, Connection connection, TransactionDTO transactionDTO) throws SQLException, TechnicalException {
		PreparedStatement preparedStatement = null;
		try {
			if(null != sequenceNo && !sequenceNo.isEmpty() && keyName != null && !keyName.isEmpty() && 
					tenantCode != null && !tenantCode.isEmpty()) {
				logger.logInfo(traceId, "BusinessKey : updateSequenceNo() - Entered.");
				String query = "update business_key set sequence = ? where key_name = ? and tenant_code = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, sequenceNo);
				preparedStatement.setString(2, keyName);
				preparedStatement.setString(3, tenantCode);
				
				int rowsUpdated = preparedStatement.executeUpdate();
				if (rowsUpdated > 0) {
					logger.logInfo(traceId, "BusinessKey : updateSequenceNo() - Returned.");
					return "Data updated successfully.";
				} else {
					logger.logInfo(traceId, "BusinessKey : updateSequenceNo() - Returned.");
					return "Failed to update data in txn_settlement_exc.";
				}
			} else {
				logger.logError(traceId, "sequenceNo/keyName/tenantCode is null/empty.");
				
				TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("sequenceNo/keyName/tenantCode is null/empty.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while updating sequence_no into database: "+e.getLocalizedMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while updating sequence_no into database: "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		} finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
	}

}
