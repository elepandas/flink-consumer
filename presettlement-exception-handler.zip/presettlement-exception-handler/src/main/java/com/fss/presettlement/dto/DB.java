package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;
/**
 * 
 * This is a DTO class which holds the property details DB details fields
 * @since 2023
 *
 */
@Getter
@Setter
public class DB{
    private String merchID;
    private String merchBusinessName;
    private String merchWebURL;
    private String merchAddr1;
    private String merchPostalCode;
    private String merchCity;
    private String merchState;
    private String merchCntry;
    private String merchMobileNo;
    private String merchEmailID;
    private String merchCrncyCde;
    private String merchCntryCde;
    private String merchEnableEMI;
    private String merchBusinessAddr;
    private String paymentInstrument;
    private String interchangeID;
    private String transactionMode;
    private String payeeVPA;
    private String payeeName;
    private String tenantCode;
}
