package com.fss.presettlement.dto;


import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction non-processable data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TerminalPaymentMethodDTO {

	private Long terminalUid;
    private String terminalPaymentMethodId;
    private String paymentMethodCode;
}
