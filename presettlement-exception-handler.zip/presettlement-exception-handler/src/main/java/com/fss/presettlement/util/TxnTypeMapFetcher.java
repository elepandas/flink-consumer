package com.fss.presettlement.util;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import java.sql.*;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.persistence.TxnTypeMap;

/**
 * 
 * This class contains the logic to fetch txn type code from cache or database
 * @since 2023
 *
 */
public class TxnTypeMapFetcher {
	
	private TxnTypeMapFetcher() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnTypeMapFetcher.class);
	
	/**
	 * 
	 * This method contains the logic to fetch transaction type code from cache or tan_type_map table
	 * @param processingCode, txnSourceCode, connection
	 * @throws SQLException,TechnicalException 
	 */
	public static String fetchTxnTypeCode(String processingCode, String txnSourceCode, Connection connection) throws SQLException, TechnicalException {
		logger.logInfo(traceId, "TxnTypeMapFetcher: fetchTxnTypeCode: Started");
		try (Jedis jedis = new Jedis(Constants.REDIS_HOST, Constants.REDIS_PORT)) {
			// Check if the record is in the cache
			String cacheKey = buildCacheKey(processingCode, txnSourceCode);
			if (Boolean.TRUE.equals(jedis.exists(cacheKey))) {
				// If present in cache, retrieve and return from cache
				return jedis.get(cacheKey);
			} else {
				try {
					// If not in cache, fetch from the database and store in cache
					String txnTypeCode = fetchTxnTypeCodeFromDatabase(processingCode, txnSourceCode, connection);

					if (txnTypeCode != null) {
						// Store in cache
						jedis.set(cacheKey, txnTypeCode);
					}

					return txnTypeCode;
				} catch (JedisConnectionException e) {
					 logger.logError(traceId, "Failed to connect to Redis at getTxnTypeCode: " + e.getLocalizedMessage());
					// You can choose to throw a custom exception or return a default value
					throw new TechnicalException("Failed to connect to Redis", e);
				}
			}
		}
	}

	/**
	 * 
	 * This method contains the logic to fetch transaction type code 
	 * @param processingCode, txnSourceCode, connection
	 * @throws SQLException,TechnicalException 
	 */
    private static String fetchTxnTypeCodeFromDatabase(String processingCode, String txnSourceCode, Connection connection) throws SQLException, TechnicalException {
    	logger.logInfo(traceId, "TxnTypeMapFetcher: fetchTxnTypeCodeFromDatabase: Started");
    	return TxnTypeMap.getTxnTypeCode(processingCode, txnSourceCode, connection);
    }

    /**
	 * 
	 * This method get us the cache key 
	 * @param processingCode, txnSourceCode
	 */
    private static String buildCacheKey(String processingCode, String txnSourceCode) {
    	logger.logInfo(traceId, "TxnTypeMapFetcher: buildCacheKey: Started");
        return Constants.REDIS_KEY_PREFIX + processingCode + Constants.REDIS_KEY_SEPERATER + txnSourceCode;
    }
}
