package com.fss.presettlement.dto;

import com.fss.presettlement.dto.AggregationSameMerchantLocationSameAmountDto;
import com.fss.presettlement.dto.AggregationSameMerchantLocationDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SettlementRiskRuleInput {
	
	private TransactionRuleDto transaction;
	private AggregationSameMerchantLocationDto aggregationSameMerchantLocation;
	private AggregationSameMerchantLocationSameAmountDto aggregationSameMerchantLocationSameAmount;

}
