package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of De60 fields
 * @since 2023
 *
 */
@Getter
@Setter
public class De60 {
    private String rvslCode;
}
