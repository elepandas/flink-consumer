package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.RaIrdTraceLogDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class RaIrdTraceLog {

	private RaIrdTraceLog() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(RaIrdTraceLog.class);

	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	

    /**
  	 * 
  	 * This class contains environment executer jdbc operations on ra_ird_trace_log table 
  	 * @param RaIrdTraceLogDTO, Connection
  	 * @exception TechnicalException 
  	 */
      public static void add(RaIrdTraceLogDTO raIrdTraceLogDTO, Connection connection) throws TechnicalException {
		    logger.logInfo(traceId, "TxnUniqueData: txnPersister: Started");
	
			PreparedStatement preparedStatement = null;
			
			try {
			    String sql = "INSERT INTO ra_ird_trace_log (settlement_txn_key, interchange_code, ra_ird, trace_log, tenant_code,dml_type,dml_by,dml_on )" +
			 "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			    
			    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
			    Date currentDate = new Date();
			    String formattedDate = dateFormat.format(currentDate);
			    
			    preparedStatement = connection.prepareStatement(sql);
			    preparedStatement.setString(1, raIrdTraceLogDTO.getSettlementTxnKey());
			    preparedStatement.setString(2, raIrdTraceLogDTO.getInterchangeCode());
			    preparedStatement.setString(3, raIrdTraceLogDTO.getRaIrd());
			    preparedStatement.setString(4, raIrdTraceLogDTO.getTraceLog());
			    preparedStatement.setString(5, raIrdTraceLogDTO.getTenantCode());
			    preparedStatement.setString(6, Constants.DML_TYPE);
			    preparedStatement.setString(7, Constants.DML_BY); 
			    preparedStatement.setString(8, formattedDate);
			
			    preparedStatement.executeUpdate();
			    
			} catch (Exception ex) {
			    logger.logError(traceId, "Exception occurred: " + ex.getLocalizedMessage(), ex);
			TxnExceptionlogger.techErrTransactions(raIrdTraceLogDTO.getSettlementTxnKey() + Constants.ERROR_MSG_SEPERATER + raIrdTraceLogDTO.getRaIrd() + Constants.ERROR_MSG_SEPERATER + ex.getLocalizedMessage());
			throw new TechnicalException("Error while persisting txn interchange status: " + ex.getLocalizedMessage());
			
			} finally {
			    if (preparedStatement != null) {
			        try {
			            preparedStatement.close();
			        } catch (SQLException e) {
			        	TxnExceptionlogger.techErrTransactions(raIrdTraceLogDTO.getSettlementTxnKey() + Constants.ERROR_MSG_SEPERATER + raIrdTraceLogDTO.getRaIrd() + Constants.ERROR_MSG_SEPERATER + e.getLocalizedMessage());
			        }
			    }
			}
		}
   	
}
