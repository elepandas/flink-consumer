package com.fss.presettlement.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnSettlementRiskReasonDto {
	
	private long txnSettlementRiskReasonId;
	private long txnSettlementRiskId;
	private LocalDate processDate;
	private LocalDate businessDate;
	private String settlementTxnKey;
	private String settlementRiskCode;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;

}
