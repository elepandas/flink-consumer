package com.fss.presettlement.constants;

public class Constants {

	private Constants() {

	}
	
	//DB Config
	public static final String DB_HOST = "jdbc:mysql://localhost:3306/dev_acq_txn";
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_USR_NAME = "root";
	public static final String DB_PASS = "password";
	
	public static final int DB_BATCH_SIZE = 1000;
	public static final int DB_INTERVAL_MS = 200;
	public static final int DB_MAX_RETRY = 5;
	
	

	//secret key for encryption and decryption
	public static final String SECRET_KEY = "12345554453453346365267521612522";
	
	public static final String SUCCESS = "SUCCESS";
	public static final String STR = "";
	public static final String EMPTY_STR = "";
	public static final String FAILED = "FAILED";
	public static final String ERROR_MESSAGE = "ERROR MESSAGE:";
	public static final String DATE_FORMAT_1 = "yyyy-MM-dd";
	public static final String FOLDER_NAME = "logs/";
	public static final String FILE_NAME_1 = "non_parsed_transactions.log";
	public static final String FILE_NAME_2 = "parsed_transactions.log";
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSSS";
	
	public static final String DML_TYPE = "I";
	public static final String DML_BY = "SYSTEM_USER";
	
	// kafka properties
	public static final String KAFKA_SETTLEMENT_TXN_HOST = "kafka-ext-nlb-sit-08f85bcb45235657.elb.us-east-1.amazonaws.com:9092";
	public static final String KAFKA_TOPIC_NAME = "SitTranLog";
	public static final String KAFKA_PE_TOPIC_NAME = "SitTranLog";
	public static final String KAFKA_GROUP_ID = "flink_consumer";
	public static final String KAFKA_DATA_SOURCE_NAME = "kafka trx data source";
	public static final String ERROR_MSG_SEPERATER = " || ";
	public static final String PROCESSABLE_TOPIC_NAME = "ACQ-SETTLE-PROCESSABLE-EXCE";
	public static final String PROCESSABLE_GROUP_ID = "processable_consumer";
	public static final String KEY_SERIALIZER = "org.apache.kafka.common.serialization.StringSerializer";
	public static final String KAFKA_EXCEPTION_TOPIC_NAME = "PresettlementExceptions" ;
	
	//trx schema
	public static final String TRX_SCHEMA_FILE_PATH = "schema/txnJsonSchemaTemplate.json";
	public static final String TRX_PROCESSABLE_SCHEMA_FILE_PATH = "schema/be/schema/processableTxnSettlementExcSchema.json";
	public static final String JSON_SCHEMA_ERROR = "no subschema matched out of the total 1 subschemas";
	public static final String DATA_FORMAT_EERROR = "can't parse the incoming transaction data, data format error";
	//validator
	public static final String CREDIT = "Credit";
	public static final String DEBIT = "Debit";
	public static final String PREPAID = "Prepaid";
	public static final String LOCAL_DIRECTORY = "file:///D:/Elepandas/Flink-Project/RocksDBStateBackend/offsetCheckpoint";
	
	//parallelism parameters
	
	public static final int PARALLELISM = 3;
	public static final int CHECKPOINT_TIME = 10;
	public static final int WATERMARK_TIME = 10;
	public static final int FIXED_RESTART_DELAY = 10000;
	public static final int FIXED_RESTART_ATTEMPTS = 3;
	public static final String FETCH_CURRENT_BOD_END_POINT = "/api/fetchCurrBusinessDate";
	public static final String FETCH_BIN_INFO = "/getBinRangeInformation";
	public static final String INTER_CARD_NUM = "interchangeCardNumber";
	
	
	//NPE error codes
	
	public static final String ERR_MSG_NPERR000001 = "Invalid Transaction Type";
	public static final String ERR_MSG_NPERR000002 = "Original transaction not found for Refund, Void/Reversal";
	public static final String ERR_MSG_NPERR000030 = "Refund amount is greater than transaction amount";
	public static final String ERR_MSG_NPERR000003 = "Duplicate Transaction";
	public static final String ERR_MSG_NPERR000004 = "Invalid CVV2 result code";
	public static final String ERR_MSG_NPERR000005 = "Invalid Terminal Entry Capability";
	public static final String ERR_MSG_NPERR000006 = "Invalid Chip Condition Code";
	public static final String ERR_MSG_NPERR000007 = "Invalid MOTO/ECOM Indicator";
	public static final String ERR_MSG_NPERR000011 = "Invalid AVS Response";
	public static final String ERR_MSG_NPERR000012 = "Invalid POS Terminal Attendance";
	public static final String ERR_MSG_NPERR000014 = "Invalid POS Cardholder Presence";
	public static final String ERR_MSG_NPERR000020 = "Invalid Cardholder Authentication";
	public static final String ERR_MSG_NPERR000021 = "Invalid UCAF Collection Indicator";
	public static final String ERR_MSG_NPERR000028 = "Invalid Message Type";
	public static final String ERR_MSG_NPERR000029 = "Invalid POS Entry Mode";
	public static final String ERR_MSG_NPERR000031 = "Original transaction is in non processable exception";
	public static final String ERR_MSG_NPERR000034 = "Invalid Transaction Source";
	public static final String ERR_MSG_NPERR000035 = "Invalid Tenant Code";
	
	
	public static final String NPERR000001 = "NPERR000001";
	public static final String NPERR000002 = "NPERR000002";
	public static final String NPERR000030 = "NPERR000030";
	public static final String NPERR000003 = "NPERR000003";
	public static final String NPERR000004 = "NPERR000004";
	public static final String NPERR000005 = "NPERR000005";
	public static final String NPERR000006 = "NPERR000006";
	public static final String NPERR000007 = "NPERR000007";
	public static final String NPERR000011 = "NPERR000011";
	public static final String NPERR000012 = "NPERR000012";
	public static final String NPERR000014 = "NPERR000014";
	public static final String NPERR000020 = "NPERR000020";
	public static final String NPERR000021 = "NPERR000021";
	public static final String NPERR000028 = "NPERR000028";
	public static final String NPERR000029 = "NPERR000029";
	public static final String NPERR000031 = "NPERR000031";
	public static final String NPERR000034 = "NPERR000034";
	public static final String NPERR000035 = "NPERR000035";
	
	
	
	public static final String PRERR000011 = "PRERR000011";
	public static final String PRERR000003 = "PRERR000003";
	public static final String PRERR000016 = "PRERR000016";
	public static final String PRERR000002 = "PRERR000002";
	public static final String PRERR000001 = "PRERR000001";
	public static final String PRERR000007 = "PRERR000007";
	public static final String PRERR000004 = "PRERR000004";
	
	
	public static final String ERR_MSG_PRERR000011 = "Invalid Permitted Acquiring Currency";
	public static final String ERR_MSG_PRERR000003 = "Terminal ID not found or Terminal may be closed/de installed";
	public static final String ERR_MSG_PRERR000016 = "Invalid Payment Method";
	public static final String ERR_MSG_PRERR000002 = "Store ID not found or Store may be closed/purged";
	public static final String ERR_MSG_PRERR000001 = "SID and TID combination blocked/deactivated";
	public static final String ERR_MSG_PRERR000007 = "Merchant Closed or Purged";
	public static final String ERR_MSG_PRERR000004 = "MCC not defined for the merchant";
	
	//TODO - key should match cmaster data description
	public static final String STATUS_PROPER = "TS0014";
	public static final String STATUS_NPE = "TS0002";
	public static final String TXN_STATUS_PROCESSABLE_EXCEPTION = "TS0005";
	
	public static final int SNOFLAKE_ID_GEN_PARM = 2;
	
	//bin data check
	
	public static final String ERR_MSG_PRERR000008 = "Bin not found";
	public static final String PRERR000008 = "PRERR000008";
	public static final String PRERR000010 = "PRERR000010";
	public static final String PRERR000009 = "PRERR000009";
	public static final String PRERR000013 = "PRERR000013";
	public static final String ERR_MSG_PRERR000009 = "Transaction Date greater than Business date";
	public static final String ERR_MSG_PRERR000013 = "Original transaction is in processable exception";
	public static final String ERR_MSG_PRERR000010 = "RA/IRD not found";
	
	public static final String ERR_MSG_PRERR000015 = "Bin activation date issue";
	public static final String PRERR000015 = "PRERR000015";
	
	
	//NPE Regex
	public static final String ALLOWED_CVV2RESULTCODE = "^[MNPUS]$";
	public static final String ALLOWED_TEC = "^[0-3]$";
	public static final String ALLOWED_CCCODE = "^[012 ]$";
	public static final String ALLOWED_MOTOEI = "^(00|0[1-8])$";
	public static final String ALLOWED_AVSRESP = "^[ABCDFGIMNPRSUWXYZ]$";
	public static final String ALLOWED_POS_TERMINAL_ATTENDENCE = "^[0129]$";
	public static final String ALLOWED_POS_CRD_HLDR_PRSNCE = "^[0-5]$";
	public static final String ALLOWED_UCAF_INDICATOR = "^[0-8]$";
	public static final String ALLOWED_ORIG_MTI = "^(0100|0110|0200|0210|0220|0230|0400|0410)$";
	public static final String ALLOWED_PAN_ENTRY_MODE = "^(00|01|02|03|04|05|07|90|91|95)$";
	public static final String ALLOWED_PAN_CAPABILITY = "^(0|1|2)$";
	public static final String ALLOWED_EIGHTH_CHAR =  "^[0-6]$";
	public static final String ALLOWED_NINTH_CHAR = "^[0-5]$";
	public static final String ALLOWED_MTI = "^(0110|0100|0200|0210|0220|0230|0400|0410)$";
	
	//Transaction Step Status	
	public static final String NP_SCHEMA_SETTLEMENT_CODE = "IS001";
	public static final String NPE_CODE = "TS0002";
	public static final String DUPLICATE_CODE = "TS0003";
	public static final String PROCESSABLE_EXCEPTION_CODE = "TS0005";
	public static final String PROCESSABLE_PASSED = "TS0006";
	public static final String FEES_CALCULATED = "TS0028"; 
	public static final String SENT_FOR_RISK_EVA_CLRING = "TS0029"; 
	public static final String READY_FOR_SETTLEMENT = "TS0014"; 
	public static final String INTERCHANGE_STATUS = "IS001"; 
	
	//Transaction Type Codes
	public static final String REFUND_CODE = "TT002";
	public static final String PURCHASE_VOID_CODE = "TT008";
	public static final String REFUND_VOID_CODE = "TT010";
	public static final String PURCHASE_REVERSAL_CODE = "TT009";
	public static final String REFUND_REVERSAL_CODE = "TT011";
	
	public static final String PUBLISH_FLAG_Y = "Y";
	
	public static final String PUBLISH_FLAG_N = "N";
	
	public static final String NO = "No";
	public static final String YES = "Yes";
	public static final String A = "A";
	
	
	
	
	//Redis properties
	public static final String REDIS_HOST = "localhost"; 
	public static final int REDIS_PORT = 6379; 
	public static final String REDIS_KEY_PREFIX = "txn_type_map:";
	public static final String REDIS_KEY_SEPERATER = ":";
	public static final String REDIS_BIN_KEY_PREFIX = "BIN";
	public static final String REDIS_KEY_PREFIX_2 = "country_region_map:";
	
	
	
	//Bin
	public static final String DOUBLE_ZERO = "00";
	public static final String PROPER = "TS0014";
	public static final String DECLINE = "TS0025";
	public static final String RUPAY = "RUPAY";
	public static final String VISA = "VISA";
	public static final String MASTERCARD = "MASTERCARD";
	public static final String MASTER_DEBIT_CARD = "DMC";
	public static final String MASTER_CREDIT_CARD = "MCC";
	public static final String RUPAY_S = "S";
	public static final String RUPAY_D = "D";
	
	public static final String DOMESTIC = "DOMESTIC";
	public static final String INTERNATIONAL = "INTERNATIONAL";
	
	public static final String RUPAY_DEBIT_CARD = "01";
	public static final String RUPAY_CREDIT_CARD = "02";
	public static final String RUPAY_PREPAID_CARD = "03";
	
	
	
	public static final String KEY_PATTERN = "*$#*-*$#*";
	public static final String SPLIT_KEY_PATTERN = "-";
	public static final String KEY_FORMAT_PATTERN = "$#";
	
	public static final String TXN_DATE_FORMAT = "yyyy-MM-dd";
	public static final String NO_CURR_DATE = "Unable to fetch current business date";
	public static final String INVALID_DATA = "passed date is invalid:";
	public static final String BUSINESS_DATE = "businessDate";
	
	//RA
	public static final String INTRA_COUNTRY = "INC003";
	public static final String INTRA_REGIONAL = "INC002";
	public static final String INTER_REGIONAL = "INC001";
	public static final String DEFAULT_RA = "0";
	public static final String ALL = "ALL";
	public static final String SPLIT_BY = ",";
	public static final String INSTITUTE_CONATCT_KEY = "INSTITUTE_CONATCT:tenantCode:";
	public static final String REGION_MAP_KEY = "RegionMapByCountryCode:countryCode:";
	public static final String VISA_RA_KEY = "VISA_RA:";
	public static final String SEPERATER = ":";
	public static final String CAB_KEY = "CAB_KEY:";
	public static final String CAB_TYPE_KEY = "CAB_TYPE_KEY:";
	
	//IRD
	public static final String DEFAULT_IRD = "75";
	public static final String MASTERCARD_ALLOWED_REGION = "R004";
	public static final String INTERCHANGE_CODE = "IN001";
	public static final String INTERCHANGE_REGION_MAP_KEY = "INTERCHANGE_REGION_MAP_KEY:byRegionCode:";
	public static final String IRD_MASTERDATA_KEY = "IRD_MASTERDATA_KEY:";
	public static final String CLEARING_DEFAULT_9 = "9";
	public static final String CLEARING_DEFAULT_0 = "0";
	public static final String NOT_REQUIRED = "NOT REQUIRED";
	public static final String TXN_AMOUNT_SPLIT_BY = ":";
	public static final String REQUIRED = "REQUIRED";
	
	
	//clearing
	public static final String REDIS_CLARING_KEY_PREFIX = "CLEARING";
	public static final String MASTERCARD_CLEARING_ACQUIRER_REFERENCE_DATA_FIXED_CHARACTER_1 = "1";
	public static final String VISA_TCR0_AQUIRER_REFRENCE_NUMBER_FIXED_VAL = "7";
	public static final String VISA_CLEARING_SEQUENCE_KEY_NAME = "clearing_visa_arn";
	public static final String CLEARING_KAFKA_TOPIC_NAME = "ACQ-CLEARING-DATA";
	
	
	public static final String VISA_CLEARING_INTERCHANGE_CODE = "IN001";
	public static final String VISA_TCR0_SPACE = " ";
	public static final String CLEARING_DEFAULT_N = "N";
	public static final String VISA_TCR0_SETTLEMENT_FLAG_9 = "9";
	public static final String VISA_TCR0_YES = "Yes";
	public static final String CLEARING_DEFAULT_1 = "1";
	public static final String VISA_TCR1_RESERVED_3_DEFAULT_0 = "0";
	public static final String VISA_TCR1_AUTHORIZATION_SOURCE_CODE_DEFAULT_V = "V";
	public static final String VISA_TCR5_TXN_COMPONENT_SEQUENCE_NUMBER_DEFAULT_5 = "5";
	public static final String VISA_TCR5_INFORMATION_INDICATOR_DEFAULT_N = "N";
	public static final String VISA_TCR5_MULTIPLE_CLEARING_SEQUENCE_NUMBER_DEFAULT_1 = "11";
	public static final String RUPAY_CLARING_MTI_1240 = "1240";
	public static final String RUPAY_CLARING_MTI_1420 = "1420";
	public static final String RUPAY_CLARING_FUNCTION_CODE_200 = "200";
	public static final String RUPAY_CLARING_FUNCTION_CODE_262 = "262";
	public static final String RUPAY_CLARING_FUNCTION_CODE_420 = "420";
	public static final String RUPAY_CLARING_FUNCTION_CODE_269 = "269";
	public static final String RUPAY_CLARING_INTERCHANGE_CODE_IN003 = "IN003";
	public static final String RUPAY_CLARING_BLANK = "";
	public static final String RUPAY_CLARING_SPACE = " ";
	public static final String VISA_TCR0_USAGE_CODE_1 = "1";
	public static final String VISA_TCR0_COLLECTION_ONLY_FLAG_C = "C";
	public static final String MASTERCARD_SEQUENCE_KEY_NAME = "clearing_mastercard_arn";
	public static final String MASTERCARD_CLEARING_INTERCHANGE_CODE = "IN002";

	
	public static final String DATA_PERSISTENCE_KAFKA_TOPIC = "ACQ-CLEARING-DATA";
	public static final String TXN_SETTLEMENT_STATUS_HOLD = "HOLD";
	public static final String TXN_SETTLEMENT_STATUS_SUSPECT = "SUSPECT";
	
	public static final String APPROVED_TXN_RESPONSE_CODE = "00";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String APPLICATION_JSON = "application/json";
	public static final int STATUS_200 = 200;
	public static final String TXN_SETTLEMENT_STATUS_SUSPECT_CODE = "TS0008";
	public static final String TXN_SETTLEMENT_STATUS_HOLD_CODE = "TS0009";
	public static final String ONE_STRING = "1";
	public static final String A01_STRING = "A01";
	public static final String A02_STRING = "A02";
	
	public static final String PURCHASE_TRANSACTION_CODE = "TT001";
	public static final String DEBIT_TRANSACTION_CODE = "PM001";
	public static final String CREDIT_TRANSACTION_CODE = "PM002";
	public static final String PREPAID_TRANSACTION_CODE = "PM003";
	
	//tax calculation
	public static final String INDIA_COUNTRY_CODE = "IND";
	public static final String IGST_TAX_CODE = "TT01";
	public static final String CGST_TAX_CODE = "TT02";
	public static final String SGST_TAX_CODE = "TT03";
	public static final String VAT_TAX_CODE = "TT04";
	
	public static final String PRICING_FEE_VALUE_GTLT_GREATER_THAN = "GT";
	public static final String PRICING_FEE_VALUE_GTLT_LESS_THAN = "LT";
	public static final String PRICING_FEE_VALUE_GTLT_BOTH = "BT";
	
	
	//Rule-engine
	public static final String RULE_ENGINE_API_END_POINT_FOR_RISK = "http://localhost:8085/rule-engine-setl/v1/setl";
	public static final String RULE_ENGINE_API_END_POINT_FOR_FEE_CALCULATION = "http://localhost:8085/rule-engine-setl/v1/pricing";
	public static final String RULE_ENGINE_API_HEADER_KEY = "ruleset";
	public static final String RULE_ENGINE_API_HEADER_VALUE_RISK_IDENTIFICATION = "ruleengine/Acquirer-ruleset1";
	public static final String RULE_ENGINE_API_HEADER_VALUE_FOR_FEE_CALCULATION = "ruleengine/PricingFeeRule";
	
	
	//Cassandra
	public static final String CASSANDRA_IP_HOST = "127.0.0.1";
	public static final int CASSANDRA_PORT_NUMBER = 9042;
	public static final String MERCHANT_TXN_KEYSPACE = "dev_settlement";
	public static final String MERCHANT_TXN_TABLE_NAME = "merchant_txn";
	
	
	//Risk
	public static final String RISK_EVALUATION_KAFKA_TOPIC_NAME = "ACQ-TXN-RISK-DATA";
	
	//exception handler
	public static final String FORMAT_EXEC_MSG = "FormatException";
	public static final String TECH_EXEC_MSG = "TechenicalException";
	public static final String TECH_EXEC_Y = "1";
	public static final String TECH_EXEC_N = "0";
	public static final String HAS_TRX_FLOW_Y = "1";
	public static final String HAS_TRX_FLOW_N = "0";
	public static final String IDENTIFIER = "identifier";
}
