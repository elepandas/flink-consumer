package com.fss.presettlement.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fss.presettlement.constants.Constants;

/**
 * 
 * This class contains logic to log the transaction details to specified files.
 * @since 2023
 *
 */
public class TxnExceptionlogger {
	
	private TxnExceptionlogger() {}
	
	
	private static final String LOG_FILE_PREFIX = "TechenicalError";
    private static final long MAX_LOG_FILE_SIZE = 10 * 1024 * 1024; // 10 MB in bytes

	private static final String NPE_LOG_FILE_PREFIX = "DataValidationErrors";
    
    private static int currentLogFileNumber = 1;
    private static int currentNPELogFileNumber = 1;

	 /**
	 * 
	 * This method provides implementation of logic to log the non parsed transaction details to specified files.
	 *
	 */
	
	 public static void logNonParsedJsonTransaction(String jsonTransaction) {
	        try {
	            // Get the current date in the desired format for folder and file naming
	        	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT_1);
		        String currentDate = dateFormat.format(new Date());

	            String logFileName = String.format("%s-%s-%d.log", NPE_LOG_FILE_PREFIX, currentDate, currentNPELogFileNumber);
	            File logFolder = new File(Constants.FOLDER_NAME + currentDate);
	            if (!logFolder.exists()) {
	                logFolder.mkdirs();
	            }

	            File logFile = new File(logFolder, logFileName);

	            if (logFile.exists() && logFile.length() >= MAX_LOG_FILE_SIZE) {
	            	currentNPELogFileNumber++;
	                logFileName = String.format("%s-%s-%d.log", LOG_FILE_PREFIX, currentDate, currentNPELogFileNumber);
	                logFile = new File(logFolder, logFileName);
	            }
		            
	            // Append the non-parsed JSON transaction to the log file
	            try (FileWriter writer = new FileWriter(logFile, true)) {
	                writer.write(jsonTransaction + "\n");
	            } catch (IOException ioException) {
	                ioException.printStackTrace();
	            }
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        }
	    }
	    
	 /**
		 * 
		 * This method provides implementation of logic to log the parsed transaction details to specified files.
		 *
		 */
	    public static void logParsedJsonTransaction(String jsonTransaction) {
	        try {
	            // Get the current date in the desired format for folder and file naming
	            SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT_1);
	            String currentDate = dateFormat.format(new Date());

	            // Create a directory with the current date as the folder name
	            File logFolder = new File(Constants.FOLDER_NAME + currentDate);
	            if (!logFolder.exists()) {
	                logFolder.mkdirs();
	            }

	            // Create a log file within the folder
	            File logFile = new File(logFolder, Constants.FILE_NAME_2);

	            // Append the non-parsed JSON transaction to the log file
	            try (FileWriter writer = new FileWriter(logFile, true)) {
	                writer.write(jsonTransaction + "\n");
	            } catch (IOException ioException) {
	                ioException.printStackTrace();
	            }
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        }
	    }

	    public static void techErrTransactions(String jsonTransaction) {
	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT_1);
	            String currentDate = dateFormat.format(new Date());

	            String logFileName = String.format("%s-%s-%d.log", LOG_FILE_PREFIX, currentDate, currentLogFileNumber);
	            File logFolder = new File(Constants.FOLDER_NAME + currentDate);
	            if (!logFolder.exists()) {
	                logFolder.mkdirs();
	            }

	            File logFile = new File(logFolder, logFileName);

	            if (logFile.exists() && logFile.length() >= MAX_LOG_FILE_SIZE) {
	                currentLogFileNumber++;
	                logFileName = String.format("%s-%s-%d.log", LOG_FILE_PREFIX, currentDate, currentLogFileNumber);
	                logFile = new File(logFolder, logFileName);
	            }

	            try (FileWriter writer = new FileWriter(logFile, true)) {
	                writer.write(jsonTransaction + "\n");
	            } catch (IOException ioException) {
	                ioException.printStackTrace();
	            }
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        }
	    }
}
