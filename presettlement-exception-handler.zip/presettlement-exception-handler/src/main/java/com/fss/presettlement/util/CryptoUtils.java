/*****************************************************************************************************
 * Copyright: Licensed under the Financial Software & Systems Pvt. Ltd
 * These materials are confidential and proprietary to FSS and no part of these
 * materials should be reproduced, published in any form by any means,
 * electronic or mechanical including photocopy or any information storage or
 * retrieval system nor should the materials be disclosed to third parties
 * without the express written authorization of FSS.
 *****************************************************************************************************/

package com.fss.presettlement.util;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoUtils {

	private CryptoUtils() {}
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(CryptoUtils.class);
	
	 public static byte[] getRandomNonce(int numBytes) {
	        byte[] nonce = new byte[numBytes];
	        new SecureRandom().nextBytes(nonce);
	        return nonce;
	    }

	    // AES secret key
	    public static SecretKey getAESKey(int keysize) throws NoSuchAlgorithmException {
	    	logger.logInfo(traceId, "CryptoUtils getAESKey:Started");
	        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
	        keyGen.init(keysize, SecureRandom.getInstanceStrong());
	        return keyGen.generateKey();
	    }

	    // secret derived AES 256 bits secret key
	    public static SecretKey getAESKeyFromsecret(char[] secret, byte[] salt)
	            throws NoSuchAlgorithmException, InvalidKeySpecException {

	    	logger.logInfo(traceId, "CryptoUtils getAESKeyFromsecret:Started");
	        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
	        // iterationCount = 65536
	        // keyLength = 256
	        KeySpec spec = new PBEKeySpec(secret, salt, 65536, 256);
	        SecretKey secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
	        logger.logDebug("0", "CryptoUtils SecretKey getAESKeyFromsecret:::"+secretKey);
	        return secretKey;

	    }

	    // hex representation
	    public static String hex(byte[] bytes) {
	    	logger.logInfo(traceId, "CryptoUtils hex:Started");
	        StringBuilder result = new StringBuilder();
	        for (byte b : bytes) {
	            result.append(String.format("%02x", b));
	        }
	        return result.toString();
	    }

	    // print hex with block size split
	    public static String hexWithBlockSize(byte[] bytes, int blockSize) {

	    	logger.logInfo(traceId, "CryptoUtils hexWithBlockSize:Started");
	        String hex = hex(bytes);

	        // one hex = 2 chars
	        blockSize = blockSize * 2;

	        // better idea how to print this?
	        List<String> result = new ArrayList<>();
	        int index = 0;
	        while (index < hex.length()) {
	            result.add(hex.substring(index, Math.min(index + blockSize, hex.length())));
	            index += blockSize;
	        }

	        return result.toString();

	    }

	    
	    



}
