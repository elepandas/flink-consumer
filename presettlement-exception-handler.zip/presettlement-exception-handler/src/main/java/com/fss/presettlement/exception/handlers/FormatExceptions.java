package com.fss.presettlement.exception.handlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class FormatExceptions {

	private FormatExceptions() {}

	private static CommonLogger logger = new CommonLogger(FormatExceptions.class);
	
	/**
	 * 
	 * This method provides the implementation to insert the data into
	 * format_exception table by accepting traceId, transactionDTO and connection
	 * as input parameters.
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @exception TechnicalException
	 * 
	 */
	public static void add(String traceId, FormatExceptionsDTO formatExceptionsDTO, Connection connection) {
		logger.logInfo(traceId, "FormatExceptions : add() - Entered.");
		PreparedStatement preparedStatement = null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
			Date currentDate = new Date();
			String formattedDate = dateFormat.format(currentDate);
			// Insert query
			String sql = "insert into format_exception (business_date, txn_record, tenant_code, dml_type, dml_by, dml_on, topic_name) "
					+ "values (?,?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1,formattedDate);
			preparedStatement.setString(2,formatExceptionsDTO.getTransactionRecord());
			preparedStatement.setString(3,formatExceptionsDTO.getTenantCode());
			preparedStatement.setString(4,Constants.DML_TYPE);
			preparedStatement.setString(5,Constants.DML_BY);
			preparedStatement.setString(6,formattedDate);
			preparedStatement.setString(7,formatExceptionsDTO.getTopicName());
			
			// fetching the db operation result
			int rowsInserted = preparedStatement.executeUpdate();
			if (rowsInserted > 0) {
				logger.logInfo(traceId, "Data inserted successfully.");
			} else {
				logger.logError(traceId, "Failed to insert data into format_exception.");
			}
			logger.logInfo(traceId, "FormatExceptions : add() - Returned.");
		} catch (SQLException e) {
			logger.logError(traceId,
					"Error while persisting data into format_exception : " + e.getLocalizedMessage());
			TxnExceptionlogger
					.techErrTransactions(formatExceptionsDTO.getTransactionRecord()
							+ Constants.ERROR_MSG_SEPERATER + formatExceptionsDTO.getTransactionRecord()
							+ Constants.ERROR_MSG_SEPERATER
							+ " Error while persisting data into format_exception :  " + e.getMessage());
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, " Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}
}
