package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

/**
 * 
 * This class contains method which perform database operations on interchange txn type table.
 * @author ramcharanr
 *
 */
public class InterchangeTxnType {
	
	private static CommonLogger logger = new CommonLogger(InterchangeTxnType.class);
	
	private InterchangeTxnType() {
		
	}
	
	
	/**
	 * 
	 * This method get the interchange txn type code from database/cache by accepting traceId, interchangeCode and txnTypeCode
	 * as input parameter.
	 * @param traceId
	 * @param interchangeCode
	 * @param txnTypeCode
	 * @return InterchangeTxnTypeCode
	 * @throws TechnicalException
	 * @throws SQLException
	 * 
	 */
	public static String getInterchangeTxnTypeCode(String traceId, String interchangeCode, String txnTypeCode, Connection connection, TransactionDTO transactionDTO ) throws TechnicalException, SQLException {
		logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCode() - Entered.");
		try(Jedis jedis = new Jedis(Constants.REDIS_HOST, Constants.REDIS_PORT)) {
			String interchangeTxnTypeCodeFromCache = getInterchangeTxnTypeCodeFromCache(traceId, interchangeCode, txnTypeCode, jedis, transactionDTO);
			if(null != interchangeTxnTypeCodeFromCache && !interchangeTxnTypeCodeFromCache.isEmpty()) {
				logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCode() - Fetching it from cache.");
				logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCode() - Returned.");
				return interchangeTxnTypeCodeFromCache;
			} else {
				String interchangeTxnTypeCodeFromDB = getInterchangeTxnTypeCodeFromDB(traceId, interchangeCode, txnTypeCode, connection, transactionDTO);
				jedis.set(buildCacheKey(traceId, interchangeCode, txnTypeCode), interchangeTxnTypeCodeFromDB);
				logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCode() - Fetching it from database.");
				logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCode() - Returned.");
				return interchangeTxnTypeCodeFromDB;
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while getting interchange_txn_type_code from cache/db: " + e.getLocalizedMessage());
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while getting interchange_txn_type_code from cache/db: "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		}
	}
	
	
	/**
	 * 
	 * This method gets the interchange_txn_type_code from cache by accepting traceId, interchangeCode, txnTypeCode and
	 * jedis as input parameters.
	 * @param traceId
	 * @param interchangeCode
	 * @param txnTypeCode
	 * @param jedis
	 * @return InterchangeTxnTypeCode
	 * @throws TechnicalException
	 * 
	 */
	public static String getInterchangeTxnTypeCodeFromCache(String traceId, String interchangeCode, String txnTypeCode, Jedis jedis,TransactionDTO transactionDTO) throws TechnicalException {
		logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCodeFromCache() - Entered.");
		try {
			logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCodeFromCache() - Returned.");
			// Retrieve interchange txn type code from Redis using key "interchangeCode+txnTypeCode"
            return jedis.get(buildCacheKey(traceId, interchangeCode, txnTypeCode));
		} catch (JedisConnectionException e) {
			logger.logError(traceId, "Error while getting interchange_txn_type_code from cache:  " + e.getLocalizedMessage());
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while getting interchange_txn_type_code from cache:  "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		}
	}
	
	/**
	 * 
	 * This method get us the cache key.
	 * @param traceId
	 * @param interchangeCode
	 * @param txnTypeCode
	 */
    private static String buildCacheKey(String traceId, String interchangeCode, String txnTypeCode) {
    	logger.logInfo(traceId, "InterchangeTxnType: buildCacheKey()");
        return Constants.REDIS_CLARING_KEY_PREFIX + interchangeCode + txnTypeCode + Constants.REDIS_KEY_SEPERATER ;
    }
    
	
	/**
	 * 
	 * This method fetches the InterchangetxnTypeCode from database by accepting traceId, interchangeCode and
	 * txnTypeCode as input parameters.
	 * @param interchangeCode
	 * @param txnTypeCode
	 * @return InterchangetxnTypeCode
	 * @throws TechnicalException
	 * @throws SQLException
	 * 
	 */
	public static String getInterchangeTxnTypeCodeFromDB(String traceId, String interchangeCode, String txnTypeCode, Connection connection, TransactionDTO transactionDTO) throws TechnicalException, SQLException {
		logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCodeFromDB() - Entered.");
		PreparedStatement preparedStatement = null;
		try {
			if(interchangeCode != null && !interchangeCode.isEmpty() && txnTypeCode != null && !txnTypeCode.isEmpty()) {
				String query = "select interchange_txn_type_code from interchange_txn_type where interchange_code = ? and txn_type_code = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, interchangeCode);
				preparedStatement.setString(2, txnTypeCode);
				ResultSet resultSet = preparedStatement.executeQuery();
				if(resultSet.next()) {
					logger.logInfo(traceId, "InterchangeTxnType : getInterchangeTxnTypeCodeFromDB() - Returned.");
					return resultSet.getString("interchange_txn_type_code");
				} else {
					logger.logError(traceId, "Error while fetching interchange_txn_type_code from interchange_txn_type table.");
				
					TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
			    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
			    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
			    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
			    	throw new TechnicalException("Error while fetching interchange_txn_type_code from interchange_txn_type table.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
					
				
				}
			} else {
				logger.logError(traceId, "interchangeCode/txnTypeCode is null/empty.");
				
				TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
		    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
		    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
		    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
		    	throw new TechnicalException("interchangeCode/txnTypeCode is null/empty.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
				
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while fetching interchange_txn_type_code from database: "+e.getLocalizedMessage());
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while fetching interchange_txn_type_code from database: "+e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		
		
		} finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
	}

}
