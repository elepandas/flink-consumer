package com.fss.presettlement.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
/**
 * 
 * This class contains Date specific utilities
 * @since 2023
 *
 */
public class DateUtil {

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(DateUtil.class);
	 /**
	 * 
	 * This method provides logic implementation of calculating the difference between passed dates
	 * @exception ValidationException
	 * @param startDateStr, endDateStr
	 * @return integer value
	 * 
	 */
	public static int calculateDateDifferenceExcludingSundays(String startDateStr, String endDateStr) throws  ValidationException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        int daysDifference = 0;

        try {
        	if(startDateStr != null && endDateStr != null) {
        		Date startDate = sdf.parse(startDateStr);
                Date endDate = sdf.parse(endDateStr);

                Calendar startCalendar = Calendar.getInstance();
                startCalendar.setTime(startDate);

                Calendar endCalendar = Calendar.getInstance();
                endCalendar.setTime(endDate);

                while (!startCalendar.after(endCalendar)) {
                    // Check if the day is not Sunday (Calendar.SUNDAY is 1)
                    if (startCalendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                        daysDifference++;
                    }
                    startCalendar.add(Calendar.DATE, 1);
                }
        	}
        	 
        } catch (Exception e) {
        	logger.logError(traceId, "Error while calculateDateDifferenceExcludingSundays: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("calculateDateDifferenceExcludingSundays"+startDateStr + Constants.ERROR_MSG_SEPERATER+ endDateStr+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in calculateDateDifferenceExcludingSundays: " + e.getMessage());
        }
        
        return daysDifference;
    }
	
	 /**
	 * 
	 * This method provides logic implementation of converting Date format
	 * @exception  ValidationException
	 * @param inputDateTime
	 * @return String value
	 */
	public static String convertToFormattedDate(String inputDateTime) throws ValidationException {
        // Define the input and output date formats
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = null;
        try {
        	if(inputDateTime != null) {
	            // Parse the input date string
	            Date date = inputFormat.parse(inputDateTime);
	
	            // Format the date to the desired output format
	            formattedDate = outputFormat.format(date);
        	}
            
        } catch (Exception e) {
        	logger.logError(traceId, "Error while convertToFormattedDate: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("convertToFormattedDate"+inputDateTime + Constants.ERROR_MSG_SEPERATER+  e.getMessage());
            throw new ValidationException("Error in convertToFormattedDate: " + e.getMessage());
        }
        return formattedDate;
    }
}
