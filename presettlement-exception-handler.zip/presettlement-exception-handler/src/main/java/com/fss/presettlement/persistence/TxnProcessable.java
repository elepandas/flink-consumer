package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains environment executer jdbc operations of Txn Processable
 * @since 2023
 *
 */
public class TxnProcessable {
	
	private TxnProcessable() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnProcessable.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on txn_processable table 
	 * @param txnExceptionCode, transactionDTO
	 * @exception TechnicalException 
	 */
	
	public static void add(TransactionDTO transactionDTO, String txnExceptionCode, Connection connection) throws TechnicalException {
	    logger.logInfo(traceId, "TxnProcessable: txnPersister: Started");
	    
	    PreparedStatement preparedStatement = null;

	    try {
	        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
	        Date currentDate = new Date();
	        String formattedDate = dateFormat.format(currentDate);
	        
	        String sql = "INSERT INTO txn_processable " +
	                     "(process_date, business_date, settlement_txn_key, txn_exception_code, tenant_code, " +
	                     "dml_type, dml_by, dml_on) " +
	                     "VALUES (?,?,?,?,?,?,?,?)";
	        
	        preparedStatement = connection.prepareStatement(sql);
	        preparedStatement.setString(1, String.valueOf(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate()));
	        preparedStatement.setString(2, transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate());
	        preparedStatement.setString(3, transactionDTO.getSettlementTxnKey());
	        preparedStatement.setString(4, txnExceptionCode);
	        preparedStatement.setString(5, transactionDTO.getData().getBody().getDb().getTenantCode());
	        preparedStatement.setString(6, Constants.DML_TYPE);
	        preparedStatement.setString(7, Constants.DML_BY);
	        preparedStatement.setString(8, formattedDate);
	        
	        int rowsInserted = preparedStatement.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            logger.logInfo(traceId, "Data inserted successfully.");
	        } else {
	            logger.logError(traceId, "Failed to insert data into txn_processable.");
	        }
	    } catch (SQLException e) {
	        logger.logError(traceId, "Error while persisting data at txnDataPersister: " + e.getLocalizedMessage());
	    
	        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data at txnDataPersister: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
	    
	    } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
	}
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on txn_processable table 
	 * @param txnExceptionCode, transactionDTO
	 * @exception TechnicalException 
	 */
	public static void deleteBySettlementTxnKey( Connection connection, TransactionDTO transactionDTO) throws TechnicalException {
	    logger.logInfo(traceId, "TxnProcessable: deleteBySettlementTxnKey: Started");
	    
	    PreparedStatement preparedStatement = null;

	    try {
	        String sql = "DELETE FROM txn_processable WHERE settlement_txn_key = ?";
	        
	        preparedStatement = connection.prepareStatement(sql);
	        preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());
	        
	        int rowsDeleted = preparedStatement.executeUpdate();
	        
	        if (rowsDeleted > 0) {
	            logger.logInfo(traceId, "Records deleted successfully.");
	        } else {
	            logger.logError(traceId, "No records found to delete with settlement_txn_key " + transactionDTO.getSettlementTxnKey());
	        }
	    } catch (SQLException e) {
	        logger.logError(traceId, "Error while deleting records at deleteBySettlementTxnKey: " + e.getLocalizedMessage());

	        TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data at txnDataPersister: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
	    
	    } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
	}
}
