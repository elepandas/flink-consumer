package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of additional Response data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class AddlRespData{
    public String rsnCode;
    public String addrVrfnRsltCode;
    public String addnlTknRespInfo;
    public String extnSTIPRsnCode;
    public String cvvRsltsCode;
    public String pacmDiversionLvlCode;
    public String pacmDiversionRsnCode;
    public String crdAuthenRsltsCode;
    public String cvv2RsltCode;
    public String cavvRsltsCode;
    public String respRsnCode;
    public String panL4DFR;
}
