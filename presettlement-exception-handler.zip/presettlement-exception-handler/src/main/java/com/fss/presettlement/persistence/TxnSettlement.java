package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TxnSettlementDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;
/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnSettlement {
	
	private TxnSettlement() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnSettlement.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on txn_settlement table 
	 * @param transactionDTO
	 * @exception Exception 
	 */
	public static void txnPersister(TransactionDTO transactionDTO, String rawTrx) throws Exception {
		
		logger.logInfo(traceId, "TxnSettlement: txnPersister:Started");
		try {
        var env = StreamExecutionEnvironment.getExecutionEnvironment();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        // Get the current date and time
        Date currentDate = new Date();
        // Format the date and time to the desired format
        String formattedCurrentDate = dateFormat.format(currentDate); 

        ObjectMapper objectMapper = new ObjectMapper();
        String txnData = objectMapper.writeValueAsString(transactionDTO.getData().getBody());
        env.fromElements(
        		transactionDTO
        ).addSink(
                JdbcSink.sink(
                        "insert into txn_settlement (settlement_txn_key, process_date, business_date, pg_payment_id, merchant_track_id, discriminant, "
                        + "txn_datetime, txn_amt, acquirer_institution_id, primary_account_no, merchant_id, store_id, terminal_id, payment_code,"
                        + " txn_source_code, txn_type_code, response_code, sub_channel, sub_channel_request_id, txn_data,"
                        + "tenant_code, dml_type, dml_by, dml_on) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (statement, trxDto) -> {
                            statement.setString(1, trxDto.getSettlementTxnKey());
                            statement.setString(2, formattedCurrentDate);
                            statement.setString(3, formattedCurrentDate); // API call to fetch current business date - common global variable
                            statement.setString(4, trxDto.getData().getBody().getAddnlFlds().getPgPmntId());
                            statement.setString(5, trxDto.getData().getBody().getAddnlFlds().getMerchTrackId());
                            statement.setString(6, trxDto.getData().getDiscrim());
                            statement.setString(7, trxDto.getData().getBody().getStdFlds().getLocalDateTime());
                            statement.setString(8, trxDto.getData().getBody().getStdFlds().getTxnAmt());
                            statement.setString(9, trxDto.getData().getBody().getStdFlds().getAcqInstIdCode());
                            statement.setString(10, trxDto.getData().getPan().substring(0, 20));
                            statement.setString(11, trxDto.getData().getBody().getDb().getMerchID());
                            statement.setString(12, trxDto.getData().getBody().getAddnlFlds().getStoreCode());
                            statement.setString(13, trxDto.getData().getBody().getStdFlds().getCrdAccptTermId());
                            statement.setString(14, trxDto.getData().getPaymentCode());
                            statement.setString(15, trxDto.getData().getBody().getAddnlFlds().getTxnSrc()); 																	//txn_source_code
                            statement.setString(16, trxDto.getData().getBody().getTxnEnrData().getTrxTypeCode());																		 //txn_type_code
                            statement.setString(17, trxDto.getData().getBody().getStdFlds().getResponseCode());
                            statement.setString(18, trxDto.getData().getSubChannel());
                            statement.setString(19, trxDto.getData().getSubChannelRequestId());
                            statement.setString(20, txnData); 
                            statement.setString(21, trxDto.getData().getBody().getDb().getTenantCode()); 
                            statement.setString(22, Constants.DML_TYPE);
                            statement.setString(23, Constants.DML_BY);
                            statement.setString(24, formattedCurrentDate);
                            
                            
                        },
                        JdbcExecutionOptions.builder()
	                        .withBatchSize(Constants.DB_BATCH_SIZE)
	                        .withBatchIntervalMs(Constants.DB_INTERVAL_MS)
	                        .withMaxRetries(Constants.DB_MAX_RETRY)
	                        .build(),
	                    new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
	                        .withUrl(Constants.DB_HOST) 
	                        .withDriverName(Constants.DB_DRIVER) 
	                        .withUsername(Constants.DB_USR_NAME)
	                        .withPassword(Constants.DB_PASS)
	                        .build()
                ));
                
        env.execute();
        
		}catch(Exception e) {
			logger.logError(traceId, "Error while persisting data at TxnSettlement: " + e.getMessage());
		
            TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException("Error while persisting data at TxnSettlement: "+ e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
            
		}
        
    }
	
	/**
	 * 
	 * Method contains the logic to perform insert operation on txn_settlement table by 
	 * accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public static void add(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnSettlement : add() - Started.");
	    PreparedStatement preparedStatement = null;
        try {
        	//Date for dml_on
        	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
            Date currentDate = new Date();
            String formattedCurrentDate = dateFormat.format(currentDate);
            ObjectMapper objectMapper = new ObjectMapper();
			String txnData = objectMapper.writeValueAsString(transactionDTO.getData().getBody());
			
			//txn_settlement custom insert query 
			String sql = "insert into txn_settlement " +
                     "(settlement_txn_key, process_date, business_date, pg_payment_id, pg_txn_id, merchant_track_id, discriminant, " +
                     "txn_datetime, txn_amt, acquirer_institution_id, issuer_institution_id, primary_account_no, merchant_id, store_id, " +
                     "terminal_id, payment_code, txn_source_code, processing_code, txn_type_code, response_code, sub_channel, " +
                     "sub_channel_request_id, txn_data, tenant_code, dml_type, dml_by) " +
                     "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			 
			 logger.logInfo(traceId, "Inserting data into int txn_settlement table.");
			 //Declaring prepared statement
			 preparedStatement = connection.prepareStatement(sql);
			 preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());
		     preparedStatement.setString(2, String.valueOf(LocalDate.ofInstant(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().toInstant(), 
					 ZoneId.systemDefault())));
		     preparedStatement.setString(3, transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate());
		     preparedStatement.setString(4, transactionDTO.getData().getBody().getAddnlFlds().getPgPmntId());
		     preparedStatement.setString(5, "12");
		     preparedStatement.setString(6, transactionDTO.getData().getBody().getAddnlFlds().getMerchTrackId());
		     preparedStatement.setString(7, transactionDTO.getData().getDiscrim());
		     preparedStatement.setString(8, transactionDTO.getData().getBody().getStdFlds().getLocalDateTime());
		     preparedStatement.setString(9, transactionDTO.getData().getBody().getStdFlds().getTxnAmt());
		     preparedStatement.setString(10, transactionDTO.getData().getBody().getStdFlds().getAcqInstIdCode());
		     preparedStatement.setString(11, transactionDTO.getData().getBody().getStdFlds().getForwdInstIdCode());
		     preparedStatement.setString(12, transactionDTO.getData().getPan());
		     preparedStatement.setString(13, transactionDTO.getData().getMerchantId());
		     preparedStatement.setString(14, transactionDTO.getData().getBody().getAddnlFlds().getStoreCode());
		     preparedStatement.setString(15, transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId());
		     preparedStatement.setString(16, transactionDTO.getData().getPaymentCode());
		     preparedStatement.setString(17, transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc());
		     preparedStatement.setString(18, transactionDTO.getData().getBody().getAddnlFlds().getActionCode());
		     preparedStatement.setString(19, transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode());
		     preparedStatement.setString(20, transactionDTO.getData().getBody().getStdFlds().getResponseCode());
		     preparedStatement.setString(21, transactionDTO.getData().getSubChannel());
		     preparedStatement.setString(22, transactionDTO.getData().getSubChannelRequestId());
		     preparedStatement.setString(23, txnData);
		     preparedStatement.setString(24, transactionDTO.getData().getBody().getDb().getTenantCode());
		     preparedStatement.setString(25, Constants.DML_TYPE);
		     preparedStatement.setString(26, transactionDTO.getData().getDmlBy());
		        
		     //Executing the insert operation using prepared statement
		     int rowsInserted = preparedStatement.executeUpdate(); 
		     //Validating the result
		     if (rowsInserted > 0) {
		    	 logger.logInfo(traceId, "Data inserted successfully.");
		     } else {
		    	 logger.logError(traceId, "Failed to insert data into txn_settlement.");
		     }
		     logger.logInfo(traceId, "TxnSettlement : add() - Returned.");
        } catch (SQLException | JsonProcessingException e) {
        	logger.logError(traceId, " Error while persisting data at TxnSettlement: " + e.getLocalizedMessage());

        	TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException(" Error while persisting data at TxnSettlement: "+ e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
			
		} finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
	}
	
	
	/**
	 * 
	 * This method provides the implementation to fetch txn_settlement_id from database by accepting
	 * traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException 
	 */
    public static TxnSettlementDTO getTxnSettlement(String traceId, TransactionDTO transactionDTO, 
    		Connection connection) throws SQLException, TechnicalException {
    	logger.logInfo(traceId, "TxnSettlement : getTxnSettlement() - Started.");
        PreparedStatement preparedStatement = null;
        try {
            // Create a SQL query with placeholders for the dynamic parameters.
            String sqlQuery = "select txn_settlement_id from txn_settlement where settlement_txn_key = ? ";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());

            // Execute the query.
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
                // Populate a TxnUniqueDataDTO object with the retrieved data.
            	TxnSettlementDTO txnSettlementDto = new TxnSettlementDTO();
                txnSettlementDto.setTxnSettlementId(resultSet.getLong("txn_settlement_id"));
                logger.logInfo(traceId, "TxnSettlement : getTxnSettlement() - Returned.");
                return txnSettlementDto;
            } else {
            	logger.logInfo(traceId, "TxnSettlement : getTxnSettlement() - Returned.");
                return null;
            }
        } catch(Exception e) {
			logger.logError(traceId, "Error while getting txn_settlement_id at getTxnSettlement: " + e.getMessage());
		
            TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException("Error while getting txn_settlement_id at getTxnSettlement: "+ e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
        
        } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
    }
	
}
