package com.fss.presettlement.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.persistence.BusinessKey;

/**
 * 
 * This class contains the util methods regarding clearing data enrichment.
 * @author ramcharanr
 *
 */
public class PreSettlementCommonUtilty {
	
	private static CommonLogger logger = new CommonLogger(PreSettlementCommonUtilty.class);
	
	private PreSettlementCommonUtilty() {
		
	}
	
	/**
	 * 
	 * This method returns the current Julian date.
	 * @return current Julian date
	 * 
	 */
	public static String getCurrentJulianDate(String traceId) {
		logger.logInfo(traceId, "PreSettlementCommonUtilty : getCurrentJulianDate() - Entered.");
		// Get the current date
        LocalDate currentDate = LocalDate.now();
        // Get the Julian date in YDDD format
        int julianDay = currentDate.getDayOfYear();
        //Convert year to string to fetch last character
        String year = String.valueOf(currentDate.getYear());
        //Get last character of the year and concat it to Julian day
        logger.logInfo(traceId, "PreSettlementCommonUtilty : getCurrentJulianDate() - Returned.");
        return year.substring(year.length()-1)+julianDay;
	}
	
	/**
	 * 
	 * This method converts the date into Julian date.
	 * @param traceId
	 * @param traceId
	 * @param date
	 * @return converted Julian date
	 * @throws TechnicalException
	 * 
	 */
	public static String convertDateIntoJulianDate(String traceId, String date, TransactionDTO transactionDTO) throws TechnicalException {
		logger.logInfo(traceId, "PreSettlementCommonUtilty : convertDateIntoJulianDate() - Entered.");
		if(date != null && !date.isEmpty()) {
			LocalDate localDate = LocalDate.parse(date);
			// Get the Julian date in YDDD format
			int julianDay = localDate.getDayOfYear();
			//Convert year to string to fetch last character
			String year = String.valueOf(localDate.getYear());
			//Get last character of the year and concat it to Julian day 
			logger.logInfo(traceId, "PreSettlementCommonUtilty : convertDateIntoJulianDate() - Returned.");
			return year.substring(year.length()-1)+julianDay;
		} else {
			logger.logError(traceId, "Error while converting date into julian date. "+date);
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while converting date into julian date. "+date, traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		}
	}
	
	/**
	 * 
	 * This method accept keyName and tenantCode as input parameter and returns the sequence number.
	 * @param traceId
	 * @param keyName
	 * @param tenantCode
	 * @return SequenceNo
	 * @throws SQLException
	 * @throws TechnicalException
	 * 
	 */
	public static String getSequenceNo(String traceId, String keyName, String tenantCode, Connection connection, TransactionDTO transactionDTO) throws SQLException, TechnicalException {
		logger.logInfo(traceId, "PreSettlementCommonUtilty : getSequenceNo() - Entered.");
		String sequenceNo = BusinessKey.getSequenceNo(traceId, keyName, tenantCode, connection, transactionDTO);
		if(null != keyName && !keyName.isEmpty() && null != tenantCode && !tenantCode.isEmpty()) {
			int sequenceNumber = Integer.valueOf(sequenceNo)+1;
			BusinessKey.updateSequenceNo(traceId, String.valueOf(sequenceNumber), keyName, tenantCode, connection, transactionDTO);
			logger.logInfo(traceId, "PreSettlementCommonUtilty : getSequenceNo() - Returned.");
			return String.valueOf(sequenceNumber);
		} else {
			logger.logError(traceId, "Error while fetching sequence number from DB.");
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while fetching sequence number from DB.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		}
	}
	
	
	/**
	 * 
	 * This method will return the check digit value by accepting the sequence number as input parameter.
	 * @param traceId
	 * @param psInputValue
	 * @return {@link Integer} value
	 * @throws TechnicalException 
	 * 
	 */
	public static int getCheckDigit(String traceId, String psInputValue, TransactionDTO transactionDTO) throws TechnicalException {
		logger.logInfo(traceId, "PreSettlementCommonUtilty : getCheckDigit() - Entered.");
		String psStrNumber, psStrCheckNumber, psStrTmpNumber;
		int pcCharDigit;
		int piCounter, piFlgTggle, piVal1, piTmpVal, piTmpCheckDegit;
		if (null != psInputValue && !psInputValue.isEmpty()) {
			psStrNumber = psInputValue;
			psStrCheckNumber = psStrNumber;
			psStrTmpNumber = "";
			pcCharDigit = 0;
			piCounter = piTmpVal = piVal1 = 0;
			piFlgTggle = 1;
			piCounter = psStrCheckNumber.length();

			while (piCounter > 0) {
				pcCharDigit = Integer.parseInt(Character.toString(psStrCheckNumber.charAt(piCounter - 1)));

				if (piFlgTggle == 1) {
					psStrTmpNumber = psStrTmpNumber + (pcCharDigit * 2);
					piFlgTggle = 0;
				} else {
					psStrTmpNumber = psStrTmpNumber + pcCharDigit;
					piFlgTggle = 1;
				}
				piCounter--;
			}
			while (piVal1 < psStrTmpNumber.length()) {
				piTmpVal = piTmpVal + Integer.parseInt(Character.toString(psStrTmpNumber.charAt(piVal1)));
				piVal1++;
			}

			if (piTmpVal % 10 == 0)
				piTmpCheckDegit = 0;
			else
				piTmpCheckDegit = (10 - (piTmpVal % 10));
			
			logger.logInfo(traceId, "PreSettlementCommonUtilty : getCheckDigit() - Returned.");
			return (piTmpCheckDegit);
		} else {
			logger.logError(traceId, "Input value is null/empty.");
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Input value is null/empty.", traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		}
	}
	
	
	
	public static String getStringOfFormatExceptionsDTO( FormatExceptionsDTO formatExceptionsDTO) {
		logger.logInfo("PreSettlementCommonUtilty "," : getStringOfFormatExceptionsDTO() - Entered.");
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(formatExceptionsDTO);
			
		} catch (Exception e) {
			logger.logError(" PreSettlementCommonUtilty","getStringOfFormatExceptionsDTO: Error while converting transaction data into string : "+e.getLocalizedMessage());
			TxnExceptionlogger.techErrTransactions(" Error while publishing transaction data into risk kafka topic : "+e.getLocalizedMessage());
			return null;
		}
		
	}
	
	public static String getStringOfTechenicalExceptionsDTO(TechenicalExceptionDTO techenicalExceptionDTO) {
		logger.logInfo("PreSettlementCommonUtilty"," : getStringOfTechenicalExceptionsDTO() - Entered.");
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(techenicalExceptionDTO);
			
		} catch (Exception e) {
			logger.logError("PreSettlementCommonUtilty","getStringOfTechenicalExceptionsDTO: Error while converting transaction data into string : "+e.getLocalizedMessage());
			TxnExceptionlogger.techErrTransactions(" Error while publishing transaction data into risk kafka topic : "+e.getLocalizedMessage());
			return null;
		}
		
	}
	
	public static String extractTenantCodeFromRawTrx(String jsonString) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Check if "data" node is present
            JsonNode dataNode = jsonNode.has("data") ? jsonNode.get("data") : null;

            // Check if "tenantCode" field is present
            String tenantCode = (dataNode != null && dataNode.has("tenantCode")) ? dataNode.get("tenantCode").asText() : null;

            return tenantCode;
        } catch (Exception e) {
        	logger.logError(jsonString, e.getLocalizedMessage());
        	TxnExceptionlogger.techErrTransactions(jsonString + Constants.ERROR_MSG_SEPERATER+ e.getMessage());
            return null;
        }
    }
}
