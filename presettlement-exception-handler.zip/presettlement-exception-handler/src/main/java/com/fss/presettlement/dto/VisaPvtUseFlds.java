package com.fss.presettlement.dto;


import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Visa private user fields
 * @since 2023
 *
 */
@Getter
@Setter
public class VisaPvtUseFlds{
    private String srvInd;
    private String posEnv;
    private String dcci;
}
