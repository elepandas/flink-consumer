package com.fss.presettlement.exception.handlers;

import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.PublisherService;

/**
 * this is custom exception class which is used to handle all sort of Format exception
 */
public class FormatException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public FormatException(String message,String traceId,String host, FormatExceptionsDTO formatExceptionsDTO) throws TechnicalException {
        super(message);
        try {
        	PublisherService.publishMessage(traceId, host, formatExceptionsDTO.getTopicName(), PreSettlementCommonUtilty.getStringOfFormatExceptionsDTO(formatExceptionsDTO));
        }catch(Exception e) {
        	TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
        	techenicalExceptionDTO.setTenantCode(formatExceptionsDTO.getTenantCode());
        	techenicalExceptionDTO.setTransactionRecord(formatExceptionsDTO.getTransactionRecord());
        	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
        	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
        }
        
    }
}
