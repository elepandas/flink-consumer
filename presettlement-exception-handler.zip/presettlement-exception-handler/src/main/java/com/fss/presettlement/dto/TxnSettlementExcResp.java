package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;


/**
 * 
 * This is a DTO class which holds the property details of Transaction settlement exception data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnSettlementExcResp {
	
	private String txnSettlementExcId;
	private String settlementTxnKey;
	private Date processDate;
	private Date businessDate;
	private String tenantCode;
}
