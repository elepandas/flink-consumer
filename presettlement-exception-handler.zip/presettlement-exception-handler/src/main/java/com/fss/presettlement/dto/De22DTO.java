package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details DB details fields
 * @since 2023
 *
 */
@Getter
@Setter
public class De22DTO {

	private String dE22S1;
	private String dE22S2;
	private String dE22S3;
	private String dE22S4;
	private String dE22S5;
	private String dE22S6;
	private String dE22S7;
	private String dE22S8;
	private String dE22S9;
	private String dE22S10;
	private String dE22S11;
	private String dE22S12;
}
