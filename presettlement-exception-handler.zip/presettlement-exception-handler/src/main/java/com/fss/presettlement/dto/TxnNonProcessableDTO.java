package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction non-processable data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnNonProcessableDTO {
    private Long txnNonProcessableId;
    private Date processDate;
    private Date businessDate;
    private String settlementTxnKey;
    private String txnExceptionCode;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;

}
