package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Primary RsvdPriv fields
 * @since 2023
 *
 */
@Getter
@Setter
public class PrimRsvdPriv{
    private String de62Bitmap;
    private String authCharInd;
    private String tranInd;
    private String valCode;
    private String mktSpecDataIdent;
    private String duration;
    private String rsvd;
    private String purchIdent;
    private String gatewayTxnIdent;
    private String merchVrfnValue;
    private String onlRiskAssessRiskScoreRsnCode;
    private String onlRiskAssessCondCde;
    private String prodId;
    private String progIdentifier;
    private String spndQualInd;
    private String acctStatus;
}
