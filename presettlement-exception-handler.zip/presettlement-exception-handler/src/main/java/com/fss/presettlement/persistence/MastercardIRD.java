package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.MastercardIrdDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class MastercardIRD {

	private MastercardIRD() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(MastercardIRD.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on Mastercard_IRD table 
	 * @param connection, interchange_code, region_code
	 * @throws ValidationException 
	 * interchange_region_code
	 */
	
    public static List<MastercardIrdDTO> getMastercardIRD(Connection connection, TransactionDTO transactionDTO) throws ValidationException {
    	logger.logInfo(traceId, "MastercardIRD: getMastercardIRD:Started");
    	List<MastercardIrdDTO> mastercardIrdDTOList = new ArrayList<>();
    	
    	String query = "SELECT product_code,card_program_id,de3_s1, pds0023, interchange_trade_category_code, mcc_excluded,de22_s1,de22_s4,de22_s5,de22_s6,de22_s7, de26_mcc, de40_s1,pds0052_s3, txn_amt, pds0170_s1, timelines, ird FROM mastercard_ird WHERE product_code =? AND card_program_id=? AND de3_s1=? AND pds0023=? AND interchange_trade_category_code=? order by priority";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
        	
        	preparedStatement.setString(1, transactionDTO.getData().getBody().getTxnEnrData().getBinProductCode());
            preparedStatement.setString(2, transactionDTO.getData().getBody().getTxnEnrData().getBinCardProgramIndicator());
            preparedStatement.setString(3, transactionDTO.getData().getBody().getStdFlds().getProcCode());
            preparedStatement.setString(4, transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermType());
            preparedStatement.setString(5, transactionDTO.getData().getBody().getTxnEnrData().getTransactionTradeCategory());
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                	
                	MastercardIrdDTO mastercardIrdDTO = new MastercardIrdDTO();
                	mastercardIrdDTO.setProductCode(resultSet.getString("product_code"));
                	mastercardIrdDTO.setCardProgramId(resultSet.getString("card_program_id"));
                	mastercardIrdDTO.setDe3s1(resultSet.getString("de3_s1"));
                	mastercardIrdDTO.setPds0023(resultSet.getString("pds0023")); 
                	mastercardIrdDTO.setPds0052s3(resultSet.getString("pds0052_s3"));
                	mastercardIrdDTO.setInterchangeTradeCategoryCode(resultSet.getString("interchange_trade_category_code"));
                	mastercardIrdDTO.setMccExcluded(resultSet.getString("mcc_excluded"));
                	mastercardIrdDTO.setDe22s1(resultSet.getString("de22_s1")); 
                	mastercardIrdDTO.setDe22s4(resultSet.getString("de22_s4"));
                	mastercardIrdDTO.setDe22s5(resultSet.getString("de22_s5"));
                	mastercardIrdDTO.setDe22s6(resultSet.getString("de22_s6"));
                	mastercardIrdDTO.setDe22s7(resultSet.getString("de22_s7"));
                	mastercardIrdDTO.setDe26Mcc(resultSet.getString("de26_mcc"));   
                	mastercardIrdDTO.setDe40s1(resultSet.getString("de40_s1")); 
                	mastercardIrdDTO.setTxnAmt(resultSet.getString("txn_amt"));
                	mastercardIrdDTO.setPds0170s1(resultSet.getString("pds0170_s1"));
                	mastercardIrdDTO.setTimelines(resultSet.getString("timelines"));
                	mastercardIrdDTO.setIrd(resultSet.getString("ird"));
                	mastercardIrdDTOList.add(mastercardIrdDTO);
                }
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while getMastercardIRD: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("MastercardIRD:getMastercardIRD:"+transactionDTO.getSettlementTxnKey() + Constants.ERROR_MSG_SEPERATER+ e.getMessage());
            throw new ValidationException("Error in getMastercardIRD: " + e.getMessage());
        }  
        return mastercardIrdDTOList;
    }

}
