package com.fss.presettlement.exception.handlers;

import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.PublisherService;
import com.fss.presettlement.util.TxnExceptionlogger;

public class TechnicalException extends Exception {

	 /**
	 * this is custom exception class which is used to handle all sort of techenical exception
	 */
	private static final long serialVersionUID = 1L;

	public TechnicalException(String message, String traceId, String host, TechenicalExceptionDTO techenicalExceptionDTO) {
	        super(message);
	        try {
	        	 PublisherService.publishMessage(traceId, host, techenicalExceptionDTO.getTopicName(), PreSettlementCommonUtilty.getStringOfTechenicalExceptionsDTO(techenicalExceptionDTO));
	  	       
	        }catch(Exception e) {
	        	TxnExceptionlogger.techErrTransactions(techenicalExceptionDTO.getTransactionRecord()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
	        }   
	
	}
}
