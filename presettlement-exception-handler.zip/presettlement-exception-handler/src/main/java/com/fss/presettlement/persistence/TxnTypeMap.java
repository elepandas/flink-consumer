package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnTypeMap  {

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnTypeMap.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;

	/**
	 * 
	 * This method contains the jdbc operations on TxnTypeMap table 
	 * @param processingCode, txnSourceCode, connection
	 * @exception SQLException 
	 * @throws TechnicalException 
	 */
    public static String getTxnTypeCode(String processingCode, String txnSourceCode, Connection connection) throws SQLException, TechnicalException {
    	  logger.logInfo(traceId, "TxnTypeMap: getTxnTypeCode: Started");

    	  String txnTypeCode = null;
          PreparedStatement preparedStatement = null;
          ResultSet resultSet = null;
    	
          try {

             String sql = "SELECT txn_type_code FROM txn_type_map WHERE processing_code = ? AND txn_source_code = ?";
             preparedStatement = connection.prepareStatement(sql);
             preparedStatement.setString(1, processingCode);
             preparedStatement.setString(2, txnSourceCode);

             resultSet = preparedStatement.executeQuery();
             
             if (resultSet.next()) {
            	 txnTypeCode = resultSet.getString("txn_type_code");
             }
             
             return txnTypeCode;
             
         } catch (SQLException e) {
             logger.logError(traceId, "Error while fetching Txn Type code data at getTxnTypeCode: " + e.getLocalizedMessage());
             TxnExceptionlogger.techErrTransactions("Error while fetching Txn Type code data at getTxnTypeCode " + txnSourceCode + ": " + e.getLocalizedMessage());
             throw new TechnicalException("Error while fetching Txn Type code data at getTxnTypeCode: " + e.getLocalizedMessage());
         } finally {
             if (preparedStatement != null) {
                 try {
                     preparedStatement.close();
                 } catch (SQLException e) {
                     logger.logError(traceId, "Error closing PreparedStatement at getTxnTypeCode: " + e.getLocalizedMessage());
                 }
             }
         }
    }
}
