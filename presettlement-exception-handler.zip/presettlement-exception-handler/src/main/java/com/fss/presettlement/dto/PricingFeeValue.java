package com.fss.presettlement.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PricingFeeValue {
	
	private String ruleCode;
	private String feeType;
	private String settlementKey;
	private String currencyCode;
	private Double percentageValue;
	private BigDecimal fixedAmt;
	private String gtLt;
	private BigDecimal minFeeValue;
	private BigDecimal maxFeeValue;

}
