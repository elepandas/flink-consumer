package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.util.TxnExceptionlogger;

public class CountryTax {
	
	private static CommonLogger logger = new CommonLogger(CountryTax.class);
	
	private CountryTax() {
		
	}
	
	/**
	 * 
	 * This method provides the implementation to get taxCode and tax percentage details from country_tax table by accepting 
	 * traceId, connection and countryCode as input parameters.
	 * @param traceId
	 * @param connection
	 * @param countryCode
	 * @return taxDetails
	 * @throws ValidationException
	 * 
	 */
	public static Map<String, String> getTaxDetails(String traceId, Connection connection, String countryCode) throws ValidationException {
		logger.logDebug(traceId, "CountryTax : getCountryTaxData() - Entered.");
        Map<String, String> taxDetails = new HashMap<>();
        //mysql query to fetch tax_pct and tax_code using country_code as query parameter.
        String query = "select tax_pct, tax_code from country_tax where country_code = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, countryCode);
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                	//set tax_code and tax_pct details into map
                	taxDetails.put(resultSet.getString("tax_code"), resultSet.getString("tax_pct"));
                } else {
                	taxDetails = null;
                }
            }
            logger.logDebug(traceId, "CountryTax : getCountryTaxData() - Returned.");
            return taxDetails;
        } catch (Exception e) {
            logger.logError(traceId, "Error while getCountryTaxData: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(traceId + Constants.ERROR_MSG_SEPERATER+" : "+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in getCountryTaxData: " + e.getMessage());
        } 
		
	}

}
