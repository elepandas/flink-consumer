package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;
/**
 * 
 * This is a DTO class which holds the property details of additional data PDE
 * @since 2023
 *
 */
@Getter
@Setter
public class AddlDataPDE{
    private String tcc;
    private String crdhldrVfnMthd;
    private String ecomInd;
    private String posDataExtndCondCode;
    private String onBehalfSrvs;
    private String pmntTxnTypeInd;
    private String pinSrvCode;
    private String avsResp;
    private String cvc2Resp;
    private String installmentPmntTerms;
    private String partialApprvlInd;
}
