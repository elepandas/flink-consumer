package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction non-processable data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TerminalPermittedCurrencyDTO {

	private String terminalUid;
    private String terminalPermittedCurrencyId;
    private String currencyCode;
    private String currencyIso;
	
}
