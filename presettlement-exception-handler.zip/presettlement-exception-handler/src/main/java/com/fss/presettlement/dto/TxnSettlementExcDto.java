package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction settlement exception data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnSettlementExcDto {

	private long txnSettlementExcId;
	private String settlementTxnKey;
	private Date processDate;
	private Date businessDate;
	private String pgPaymentId;
	private String merchantTrackId;
	private String discriminant;
	private String txnDatetime;
	private String txnAmt;
	private String acquirerInstitutionId;
	private String issuerInstitutionId;
	private String primaryAccountNo;
	private String merchantId;
	private String storeId;
	private String terminalId;
	private String paymentCode;
	private String txnSourceCode;
	private String processingCode;
	private String txnTypeCode;
	private String responseCode;
	private String subChannel;
	private String subChannelRequestId;
	private String txnData;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;

}
