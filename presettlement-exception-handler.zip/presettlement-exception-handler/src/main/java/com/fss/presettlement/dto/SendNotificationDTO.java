package com.fss.presettlement.dto;

import lombok.Data;
import org.springframework.stereotype.Component;
import java.util.Map;

/**
 * 
 * This is a DTO class which holds the property details of Send Notification fields
 * @since 2023
 *
 */
@Data
@Component
public class SendNotificationDTO {

    private String eventCode;
    private String tenantCode;
    private String notificationMode;
    private String recipient;
    private String notificationSource;
    private Map<String, String> templateParametersMap;
}
