package com.fss.presettlement.validator.nonprocessable;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains the method implementations which is used for conditional checks for incoming transaction data
 * @since 2023
 *
 */
public class ConditionalTrxValidator {
	
	private ConditionalTrxValidator() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(ConditionalTrxValidator.class);
	
	/**
	 * 
	 * This method applies conditional checks on incoming transactions based on specifications.
	 * @return String (SUCCESS or error message).
	 * @throws ValidationException 
	 * 
	 */
	public static String conditionalCheck(TransactionDTO transactionDTO) throws ValidationException {
	 	
        return paymentMethodCodeSpecCheck(transactionDTO);
    }
 
	/**
	 * 
	 * This method provides implementation of logic to verify payment Method Code specific
	 *  conditional checks for incoming transactions.
	 * @return String (SUCCESS or error message).
	 * @throws ValidationException 
	 * 
	 */
	private static String paymentMethodCodeSpecCheck(TransactionDTO transactionDTO) throws ValidationException {
		logger.logInfo(traceId, "conditionalCheck : paymentMethodCodeSpecCheck :Started");
		
		String flag = Constants.SUCCESS;
		
		try {
			
			/**
			 * 
			 * This check verifies whether incoming transaction's PaymentCodes is if type credit/debit/prepaid or not based on that
			 *  it performs conditional checks for incoming transactions properties.
			 * @return String (SUCCESS or error message).
			 * 
			 */		
			if(applicablePaymentCodes(transactionDTO.getData().getPaymentCode())) {
				
				logger.logInfo(traceId, "conditionalCheck : paymentMethodCodeSpecCheck :trx satisfies paymentCode check");
				
				/**
				 * This condition check validates SecBitMap property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getSecBitMap() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getSecBitMap(),16)) {
						return "Invalid secBitMap: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getSecBitMap())) {
						return "Invalid secBitMap: these characters are not allowed";
					}
				}else {
					return "Invalid secBitMap: mandatory data not present";
				}
				
				/**
				 * This condition check validates Pan property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getPan() != null && (!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getPan(),80))) {
						return "Invalid pan: character count is invalid";
					 /*
						 * else if(!alphaNumericValidater(pan)) { return
						 * "Invalid pan: these characters are not allowed"; }
						 */
				}
				
				/**
				 * This condition check validates Stan property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getStan() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getStan(),6)) {
						return "Invalid stan: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getStan())) {
						return "Invalid stan: these characters are not allowed";
					}
				}else {
					return "Invalid Stan: mandatory data not present";
				}
				
				/**
				 * This condition check validates PtSvcEntryMde property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getPtSvcEntryMde() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getPtSvcEntryMde(),4)) {
						return "Invalid ptSvcEntryMde: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getPtSvcEntryMde())) {
						return "Invalid ptSvcEntryMde: these characters are not allowed";
					}
				}else {
					return "Invalid PtSvcEntryMde: PtSvcEntryMde data not present";
				}
				
				/**
				 * This condition check validates CrdSeqNum property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdSeqNum() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdSeqNum(),4)) {
						return "Invalid crdSeqNum: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdSeqNum())) {
						return "Invalid crdSeqNum: these characters are not allowed";
					}
				}else {
					return "Invalid crdSeqNum: CrdSeqNum data not present";
				}
				
				/**
				 * This condition check validates PtSvcCondCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getPtSvcCondCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getPtSvcCondCode(),3)) {
						return "Invalid ptSvcCondCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getPtSvcCondCode())) {
						return "Invalid ptSvcCondCode: these characters are not allowed";
					}
				}else {
					return "Invalid ptSvcCondCode: PtSvcCondCode data not present";
				}
				
				/**
				 * This condition check validates MsgRsnCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getMsgRsnCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getMsgRsnCode(),4)) {
						return "Invalid msgRsnCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getMsgRsnCode())) {
						return "Invalid msgRsnCode: these characters are not allowed";
					}
				}else {
					return "Invalid msgRsnCode: MsgRsnCode data not present";
				}
				
				/**
				 * This condition check validates CrdAccptBusCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptBusCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptBusCode(),4)) {
						return "Invalid crdAccptBusCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptBusCode())) {
						return "Invalid crdAccptBusCode: these characters are not allowed";
					}
				}else {
					return "Invalid CrdAccptBusCode: CrdAccptBusCode data not present";
				}
				
				
				/**
				 * This condition check validates ApprvCdeLgth property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getApprvCdeLgth() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getApprvCdeLgth(),1)) {
						return "Invalid apprvCdeLgth: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getApprvCdeLgth())) {
						return "Invalid apprvCdeLgth: these characters are not allowed";
					}
				}else {
					return "Invalid ApprvCdeLgth: ApprvCdeLgth data not present";
				}
				
				/**
				 * This condition check validates OrigAmts property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if( transactionDTO.getData().getBody().getStdFlds().getOrigAmts() != null) {
					if(!lengthValidater( transactionDTO.getData().getBody().getStdFlds().getOrigAmts(),24)) {
						return "Invalid origAmts: character count is invalid";
					}else if(!numericValidater( transactionDTO.getData().getBody().getStdFlds().getOrigAmts())) {
						return "Invalid origAmts: these characters are not allowed";
					}
				}else {
					return "Invalid OrigAmts: OrigAmts data not present";
				}
				
				/**
				 * This condition check validates AcqInstIdCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAcqInstIdCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAcqInstIdCode(),11)) {
						return "Invalid acqInstIdCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAcqInstIdCode())) {
						return "Invalid acqInstIdCode: these characters are not allowed";
					}
				}else {
					return "Invalid AcqInstIdCode: AcqInstIdCode data not present";
				}
				
				/**
				 * This condition check validates ForwdInstIdCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getForwdInstIdCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getForwdInstIdCode(),11)) {
						return "Invalid forwdInstIdCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getForwdInstIdCode())) {
						return "Invalid forwdInstIdCode: these characters are not allowed";
					}
				}else {
					return "Invalid ForwdInstIdCode: ForwdInstIdCode data not present";
				}
				
				/**
				 * This condition check validates ApprvCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if( transactionDTO.getData().getBody().getStdFlds().getApprvCode() != null) {
					if(!lengthValidater( transactionDTO.getData().getBody().getStdFlds().getApprvCode(),6)) {
						return "Invalid apprvCode: character count is invalid";
					}else if(!alphaNumericValidater( transactionDTO.getData().getBody().getStdFlds().getApprvCode())) {
						return "Invalid apprvCode: these characters are not allowed";
					}
				}else {
					return "Invalid apprvCode: ApprvCode data not present";
				}
				
				/**
				 * This condition check validates ServiceCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getServiceCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getServiceCode(),3)) {
						return "Invalid serviceCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getServiceCode())) {
						return "Invalid serviceCode: these characters are not allowed";
					}
				}else {
					return "Invalid ServiceCode: ServiceCode data not present";
				}
				
				/**
				 * This condition check validates CrdAccptIdentificationCde property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptIdentificationCde() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptIdentificationCde(),15)) {
						return "Invalid crdAccptIdentificationCde: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptIdentificationCde())) {
						return "Invalid crdAccptIdentificationCde: these characters are not allowed";
					}
				}else {
					return "Invalid CrdAccptIdentificationCde: CrdAccptIdentificationCde data not present";
				}
				
				/**
				 * This condition check validates PostalCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getPostalCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getPostalCode(),10)) {
						return "Invalid postalCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getPostalCode())) {
						return "Invalid postalCode: these characters are not allowed";
					}
				}else {
					return "Invalid PostalCode: PostalCode data not present";
				}
				
				/**
				 * This condition check validates Region property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getRegion() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getRegion(),3)) {
						return "Invalid region: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getRegion())) {
						return "Invalid region: these characters are not allowed";
					}
				}else {
					return "Invalid Region: Region data not present";
				}
				
				/**
				 * This condition check validates CntryCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getCntryCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getCntryCode(),3)) {
						return "Invalid cntryCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getCntryCode())) {
						return "Invalid cntryCode: these characters are not allowed";
					}
				}else {
					return "Invalid CntryCode: CntryCode data not present";
				}
				
				/*
				 * String addlRespData =
				 * transactionDTO.getData().getBody().getStdFlds().getAddlRespData();
				 * if(cntryCode != null) { if(!lengthValidater(cntryCode,3)) { return
				 * "Invalid postalCode: character count is invalid"; }else
				 * if(!alphaNumericValidater(cntryCode)) { return
				 * "Invalid postalCode: these characters are not allowed"; } }
				 */
				
				/**
				 * This condition check validates RsnCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRsnCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRsnCode(),1)) {
						return "Invalid rsnCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRsnCode())) {
						return "Invalid rsnCode: these characters are not allowed";
					}
				}else {
					return "Invalid RsnCode: RsnCode data not present";
				}
				
				/**
				 * This condition check validates AddrVrfnRsltCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddrVrfnRsltCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddrVrfnRsltCode(),1)) {
						return "Invalid addrVrfnRsltCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddrVrfnRsltCode())) {
						return "Invalid addrVrfnRsltCode: these characters are not allowed";
					}
				}else {
					return "Invalid AddrVrfnRsltCode: AddrVrfnRsltCode data not present";
				}
				
				
				/**
				 * This condition check validates AddnlTknRespInfo property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddnlTknRespInfo() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddnlTknRespInfo(),1)) {
						return "Invalid addnlTknRespInfo: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getAddnlTknRespInfo())) {
						return "Invalid addnlTknRespInfo: these characters are not allowed";
					}
				}else {
					return "Invalid AddnlTknRespInfo: AddnlTknRespInfo data not present";
				}
				
				/**
				 * This condition check validates ExtnSTIPRsnCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getExtnSTIPRsnCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getExtnSTIPRsnCode(),1)) {
						return "Invalid extnSTIPRsnCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getExtnSTIPRsnCode())) {
						return "Invalid extnSTIPRsnCode: these characters are not allowed";
					}
				}else {
					return "Invalid ExtnSTIPRsnCode: ExtnSTIPRsnCode data not present";
				}
				
				/**
				 * This condition check validates CvvRsltsCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvvRsltsCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvvRsltsCode(),1)) {
						return "Invalid cvvRsltsCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvvRsltsCode())) {
						return "Invalid cvvRsltsCode: these characters are not allowed";
					}
				}else {
					return "Invalid CvvRsltsCode: CvvRsltsCode data not present";
				}
				
				/**
				 * This condition check validates PacmDiversionLvlCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionLvlCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionLvlCode(),2)) {
						return "Invalid pacmDiversionLvlCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionLvlCode())) {
						return "Invalid pacmDiversionLvlCode: these characters are not allowed";
					}
				}else {
					return "Invalid PacmDiversionLvlCode: PacmDiversionLvlCode data not present";
				}
				
				/**
				 * This condition check validates PacmDiversionRsnCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionRsnCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionRsnCode(),1)) {
						return "Invalid pacmDiversionRsnCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPacmDiversionRsnCode())) {
						return "Invalid pacmDiversionRsnCode: these characters are not allowed";
					}
				}else {
					return "Invalid PacmDiversionRsnCode: PacmDiversionRsnCode data not present";
				}
				
				/**
				 * This condition check validates CrdAuthenRsltsCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCrdAuthenRsltsCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCrdAuthenRsltsCode(),1)) {
						return "Invalid crdAuthenRsltsCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCrdAuthenRsltsCode())) {
						return "Invalid crdAuthenRsltsCode: these characters are not allowed";
					}
				}else {
					return "Invalid CrdAuthenRsltsCode: CrdAuthenRsltsCode data not present";
				}
				
				/**
				 * This condition check validates Cvv2RsltCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvv2RsltCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvv2RsltCode(),1)) {
						return "Invalid cvv2RsltCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvv2RsltCode())) {
						return "Invalid cvv2RsltCode: these characters are not allowed";
					}
				}else {
					return "Invalid Cvv2RsltCode: Cvv2RsltCode data not present";
				}
				
				/**
				 * This condition check validates CavvRsltsCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCavvRsltsCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCavvRsltsCode(),1)) {
						return "Invalid cavvRsltsCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCavvRsltsCode())) {
						return "Invalid cavvRsltsCode: these characters are not allowed";
					}
				}else {
					return "Invalid CavvRsltsCode: CavvRsltsCode data not present";
				}
				
				/**
				 * This condition check validates RespRsnCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRespRsnCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRespRsnCode(),4)) {
						return "Invalid respRsnCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getRespRsnCode())) {
						return "Invalid respRsnCode: these characters are not allowed";
					}
				}else {
					return "Invalid RespRsnCode: RespRsnCode data not present";
				}
				
				/**
				 * This condition check validates PanL4DFR property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPanL4DFR() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPanL4DFR(),4)) {
						return "Invalid panL4DFR: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getPanL4DFR())) {
						return "Invalid panL4DFR: these characters are not allowed";
					}
				}else {
					return "PanL4DFR PanL4DFR: PanL4DFR data not present";
				}
				
				/**
				 * This condition check validates Track1Data property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getTrack1Data() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getTrack1Data(),76)) {
						return "Invalid track1Data: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getTrack1Data())) {
						return "Invalid track1Data: these characters are not allowed";
					}
				}else {
					return "Invalid Track1Data: Track1Data not present";
				}
				
				/**
				 * This condition check validates AmtFees property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAmtFees() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAmtFees(),204)) {
						return "Invalid amtFees: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAmtFees())) {
						return "Invalid amtFees: these characters are not allowed";
					}
				}else {
					return "Invalid AmtFees: AmtFees data not present";
				}
				
				/*
				 * String addlDataPDE =
				 * transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE();
				 * if(addlDataPDE != null) { if(!lengthValidater(addlDataPDE,999)) { return
				 * "Invalid addlDataPDE: character count is invalid"; }else
				 * if(!alphaNumericValidater(addlDataPDE)) { return
				 * "Invalid addlDataPDE: these characters are not allowed"; } }
				 */
				
				/**
				 * This condition check validates Tcc property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getTcc() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getTcc(),1)) {
						return "Invalid tcc: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getTcc())) {
						return "Invalid tcc: these characters are not allowed";
					}
				}else {
					return "Invalid tcc: tcc data not present";
				}
				
				
				/**
				 * This condition check validates CrdhldrVfnMthd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCrdhldrVfnMthd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCrdhldrVfnMthd(),1)) {
						return "Invalid crdhldrVfnMthd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCrdhldrVfnMthd())) {
						return "Invalid crdhldrVfnMthd: these characters are not allowed";
					}
				}else {
					return "Invalid crdhldrVfnMthd: crdhldrVfnMthd data not present";
				}
				
				/**
				 * This condition check validates EcomInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getEcomInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getEcomInd(),7)) {
						return "Invalid ecomInd: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getEcomInd())) {
						return "Invalid ecomInd: these characters are not allowed";
					}
				}else {
					return "Invalid ecomInd: ecomInd data not present";
				}
				
				/**
				 * This condition check validates PosDataExtndCondCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPosDataExtndCondCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPosDataExtndCondCode(),5)) {
						return "Invalid posDataExtndCondCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPosDataExtndCondCode())) {
						return "Invalid posDataExtndCondCode: these characters are not allowed";
					}
				}else {
					return "Invalid posDataExtndCondCode: posDataExtndCondCode data not present";
				}
				
				/**
				 * This condition check validates OnBehalfSrvs property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getOnBehalfSrvs() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getOnBehalfSrvs(),40)) {
						return "Invalid onBehalfSrvs: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getOnBehalfSrvs())) {
						return "Invalid onBehalfSrvs: these characters are not allowed";
					}
				}else {
					return "Invalid onBehalfSrvs: onBehalfSrvs data not present";
				}
				
				/**
				 * This condition check validates PmntTxnTypeInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPmntTxnTypeInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPmntTxnTypeInd(),3)) {
						return "Invalid pmntTxnTypeInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPmntTxnTypeInd())) {
						return "Invalid pmntTxnTypeInd: these characters are not allowed";
					}
				}else {
					return "Invalid pmntTxnTypeInd: pmntTxnTypeInd data not present";
				}
				
				/**
				 * This condition check validates PinSrvCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPinSrvCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPinSrvCode(),2)) {
						return "Invalid pinSrvCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPinSrvCode())) {
						return "Invalid pinSrvCode: these characters are not allowed";
					}
				}else {
					return "Invalid pinSrvCode: pinSrvCode data not present";
				}
				
				
				/**
				 * This condition check validates AvsResp property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getAvsResp() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getAvsResp(),1)) {
						return "Invalid avsResp: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getAvsResp())) {
						return "Invalid avsResp: these characters are not allowed";
					}
				}else {
					return "Invalid avsResp: avsResp data not present";
				}
				
				/**
				 * This condition check validates Cvc2Resp property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCvc2Resp() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCvc2Resp(),1)) {
						return "Invalid cvc2Resp: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCvc2Resp())) {
						return "Invalid cvc2Resp: these characters are not allowed";
					}
				}else {
					return "Invalid cvc2Resp: cvc2Resp data not present";
				}
				
				/**
				 * This condition check validates InstallmentPmntTerms property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getInstallmentPmntTerms() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getInstallmentPmntTerms(),10)) {
						return "Invalid installmentPmntTerms: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getInstallmentPmntTerms())) {
						return "Invalid installmentPmntTerms: these characters are not allowed";
					}
				}else {
					return "Invalid installmentPmntTerms: installmentPmntTerms data not present";
				}
				
				/**
				 * This condition check validates PartialApprvlInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPartialApprvlInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPartialApprvlInd(),10)) {
						return "Invalid partialApprvlInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getPartialApprvlInd())) {
						return "Invalid partialApprvlInd: these characters are not allowed";
					}
				}else {
					return "Invalid partialApprvlInd: partialApprvlInd data not present";
				}
				
				/**
				 * This condition check validates AuthLifeCycleCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getAuthLifeCycleCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getAuthLifeCycleCode(),3)) {
						return "Invalid authLifeCycleCode: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getAuthLifeCycleCode())) {
						return "Invalid authLifeCycleCode: these characters are not allowed";
					}
				}else {
					return "Invalid authLifeCycleCode: authLifeCycleCode data not present";
				}
				
				/*
				 * String visaAddnlPOSInfo =
				 * transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo();
				 * if(visaAddnlPOSInfo != null) { if(!lengthValidater(authLifeCycleCode,3)) {
				 * return "Invalid authLifeCycleCode: character count is invalid"; }else
				 * if(!numericValidater(authLifeCycleCode)) { return
				 * "Invalid authLifeCycleCode: these characters are not allowed"; } }
				 */
				
				
				/**
				 * This condition check validates TermType property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermType() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermType(),1)) {
						return "Invalid termType: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermType())) {
						return "Invalid termType: these characters are not allowed";
					}
				}else {
					return "Invalid termType: termType data not present";
				}
				
				/**
				 * This condition check validates TermEntryCapability property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermEntryCapability() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermEntryCapability(),1)) {
						return "Invalid termEntryCapability: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermEntryCapability())) {
						return "Invalid termEntryCapability: these characters are not allowed";
					}
				}else {
					return "Invalid termEntryCapability: termEntryCapability data not present";
				}
				
				/**
				 * This condition check validates ChipCondCodes property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCondCodes() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCondCodes(),1)) {
						return "Invalid chipCondCodes: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCondCodes())) {
						return "Invalid chipCondCodes: these characters are not allowed";
					}
				}else {
					return "Invalid chipCondCodes: chipCondCodes data not present";
				}
				
				/**
				 * This condition check validates SplCondInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getSplCondInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getSplCondInd(),1)) {
						return "Invalid splCondInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getSplCondInd())) {
						return "Invalid splCondInd: these characters are not allowed";
					}
				}else {
					return "Invalid splCondInd: splCondInd data not present";
				}
				
				/**
				 * This condition check validates ChipTxnInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipTxnInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipTxnInd(),1)) {
						return "Invalid chipTxnInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipTxnInd())) {
						return "Invalid chipTxnInd: these characters are not allowed";
					}
				}else {
					return "Invalid chipTxnInd: chipTxnInd data not present";
				}
				
				/**
				 * This condition check validates ChipCrdAuthRelInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCrdAuthRelInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCrdAuthRelInd(),1)) {
						return "Invalid chipCrdAuthRelInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCrdAuthRelInd())) {
						return "Invalid chipCrdAuthRelInd: these characters are not allowed";
					}
				}else {
					return "Invalid chipCrdAuthRelInd: chipCrdAuthRelInd data not present";
				}
				
				
				/**
				 * This condition check validates MotoEcomInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getMotoEcomInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getMotoEcomInd(),2)) {
						return "Invalid motoEcomInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getMotoEcomInd())) {
						return "Invalid motoEcomInd: these characters are not allowed";
					}
				}else {
					return "Invalid motoEcomInd: motoEcomInd data not present";
				}
				
				/**
				 * This condition check validates CrdhldrIDMthdInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getCrdhldrIDMthdInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getCrdhldrIDMthdInd(),1)) {
						return "Invalid crdhldrIDMthdInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getCrdhldrIDMthdInd())) {
						return "Invalid crdhldrIDMthdInd: these characters are not allowed";
					}
				}else {
					return "Invalid crdhldrIDMthdInd: crdhldrIDMthdInd data not present";
				}
				
				/**
				 * This condition check validates AddnlAuthInds property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getAddnlAuthInds() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getAddnlAuthInds(),1)) {
						return "Invalid addnlAuthInds: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getAddnlAuthInds())) {
						return "Invalid addnlAuthInds: these characters are not allowed";
					}
				}else {
					return "Invalid addnlAuthInds: addnlAuthInds data not present";
				}
				
				/**
				 * This condition check validates TxnDestInstIdentCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getTxnDestInstIdentCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getTxnDestInstIdentCode(),11)) {
						return "Invalid txnDestInstIdentCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getTxnDestInstIdentCode())) {
						return "Invalid TxnDestInstIdentCode: these characters are not allowed";
					}
				}else {
					return "Invalid TxnDestInstIdentCode: TxnDestInstIdentCode data not present";
				}
				
				/**
				 * This condition check validates rigInstIdentCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getTxnOrigInstIdentCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getTxnOrigInstIdentCode(),11)) {
						return "Invalid txnOrigInstIdentCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getTxnOrigInstIdentCode())) {
						return "Invalid txnOrigInstIdentCode: these characters are not allowed";
					}
				}else {
					return "Invalid txnOrigInstIdentCode: addnlAuthInds data not present";
				}
				
				/**
				 * This condition check validates RcvngInstIdentCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getRcvngInstIdentCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getRcvngInstIdentCode(),11)) {
						return "Invalid rcvngInstIdentCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getRcvngInstIdentCode())) {
						return "Invalid rcvngInstIdentCode: these characters are not allowed";
					}
				}else {
					return "Invalid rcvngInstIdentCode: addnlAuthInds data not present";
				}
				
				/**
				 * This condition check validates SrvInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getSrvInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getSrvInd(),24)) {
						return "Invalid srvInd: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getSrvInd())) {
						return "Invalid srvInd: these characters are not allowed";
					}
				}else {
					return "Invalid srvInd: srvInd data not present";
				}
				
				/**
				 * This condition check validates PosEnv property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getPosEnv() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getPosEnv(),1)) {
						return "Invalid posEnv: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getVisaPvtUseFlds().getPosEnv())) {
						return "Invalid posEnv: these characters are not allowed";
					}
				}else {
					return "Invalid posEnv: posEnv data not present";
				}
				
				/**
				 * This condition check validates OrgRrn property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getOrgRrn() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getOrgRrn(),12)) {
						return "Invalid orgRrn: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getStdFlds().getOrgRrn())) {
						return "Invalid orgRrn: these characters are not allowed";
					}
				}else {
					return "Invalid orgRrn: orgRrn data not present";
				}
				
				/**
				 * This condition check validates AuthSrc property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getAuthSrc() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getAuthSrc(),1)) {
						return "Invalid authSrc: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getAuthSrc())) {
						return "Invalid authSrc: these characters are not allowed";
					}
				}else {
					return "Invalid authSrc: authSrc data not present";
				}
				
				/**
				 * This condition check validates TranID property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getTranID() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getTranID(),15)) {
						return "Invalid tranID: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getTranID())) {
						return "Invalid tranID: these characters are not allowed";
					}
				}else {
					return "Invalid tranID: tranID data not present";
				}
				
				/**
				 * This condition check validates AuthCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getAuthCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getAuthCode(),6)) {
						return "Invalid authCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getAuthCode())) {
						return "Invalid authCode: these characters are not allowed";
					}
				}else {
					return "Invalid authCode: authCode data not present";
				}
				
				
				/**
				 * This condition check validates RqstRcvdTime property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getRqstRcvdTime() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getRqstRcvdTime(),6)) {
						return "Invalid rqstRcvdTime: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getRqstRcvdTime())) {
						return "Invalid rqstRcvdTime: these characters are not allowed";
					}
				}else {
					return "Invalid rqstRcvdTime: authCode data not present";
				}
				
				/**
				 * This condition check validates RqstSentTime property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getRqstSentTime() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getRqstSentTime(),6)) {
						return "Invalid rqstSentTime: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getRqstSentTime())) {
						return "Invalid rqstSentTime: these characters are not allowed";
					}
				}else {
					return "Invalid rqstSentTime: rqstSentTime data not present";
				}
				
				/**
				 * This condition check validates RespRcvdTime property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getRespRcvdTime() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getRespRcvdTime(),6)) {
						return "Invalid respRcvdTime: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getRespRcvdTime())) {
						return "Invalid respRcvdTime: these characters are not allowed";
					}
				}else {
					return "Invalid respRcvdTime: rqstSentTime data not present";
				}
				
				/**
				 * This condition check validates RespSentTime property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getRespSentTime() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getRespSentTime(),6)) {
						return "Invalid respSentTime: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getRespSentTime())) {
						return "Invalid respSentTime: these characters are not allowed";
					}
				}else {
					return "Invalid respSentTime: respSentTime data not present";
				}
					
				/**
				 * This condition check validates BrandID property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getBrandID() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getBrandID(),16)) {
						return "Invalid brandID: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getBrandID())) {
						return "Invalid brandID: these characters are not allowed";
					}
				}else {
					return "Invalid brandID: brandID data not present";
				}
				
				/**
				 * This condition check validates LangID property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getLangID() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getLangID(),16)) {
						return "Invalid langID: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getLangID())) {
						return "Invalid langID: these characters are not allowed";
					}
				}else {
					return "Invalid langID: langID data not present";
				}
				
				/**
				 * This condition check validates MerchSuccResURL property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getMerchSuccResURL() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchSuccResURL(),255)) {
						return "Invalid merchSuccResURL: character count is invalid";
					}else if(!ansValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchSuccResURL())) {
						return "Invalid merchSuccResURL: these characters are not allowed";
					}
				}else {
					return "Invalid merchSuccResURL: merchSuccResURL data not present";
				}
				
				/**
				 * This condition check validates MerchFailResURL property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getMerchFailResURL() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchFailResURL(),255)) {
						return "Invalid merchFailResURL: character count is invalid";
					}else if(!ansValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchFailResURL())) {
						return "Invalid merchFailResURL: these characters are not allowed";
					}
				}else {
					return "Invalid merchFailResURL: merchFailResURL data not present";
				}
				
				/**
				 * This condition check validates MerchPmntRespTim property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getMerchPmntRespTim() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchPmntRespTim(),10)) {
						return "Invalid merchPmntRespTim: character count is invalid";
					}else if(!numericValidater(transactionDTO.getData().getBody().getAddnlFlds().getMerchPmntRespTim())) {
						return "Invalid merchPmntRespTim: these characters are not allowed";
					}
				}else {
					return "Invalid merchPmntRespTim: merchPmntRespTim data not present";
				}
				
				/**
				 * This condition check validates UcafInd property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getUcafInd() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getUcafInd(),28)) {
						return "Invalid ucafInd: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getUcafInd())) {
						return "Invalid ucafInd: these characters are not allowed";
					}
				}else {
					return "Invalid ucafInd: ucafInd data not present";
				}
				
				/**
				 * This condition check validates Eci property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getEci() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getEci(),2)) {
						return "Invalid eci: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getEci())) {
						return "Invalid eci: these characters are not allowed";
					}
				}else {
					return "Invalid eci: eci data not present";
				}
				
				/**
				 * This condition check validates Sli property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getSli() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getSli(),3)) {
						return "Invalid sli: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getSli())) {
						return "Invalid sli: these characters are not allowed";
					}
				}else {
					return "Invalid sli: sli data not present";
				}
				
				/**
				 * This condition check validates RefundType property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getRefundType() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getRefundType(),20)) {
						return "Invalid refundType: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getRefundType())) {
						return "Invalid refundType: these characters are not allowed";
					}
				}else {
					return "Invalid refundType: refundType data not present";
				}
				
				/**
				 * This condition check validates BalanceAmount property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(Double.toString(transactionDTO.getData().getBody().getAddnlFlds().getBalanceAmount()) != null) {
					if(!lengthValidater(Double.toString(transactionDTO.getData().getBody().getAddnlFlds().getBalanceAmount()),12)) {
						return "Invalid balanceAmount: character count is invalid";
					} /*
						 * else if(!alphaNumericValidater(balanceAmount)) { return
						 * "Invalid balanceAmount: these characters are not allowed"; }
						 */
				}else {
					return "Invalid balanceAmount: balanceAmount data not present";
				}
				
				/**
				 * This condition check validates CardCountryCode property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getCardCountryCode() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getCardCountryCode(),3)) {
						return "Invalid cardCountryCode: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getCardCountryCode())) {
						return "Invalid cardCountryCode: these characters are not allowed";
					}
				}else {
					return "Invalid cardCountryCode: balanceAmount data not present";
				}
				
				/**
				 * This condition check validates MskCardNum property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getMskCardNum() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getMskCardNum(),19)) {
						return "Invalid mskCardNum: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getMskCardNum())) {
						return "Invalid mskCardNum: these characters are not allowed";
					}
				}
				
				/**
				 * This condition check validates Ip property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getAddnlFlds().getIp() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getAddnlFlds().getIp(),40)) {
						return "Invalid ip: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getIp())) {
						return "Invalid ip: these characters are not allowed";
					}
				}
				
				/**
				 * This condition check validates Pan property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getPan() != null && (!lengthValidater(transactionDTO.getData().getPan(),80))) {
						return "Invalid dataPan: character count is invalid";
					
				}
				
				/**
				 * This condition check validates Ip property of incoming transaction, 
				 * it takes care of validating length and allowed characters.
				 * @returns respective validation message.
				 */
				if(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc() != null) {
					if(!lengthValidater(transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getCity()+
							transactionDTO.getData().getBody().getStdFlds().getCrdAccptNameLoc().getName() 
							,40)) {
						return "Invalid ip: character count is invalid";
					}else if(!alphaNumericValidater(transactionDTO.getData().getBody().getAddnlFlds().getIp())) {
						return "Invalid ip: these characters are not allowed";
					}
				}
				
			}
			
		} catch (Exception e) {
		    logger.logError(traceId, "Error generating settlement key using Snowflake: " + e.getMessage());
		    TxnExceptionlogger.techErrTransactions( Constants.ERROR_MSG_SEPERATER +  e.getMessage());
		    throw new ValidationException("Error generating settlement key using Snowflake: " + e.getMessage());
		}
		
		logger.logInfo(traceId, "conditionalCheck : paymentMethodCodeSpecCheck :completed");
		return flag;
		
	}
	
	private static boolean applicablePaymentCodes(String paymentCode) {
	    return paymentCode != null && (paymentCode.equalsIgnoreCase(Constants.CREDIT)
	            || paymentCode.equalsIgnoreCase(Constants.DEBIT)
	            || paymentCode.equalsIgnoreCase(Constants.PREPAID));
	}
	
	private static boolean lengthValidater(String property, int length) {
		logger.logInfo(traceId, "conditionalCheck : lengthValidated");
		return (property.length() > 0 && property.length() <= length);
		
	}
	
	private static boolean alphaNumericValidater(String property) {
		logger.logInfo(traceId, "conditionalCheck : alphabet and Number Validated");
	    return property.matches("^[a-zA-Z0-9]+$");
	}

	private static boolean numericValidater(String property) {
		logger.logInfo(traceId, "conditionalCheck : number Validated");
	    return property.matches("^[0-9]+$");
	}

	private static boolean ansValidater(String property) {
		logger.logInfo(traceId, "conditionalCheck : alphabet number and special characters Validated");
	    return property.matches("^[a-zA-Z0-9\\p{Punct}]+$");
	}
	
}
