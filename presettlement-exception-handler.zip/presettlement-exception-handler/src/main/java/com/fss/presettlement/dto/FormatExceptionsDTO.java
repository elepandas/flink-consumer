package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details Format Exceptions details fields
 * @since 2023
 *
 */
@Getter
@Setter
public class FormatExceptionsDTO {
	
	private String identifier;
    private Date currentDate;
    private String transactionRecord;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;
    private String topicName;

}
