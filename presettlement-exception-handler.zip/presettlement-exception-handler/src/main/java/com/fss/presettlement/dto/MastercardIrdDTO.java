package com.fss.presettlement.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Visa private user fields
 * @since 2023
 *
 */
@Getter
@Setter
public class MastercardIrdDTO {

    private Long mastercardIrdId;
    private String status;
    private BigDecimal priority;
    private String ird;
    private String description;
    private String interchangeProductCategoryCode;
    private String acquirerRegionCode;
    private String cardProgramId;
    private String productCode;
    private String de3s1;
    private String cabProgram;
    private String timelines;
    private String de26Mcc;
    private String mccExcluded;
    private String de22s1;
    private String de22s4;
    private String de22s5;
    private String de22s6;
    private String de22s7;
    private String approveCode;
    private String traceId;
    private String de40s1;
    private String pds0023;
    private String pds0052s3;
    private String txnAmt;
    private String programRegistrationId;
    private String pds0170s1;
    private String cardAcceptorUrl;
    private String mastercardAssignedId;
    private String additionalCriteria;
    private String notes;
    private String manualReference;
    private String interchangeTradeCategoryCode;
    private String issuerRegionCode;
    private String fundingAccountInformation;
    private String countryCode;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;
}
