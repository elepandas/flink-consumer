package com.fss.presettlement.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnFeeCalculationDto {
	
	private String settlementKey;
	private String pricingPlanId;
	private BigDecimal amount;
	private String currency;
	private String merchantType;
	private String acquiringType;
	private String destination;
	private String transactionType;
	private String multiCurrencyCategory;
	private String interchange;
	private String paymentMethod;
	private String smsIndicator;
	private String productCategory;
	private String deliveryChannel;
	private String transactionResponse;
	private String captureMode;

}
