package com.fss.presettlement.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClient;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.BinInfoDto;

public class BinDetailsExtractor {

	private BinDetailsExtractor() {}
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(BinDetailsExtractor.class);
	
	@Value("${property.interchange.api.uri}")
    private static String interchangeHostUrl;
	
	public static BinInfoDto  getBinData(String interchangeCardNumber) throws TechnicalException {
		logger.logInfo(traceId, "TechnicalException getBinData:Started");
		BinInfoDto binInfoDto = null;
		try {
			///acq/interchange-requestbinservice
			//acq/interchange-requestbinservice/getBinRangeInformation?interchangeCardNumber=6522323032555734
			//Service call using web client to fetch current bod details
			binInfoDto = WebClient.create().get()
												.uri(interchangeHostUrl+Constants.FETCH_BIN_INFO+"?"+Constants.INTER_CARD_NUM +"="+interchangeCardNumber)
												.retrieve()
												.bodyToMono(BinInfoDto.class).block();	
		} catch (Exception e) {
			logger.logError(traceId, "Error at BinDetailsExtractor and error message is: " + e.getLocalizedMessage());
		    TxnExceptionlogger.techErrTransactions("Error at BinDetailsExtractor and error message is"+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		    throw new TechnicalException("Error at BinDetailsExtractor and error message is: " + e.getLocalizedMessage());
		}
		return binInfoDto;
	}
}
