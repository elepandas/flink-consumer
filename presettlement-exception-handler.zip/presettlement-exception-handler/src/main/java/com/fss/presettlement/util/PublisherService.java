package com.fss.presettlement.util;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;

public class PublisherService {
	
	private static CommonLogger logger = new CommonLogger(PublisherService.class);
	
	private PublisherService() {
		
	}
	
	public static String publish(String traceId, String topic, String message) {
		logger.logInfo(traceId, "PublisherService : publish() : Entered.");
		
		//setting kafka config details to properties class.
		Properties properties = new Properties();
		properties.put("bootstrap.servers", Constants.KAFKA_SETTLEMENT_TXN_HOST);
		properties.put("key.serializer", Constants.KEY_SERIALIZER);
		properties.put("value.serializer", Constants.KEY_SERIALIZER);
		
		//create producer instance using properties object.
		Producer<String, String> producer = new KafkaProducer<>(properties);
		ProducerRecord<String, String> kafakMessage = new ProducerRecord<>(topic, message);
		//publish data to kafka topic.
		producer.send(kafakMessage);
		producer.close();
		
		logger.logInfo(traceId, "PublisherService : publish() : Returned.");
		return "Data published to kafak topic : "+topic+" successfully.";

	}
	
	
	public static String publishMessage(String traceId, String host, String topic, String message) {
		logger.logInfo(traceId, "PublisherService : publishMessage() : Entered.");
		
		//setting kafka config details to properties class.
		Properties properties = new Properties();
		properties.put("bootstrap.servers", host);
		properties.put("key.serializer", Constants.KEY_SERIALIZER);
		properties.put("value.serializer", Constants.KEY_SERIALIZER);
		
		//create producer instance using properties object.
		Producer<String, String> producer = new KafkaProducer<>(properties);
		ProducerRecord<String, String> kafakMessage = new ProducerRecord<>(topic, message);
		//publish data to kafka topic.
		producer.send(kafakMessage);
		producer.close();
		
		logger.logInfo(traceId, "PublisherService : publishMessage() : Returned.");
		return "Data published to kafak topic : "+topic+" successfully.";

	}
	
}
