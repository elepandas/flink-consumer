package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of De61 fields
 * @since 2023
 *
 */
@Getter
@Setter
public class De61 {
    private String posTermAttendance;
    private String posTermLoc;
    private String posCrdhldrPrsnce;
    private String posCrdPrsnce;
    private String posCrdCaptCap;
    private String posTxnSec;
    private String catLevel;
    private String posCrdDataTermInputCap;
}
