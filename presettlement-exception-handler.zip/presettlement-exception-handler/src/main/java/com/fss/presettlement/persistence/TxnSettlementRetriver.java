package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TxnSettlementDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;

/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnSettlementRetriver {
	
	private TxnSettlementRetriver() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnSettlementRetriver.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on txn_settlement table 
	 * @param settlementTxnKey
	 * @exception SQLException 
	 * @throws TechnicalException 
	 */
	public static TxnSettlementDTO fetchTxnSettlementData(String settlementTxnKey, String rawTrx, Connection connection) throws SQLException, TechnicalException {
		
		logger.logInfo(traceId, "TxnSettlementRetriver: fetchTxnSettlementData:Started");
		
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {

            // Create a SQL query with placeholders for the dynamic parameters.
            String sqlQuery = "SELECT * FROM txn_settlement WHERE settlement_txn_key = ?";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, settlementTxnKey);

            // Execute the query.
            resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
                // Populate a TxnUniqueDataDTO object with the retrieved data.
            	TxnSettlementDTO settlementDTO = new TxnSettlementDTO();
                settlementDTO.setTxnSettlementId(resultSet.getLong("txn_settlement_id"));
                settlementDTO.setSettlementTxnKey(resultSet.getString("settlement_txn_key"));
                settlementDTO.setProcessDate(resultSet.getDate("process_date"));
                settlementDTO.setBusinessDate(resultSet.getDate("business_date"));
                settlementDTO.setPgPaymentId(resultSet.getString("pg_payment_id"));
                settlementDTO.setMerchantTrackId(resultSet.getString("merchant_track_id"));
                settlementDTO.setDiscriminant(resultSet.getBigDecimal("discriminant"));
                settlementDTO.setTxnDatetime(resultSet.getTimestamp("txn_datetime"));
                settlementDTO.setTxnAmt(resultSet.getBigDecimal("txn_amt"));
                settlementDTO.setAcquirerInstitutionId(resultSet.getString("acquirer_institution_id"));
                settlementDTO.setIssuerInstitutionId(resultSet.getString("issuer_institution_id"));
                settlementDTO.setPrimaryAccountNo(resultSet.getString("primary_account_no"));
                settlementDTO.setMerchantId(resultSet.getString("merchant_id"));
                settlementDTO.setStoreId(resultSet.getString("store_id"));
                settlementDTO.setTerminalId(resultSet.getString("terminal_id"));
                settlementDTO.setPaymentCode(resultSet.getString("payment_code"));
                settlementDTO.setTxnSourceCode(resultSet.getString("txn_source_code"));
                settlementDTO.setProcessingCode(resultSet.getString("processing_code"));
                settlementDTO.setTxnTypeCode(resultSet.getString("txn_type_code"));
                settlementDTO.setResponseCode(resultSet.getString("response_code"));
                settlementDTO.setSubChannel(resultSet.getString("sub_channel"));
                settlementDTO.setSubChannelRequestId(resultSet.getString("sub_channel_request_id"));
                settlementDTO.setTenantCode(resultSet.getString("tenant_code"));
                settlementDTO.setDmlType(resultSet.getString("dml_type"));
                settlementDTO.setDmlBy(resultSet.getString("dml_by"));
                settlementDTO.setDmlOn(resultSet.getTimestamp("dml_on"));
                
                return settlementDTO;
            } else {
                // Handle the case when no data is found.
                return null;
            }
        } catch(Exception e) {
			logger.logError(traceId, "Error while persisting data at TxnSettlementExc: " + e.getMessage());

			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(rawTrx));
	    	techenicalExceptionDTO.setTransactionRecord(rawTrx);
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data at TxnSettlementExc: " +  e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
        
        
        } finally {
            // Close database resources.
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }
}
