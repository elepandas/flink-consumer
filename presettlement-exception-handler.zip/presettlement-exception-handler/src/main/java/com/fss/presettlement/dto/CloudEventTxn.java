package com.fss.presettlement.dto;

import com.fasterxml.jackson.annotation.JsonRawValue;
import lombok.Data;

/**
 * 
 * This is a DTO class which holds the property details of cloud event transaction fields
 * @since 2023
 *
 */
@Data
public class CloudEventTxn {
    /** Identifies the event. Producers MUST ensure that source + id is unique for each distinct event. */
    public String id;

    /** The context in which an event happened. */
    public String source;

    /** A value describing the type of event related to the originating occurrence. */
    public String type;

    /** A common way to get the media type of CloudEvents 'data'; */
    public String contentType;

    /** The event data, if any, otherwise null */
    @JsonRawValue
    public String data;

    /** Timestamp of when the occurrence happened */
    public String time;

    /** The version of the CloudEvents specification which the event uses */
    public String specversion;

    /** Subject of the event */
    public String subject;

    /** The Base64 encoded event data, if any, otherwise nulls */
    public String data_base64;
}
