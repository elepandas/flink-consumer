package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.util.TxnExceptionlogger;

public class TaxApplicable {
	
	private static CommonLogger logger = new CommonLogger(TaxApplicable.class);
	
	private TaxApplicable() {
		
	}
	
	/**
	 * 
	 * This method provides the implementation to fetch tax_type_codes from tax_applicable table by 
	 * accepting traceId, connection and feeType as input parameters.
	 * @param traceId
	 * @param connection
	 * @param feeType
	 * @return taxTypeCodeList
	 * @throws ValidationException
	 * @throws SQLException
	 * 
	 */
	public static List<String> getTaxApplicableData(String traceId, Connection connection, String feeType) 
			throws ValidationException, SQLException {
    	logger.logDebug(traceId, "TaxApplicable : getTaxApplicableData() - Entered.");
        PreparedStatement preparedStatement = null;
        List<String> taxTypeCodeList = new ArrayList<>();
        try {
            // Establish a JDBC connection.
            String sqlQuery = "select tax_type_code from tax_applicable where txn_type_code = ?";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, feeType);

            // Execute the query.
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
            	taxTypeCodeList.add(resultSet.getString("tax_type_code"));
            }
            resultSet.close();
            preparedStatement.close();
            logger.logDebug(traceId, "TaxApplicable : getTaxApplicableData() - Returned.");
            return taxTypeCodeList;
        } catch (Exception e) {
            logger.logError(traceId, "Error while taxApplicableData: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(traceId + Constants.ERROR_MSG_SEPERATER+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in taxApplicableData: " + e.getMessage());
        } finally {
            // Close database resources.
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            
        }
	}

}
