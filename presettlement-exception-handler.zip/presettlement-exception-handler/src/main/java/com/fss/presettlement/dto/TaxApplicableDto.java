package com.fss.presettlement.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxApplicableDto {
	
	private Long taxApplicableId;
	private Long institutionId;
	private String txnTypeCode;
	private String taxTypeCode;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;
	
}
