package com.fss.presettlement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction data fields
 * @since 2023
 *
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TransactionData {

	private String pgPmntId;
    private String merchTrackId;
    private String discrim;
    private String tranDatTim;
    private String amt;
    private String pan;
    private String merchantCode;
    private String paymentMethodCode;
    private TransactionBody body;
}
