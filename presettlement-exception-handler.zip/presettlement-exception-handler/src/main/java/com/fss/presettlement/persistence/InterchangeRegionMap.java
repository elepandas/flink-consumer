package com.fss.presettlement.persistence;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.util.TxnExceptionlogger;

public class InterchangeRegionMap {

	private InterchangeRegionMap() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(InterchangeRegionMap.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on Interchange Region Map table 
	 * @param connection, interchange_code, region_code
	 * @throws ValidationException 
	 * interchange_region_code
	 */
	
    public static String getInterchangeRegionCode(Connection connection, String interchangeCode, String regionCode) throws ValidationException {
    	logger.logInfo(traceId, "InterchangeRegionMap: getInterchangeRegionCode:Started");
        String countryCode = null;
        String query = "SELECT interchange_region_code FROM interchange_region_map WHERE interchange_code = ? AND region_code = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, interchangeCode);
            preparedStatement.setString(2, regionCode);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    countryCode = resultSet.getString("interchange_region_code");
                }
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while getInterchangeRegionCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("InterchangeRegionMap:getInterchangeRegionCodev:"+countryCode + Constants.ERROR_MSG_SEPERATER+ interchangeCode+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in getInterchangeRegionCode: " + e.getMessage());
        }  
        return countryCode;
    }
}
