package com.fss.presettlement.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Visa private user fields
 * @since 2023
 *
 */
@Getter
@Setter
public class VisaRaDTO {
    private Long visaRaId;
    private String interchangeTradeCategoryCode;
    private String cardTypeCode;
    private BigDecimal priority;
    private String ra;
    private String posEntryMode;
    private String motoIndc;
    private String posTerminalCapability;
    private String cpdTimelines;
    private String settlementFlag;
    private String productCode;
    private String countryCode;
    private String currencyCode;
    private String mcc;
    private String interchangeRegionCode;
    private String responseCode;
    private String authorizationCode;
    private String merchantName;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;

}
