package com.fss.presettlement.util;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.exception.handlers.FormatException;
import com.fss.presettlement.exception.handlers.TechnicalException;
/**
 * 
 * This class contains logic to validate incoming PG and POS transactions based on defined specifications.
 * @since 2023
 * version: V1.1
 * Specification file name: ACQ - Transaction Log Specs_PG-POS V1.1
 * last modified on:12 Oct 2023
 * @see <a href="https://fssindia.sharepoint.com/:x:/r/sites/Ray-ProductManagement/_layouts/15/doc2.aspx?sourcedoc=%7B6f1df82f-bc45-4a20-b152-46f5efed1680%7D&action=edit&wdenableroaming=1&wdorigin=Sharing.ServerTransfer&wdredirectionreason=Force_SingleStepBoot&wdinitialsession=c96d5e7a-eba0-4ec5-9796-37ffce6ccf38&wdrldsc=2&wdrldc=2&wdrldr=FileOpenUserUnauthorized%2CDeploymentInvalidEditSess&ovuser=0a7d2c8e-16fb-47c6-a2ad-ab54d23dc22a%2Cramuramtal%40fss.co.in&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMzA5MDExMjIyOSIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D">Specification document</a>
 * 
 */
public class TxnFormatValidater {
	
	private TxnFormatValidater() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnFormatValidater.class);
	 
	 /**
		 * 
		 * This method provides implementation of logic to validate incoming transactions based on defined specifications via JSON Schema.
		 * @return String SUCCESS or error message.
		 * @exception IOException, ValidationException
		 * @throws TechnicalException 
		 * @throws FormatException 
		 * 
		 * 
		 */
	public static String txnJsonSchema(String transaction, Connection connection) throws IOException, TechnicalException, FormatException {
		
		logger.logInfo(traceId, "TxnJsonSchemaValidation : txnJsonSchema Started");
		
        // JSON Schema as a string
	 	String flag = Constants.STR;
	 	try {
		 	// check the library volnarabila
	        String schemaString = new String(Files.readAllBytes(Paths.get(Constants.TRX_SCHEMA_FILE_PATH)));
	        // JSON data to be validated
	        String jsonData = transaction;
	
	        // Parse JSON Schema and JSON data
	        JSONObject schemaObj = new JSONObject(new JSONTokener(schemaString));
	        JSONObject jsonToValidate = new JSONObject(new JSONTokener(jsonData));
	
	        // Create a Schema instance from the JSON Schema
	        Schema schema = SchemaLoader.load(schemaObj);
	
	        // Validate JSON data against the Schema
        
        	flag = Constants.SUCCESS;
            schema.validate(jsonToValidate);
        } catch (org.everit.json.schema.ValidationException e) {
        	logger.logError(traceId, e.getLocalizedMessage());
        	
        	FormatExceptionsDTO formatExceptionsDTO = new FormatExceptionsDTO();
	    	formatExceptionsDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transaction));
	    	formatExceptionsDTO.setTransactionRecord(transaction);
	    	formatExceptionsDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	//FormatExceptions.add(traceId, formatExceptionsDTO, connection);
        	
	    	if(e.getMessage().contains(Constants.JSON_SCHEMA_ERROR)) {
        		flag = Constants.ERROR_MESSAGE+Constants.DATA_FORMAT_EERROR;
        		throw new FormatException(flag, traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, formatExceptionsDTO);
        	}else {
        		flag = e.getLocalizedMessage();
        	}
        } catch (Exception e) {
        	logger.logError(traceId, e.getLocalizedMessage());
        	TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
        	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transaction));
        	techenicalExceptionDTO.setTransactionRecord(transaction);
        	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
        	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
        }
        
        logger.logInfo(traceId, "TxnJsonSchemaValidation : txnJsonSchema end");
        return flag;
    }
	
	 /**
	 * 
	 * This method provides implementation of logic to validate incoming transactions based on defined specifications via JSON Schema.
	 * @return String SUCCESS or error message.
	 * @exception IOException, ValidationException
	 * @throws TechnicalException 
	 * @throws FormatException 
	 * 
	 * 
	 */
	public static String txnProcessableJsonSchema(String processableTransaction, Connection connection) throws IOException, TechnicalException, FormatException {
		
		logger.logInfo(traceId, "TxnJsonSchemaValidation : txnProcessableJsonSchema Started");
		
	    // JSON Schema as a string
	 	String flag = Constants.STR;
	 	try {
	        String schemaString = new String(Files.readAllBytes(Paths.get(Constants.TRX_PROCESSABLE_SCHEMA_FILE_PATH)));
	        // JSON data to be validated
	        String jsonData = processableTransaction;
	
	        // Parse JSON Schema and JSON data
	        JSONObject schemaObj = new JSONObject(new JSONTokener(schemaString));
	        JSONObject jsonToValidate = new JSONObject(new JSONTokener(jsonData));
	
	        // Create a Schema instance from the JSON Schema
	        Schema schema = SchemaLoader.load(schemaObj);
	
	        // Validate JSON data against the Schema
	    
	    	flag = Constants.SUCCESS;
	        schema.validate(jsonToValidate);
	    } catch (org.everit.json.schema.ValidationException e) {
	    	logger.logError(traceId, e.getLocalizedMessage());
	    	
	    	FormatExceptionsDTO formatExceptionsDTO = new FormatExceptionsDTO();
	    	formatExceptionsDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(processableTransaction));
	    	formatExceptionsDTO.setTransactionRecord(processableTransaction);
	    	formatExceptionsDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	//FormatExceptions.add(traceId, formatExceptionsDTO, connection);
	    	
	    	if(e.getMessage().contains(Constants.JSON_SCHEMA_ERROR)) {
	    		flag = Constants.ERROR_MESSAGE+Constants.DATA_FORMAT_EERROR;
	    		throw new FormatException(flag, traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, formatExceptionsDTO);
	    	}else {
	    		flag = e.getLocalizedMessage();
	    	}
	    } catch (Exception e) {
        	logger.logError(traceId, e.getLocalizedMessage());
        	TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
        	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(processableTransaction));
        	techenicalExceptionDTO.setTransactionRecord(processableTransaction);
        	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
        	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
        }
	    
	    logger.logInfo(traceId, "TxnJsonSchemaValidation : txnProcessableJsonSchema end");
	    return flag;
	}
	
}
