package com.fss.presettlement.dto;

import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction fields
 * @since 2023
 *
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TransactionDTO {
	
	private BigInteger id;
    private String source;
    private String type;
    private String contentType;
    private TxnEngineLog data;
    private String time;
    private String specversion;
    private String subject;
    private String data_base64;
   
    private String settlementTxnKey;
    private String sourceTopic;
    private String stepStatus;
    

}
