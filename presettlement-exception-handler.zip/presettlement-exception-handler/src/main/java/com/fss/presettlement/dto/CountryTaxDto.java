package com.fss.presettlement.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountryTaxDto {
	
	private Long countryTaxId;
	private String countryCode;
	private String taxCode;
	private String taxPct;
	private String tenantCode;
	private String dmlType;
	private String dmlBy;
	private Date dmlOn;

}
