package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.util.TxnExceptionlogger;

public class CabMccMap {

	private CabMccMap() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(CabMccMap.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on Cab Mcc Map table 
	 * @param connection, excludedMcc
	 * @throws ValidationException 
	 * interchange_region_code
	 */
	
    public static String getVCabTypeByExcludedMcc(Connection connection, String excludedMcc) throws ValidationException {
    	logger.logInfo(traceId, "CabMccMap: getVCabTypeByExcludedMcc:Started");
        String vCabType = null;
        String query = "SELECT DISTINCT cab_type FROM cab_mcc_map WHERE mcc = ?";
        

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, excludedMcc);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                	vCabType = resultSet.getString("cab_type");
                }
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while getVCabTypeByExcludedMcc: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("CabMccMap:getVCabTypeByExcludedMcc:"+vCabType + Constants.ERROR_MSG_SEPERATER+ excludedMcc+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in getVCabTypeByExcludedMcc: " + e.getMessage());
        }  
        return vCabType;
    }
    
    /**
	 * 
	 * This method contains the implementation of jdbc operations on Cab Mcc Map table 
	 * @param connection, excludedMcc, vCabType
	 * @throws ValidationException 
	 * 
	 */
	
    public static String getVCabByVCabType(Connection connection, String excludedMcc, String vCabType) throws ValidationException {
    	logger.logInfo(traceId, "CabMccMap: getVCabByVCabType:Started");
    	vCabType = vCabType+"001";
        String cab = null;
        
        String query = "SELECT cab FROM cab_mcc_map WHERE mcc = ? AND cab = ?";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, excludedMcc);
            preparedStatement.setString(2, vCabType);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                	cab = resultSet.getString("cab");
                }
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while getVCabByVCabType: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions("CabMccMap:getVCabByVCabType:"+cab + Constants.ERROR_MSG_SEPERATER+ vCabType+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in getVCabByVCabType: " + e.getMessage());
        }  
        return cab;
    }
}
