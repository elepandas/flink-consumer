package com.fss.presettlement.util;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;

import cn.ipokerface.snowflake.SnowflakeIdGenerator;

/**
 * 
 * This class contains the method implementations which is used for unique transaction settlement key generation
 * @since 2023
 * @see <a href="https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3285455/AMM+B0003+-+0002-0001+Transaction+Extraction+of+PG">Confluence Page</a>
 *
 */
public class SnowflakeTXNSerialIdGen {

    private static String traceId = Constants.EMPTY_STR;
    private static CommonLogger logger = new CommonLogger(SnowflakeTXNSerialIdGen.class);

    private SnowflakeTXNSerialIdGen() {}

    /**
     * This method provides implementation of logic to generate unique
     * settlement key using snowflake library.
     *
     * @return String (settlement txn id/key).
     * @throws SnowflakeGenerationException if an error occurs during key generation.
     *
     */
    public static String getTxnSettlementKey(TransactionDTO transactionDTO) throws TechnicalException {
        logger.logInfo(traceId, "SnowflakeTXNSerialIdGen : getTxnSettlementID : Started");

        try {
        	//TODO - we need to decide Constants.SNOFLAKE_ID_GEN_PARM, Constants.SNOFLAKE_ID_GEN_PARM based on flink cluster job parameters
            SnowflakeIdGenerator snowflakeIdGenerator = new SnowflakeIdGenerator(Constants.SNOFLAKE_ID_GEN_PARM, Constants.SNOFLAKE_ID_GEN_PARM);
            return Long.toString(snowflakeIdGenerator.nextId());
        } catch (Exception e) {
            logger.logError(traceId, "Error generating settlement key using Snowflake: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new TechnicalException("Error generating settlement key using Snowflake: " + e.getMessage());
        }
    }
}
