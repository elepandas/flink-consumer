package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Primary RsvdPriv fields
 * @since 2023
 *
 */
@Getter
@Setter
public class RaIrdTraceLogDTO {
	private Long raIrdTraceLogId;
    private String settlementTxnKey;
    private String interchangeCode;
    private String raIrd;
    private String traceLog;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;
}
