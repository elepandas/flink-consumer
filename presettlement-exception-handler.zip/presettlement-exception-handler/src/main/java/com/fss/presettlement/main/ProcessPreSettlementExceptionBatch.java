
package com.fss.presettlement.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.Duration;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.main.steps.ProcessPresettlementExceptionSteps;
import com.fss.presettlement.util.KafkaSourceFactory;
import com.fss.presettlement.util.TxnExceptionlogger;
import com.fss.presettlement.util.TxnTypeMapFetcher;

/**
 * 
 * This class contains environment executer for settlement transaction
 * processing job.
 * @see <a https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3285455/AMM+B0003+-+0002-0001+Transaction+Extraction+of+PG">Confluence Page</a>
 * @since 2023
 *
 */

public class ProcessPreSettlementExceptionBatch {

	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(ProcessPreSettlementExceptionBatch.class);
	
	/**
	 * 
	 * This method provides the starter functions of pre-settlement transaction
	 * processing job.
	 * @exception Exception (generic)
	 * 
	 */
	public static void main(String[] args) {

		try {

			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :Started");
			
			
			StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
			
			/*****************************************************************************************************
			 *  defining job restarting strategy, on job termination auto job restart
			 *  will takes place based on this configuration, fixedDelayRestart accepts 2 parameters which are
			 *  restart attempts and time delay between each restart event
			 *****************************************************************************************************/
			
			env.setRestartStrategy(RestartStrategies.fixedDelayRestart(Constants.FIXED_RESTART_ATTEMPTS, Constants.FIXED_RESTART_DELAY));
			
			/*****************************************************************************************************
			 * defining parallelism at environment level will take care of executing independent tasks parallely.
			 * Parallelism count should be passed to this method and this count should not exceed the available 
			 * slots in flink cluster
			 *****************************************************************************************************/
			env.setParallelism(Constants.PARALLELISM);

			
			/*****************************************************************************************************
			 * Enable check pointing for fault-tolerance - TODO validate 10 mili sec case
			 * below mentioned check point specific configuration will take care of creating the checkpoints at given time intervals
			 * it basically capture the job environment state and store it to the specified path on given time interval.
			 * we can set checkpoint modes as well in the configuration.
			 *****************************************************************************************************/
			env.enableCheckpointing(Constants.CHECKPOINT_TIME);
			env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
			env.getCheckpointConfig().setCheckpointStorage(Constants.LOCAL_DIRECTORY);

			/*****************************************************************************************************
			 * WatermarkStrategy declaration: basically helps us to create watermarks between processed packets from kafkatopics
			 * on specified time interval to keep the packets in-line.
			 *****************************************************************************************************/
			WatermarkStrategy<String> watermarkStrategy = WatermarkStrategy
					.<String>forBoundedOutOfOrderness(Duration.ofSeconds(Constants.WATERMARK_TIME))
					.withTimestampAssigner((event, timestamp) -> extractTimestamp());

			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :env specific implementations completed");
			
			Connection connection = DriverManager.getConnection(Constants.DB_HOST, Constants.DB_USR_NAME, Constants.DB_PASS);
	        connection.setAutoCommit(false);
			String txnTypeCode = TxnTypeMapFetcher.fetchTxnTypeCode("1", "TS002", connection);
			
			String rawTrx = "{\r\n"
					+ "    \"id\": \"759668562397275156\",\r\n"
					+ "    \"source\": \"PG\",\r\n"
					+ "    \"type\": \"tranlog.insert\",\r\n"
					+ "    \"contentType\": \"application/json\",\r\n"
					+ "    \"data\": {\r\n"
					+ "        \"pgPmntId\": \"759668562397275156\",\r\n"
					+ "        \"merchTrackId\": \"6467281099\",\r\n"
					+ "        \"discrim\": \"0\",\r\n"
					+ "        \"tranDatTim\": \"2023-12-14 09:44:09\",\r\n"
					+ "        \"amt\": \"000000100090\",\r\n"
					+ "        \"pan\": \"FhwhiOwpE3c9NFqHeNX/OjG8AQmaqNDnQr6eHss3HRzXMJW8Cn278Y/yJSubappyJ597LM/hlXUBme3f\",\r\n"
					+ "        \"merchantId\": \"AKA000HDFC10489\",\r\n"
					+ "        \"paymentCode\": \"Debit\",\r\n"
					+ "        \"subChannel\": null,\r\n"
					+ "        \"subChannelRequestId\": null,\r\n"
					+ "        \"pgTxnID\": \"0e685c3dfb324fb3b256664715f95149\",\r\n"
					+ "        \"tenantCode\": \"HDF\",\r\n"
					+ "        \"body\": {\r\n"
					+ "            \"StdFlds\": {\r\n"
					+ "                \"mti\": \"0100\",\r\n"
					+ "                \"secBitMap\": null,\r\n"
					+ "                \"pan\": \"FhwhiOwpE3c9NFqHeNX/OjG8AQmaqNDnQr6eHss3HRzXMJW8Cn278Y/yJSubappyJ597LM/hlXUBme3f\",\r\n"
					+ "                \"procCode\": \"000000\",\r\n"
					+ "                \"txnAmt\": \"000000100090\",\r\n"
					+ "                \"reconAmt\": null,\r\n"
					+ "                \"chbAmt\": null,\r\n"
					+ "                \"transmissionDateTime\": \"1214094409\",\r\n"
					+ "                \"reconConvRate\": null,\r\n"
					+ "                \"chbConvRate\": null,\r\n"
					+ "                \"stan\": \"094409\",\r\n"
					+ "                \"localDateTime\": \"20231214094409\",\r\n"
					+ "                \"effDate\": null,\r\n"
					+ "                \"expirationDate\": \"7Z9mIFuYKcSw5qKQtfTnJ4bApsSTcoQAIIz4htLonuZu2NMARJ4eIHp85BLRPNjO\",\r\n"
					+ "                \"setlDate\": null,\r\n"
					+ "                \"convDate\": null,\r\n"
					+ "                \"captureDate\": null,\r\n"
					+ "                \"merchType\": \"0001\",\r\n"
					+ "                \"acqInstCntryCode\": null,\r\n"
					+ "                \"forwdInstCntryCode\": null,\r\n"
					+ "                \"ptSvcEntryMde\": \"810\",\r\n"
					+ "                \"crdSeqNum\": null,\r\n"
					+ "                \"functionCode\": null,\r\n"
					+ "                \"ptSvcCondCode\": null,\r\n"
					+ "                \"msgRsnCode\": null,\r\n"
					+ "                \"crdAccptBusCode\": null,\r\n"
					+ "                \"apprvCdeLgth\": null,\r\n"
					+ "                \"reconDate\": null,\r\n"
					+ "                \"reconInd\": null,\r\n"
					+ "                \"origAmts\": null,\r\n"
					+ "                \"settleProcFeeAmt\": null,\r\n"
					+ "                \"acqInstIdCode\": \"56789249\",\r\n"
					+ "                \"panExtended\": null,\r\n"
					+ "                \"track2Data\": null,\r\n"
					+ "                \"track3Data\": null,\r\n"
					+ "                \"rrn\": \"237367879208\",\r\n"
					+ "                \"apprvCode\": \"162793\",\r\n"
					+ "                \"crdAccptTermId\": \"AKA56790\",\r\n"
					+ "                \"crdAccptIdentificationCde\": \"AKA000HDFC10489\",\r\n"
					+ "                \"crdAccptNameLoc\": {\r\n"
					+ "                    \"name\": null,\r\n"
					+ "                    \"street\": null,\r\n"
					+ "                    \"city\": null,\r\n"
					+ "                    \"postalCode\": null,\r\n"
					+ "                    \"region\": null,\r\n"
					+ "                    \"cntryCode\": null\r\n"
					+ "                },\r\n"
					+ "                \"addlRespData\": {\r\n"
					+ "                    \"rsnCode\": null,\r\n"
					+ "                    \"addrVrfnRsltCode\": null,\r\n"
					+ "                    \"addnlTknRespInfo\": null,\r\n"
					+ "                    \"extnSTIPRsnCode\": null,\r\n"
					+ "                    \"cvvRsltsCode\": null,\r\n"
					+ "                    \"pacmDiversionLvlCode\": null,\r\n"
					+ "                    \"pacmDiversionRsnCode\": null,\r\n"
					+ "                    \"crdAuthenRsltsCode\": null,\r\n"
					+ "                    \"cvv2RsltCode\": null,\r\n"
					+ "                    \"cavvRsltsCode\": null,\r\n"
					+ "                    \"respRsnCode\": null,\r\n"
					+ "                    \"panL4DFR\": null\r\n"
					+ "                },\r\n"
					+ "                \"track1Data\": null,\r\n"
					+ "                \"amtFees\": null,\r\n"
					+ "                \"addlDataPDE\": {\r\n"
					+ "                    \"tcc\": null,\r\n"
					+ "                    \"crdhldrVfnMthd\": null,\r\n"
					+ "                    \"ecomInd\": null,\r\n"
					+ "                    \"posDataExtndCondCode\": null,\r\n"
					+ "                    \"onBehalfSrvs\": null,\r\n"
					+ "                    \"pmntTxnTypeInd\": null,\r\n"
					+ "                    \"pinSrvCode\": null,\r\n"
					+ "                    \"avsResp\": null,\r\n"
					+ "                    \"cvc2Resp\": null,\r\n"
					+ "                    \"installmentPmntTerms\": null,\r\n"
					+ "                    \"partialApprvlInd\": null\r\n"
					+ "                },\r\n"
					+ "                \"txnCrncyCode\": \"356\",\r\n"
					+ "                \"reconCrncyCode\": null,\r\n"
					+ "                \"chbCrncyCode\": null,\r\n"
					+ "                \"pinData\": null,\r\n"
					+ "                \"additionalAmts\": null,\r\n"
					+ "                \"emvData\": null,\r\n"
					+ "                \"origDE\": null,\r\n"
					+ "                \"origMTI\": null,\r\n"
					+ "                \"origStan\": null,\r\n"
					+ "                \"authLifeCycleCode\": null,\r\n"
					+ "                \"authAgentInstIdCode\": null,\r\n"
					+ "                \"transportData\": null,\r\n"
					+ "                \"visaAddnlPOSInfo\": {\r\n"
					+ "                    \"termType\": null,\r\n"
					+ "                    \"termEntryCapability\": null,\r\n"
					+ "                    \"chipCondCodes\": null,\r\n"
					+ "                    \"splCondInd\": null,\r\n"
					+ "                    \"chipTxnInd\": null,\r\n"
					+ "                    \"chipCrdAuthRelInd\": null,\r\n"
					+ "                    \"motoEcomInd\": null,\r\n"
					+ "                    \"crdhldrIDMthdInd\": null,\r\n"
					+ "                    \"addnlAuthInds\": null\r\n"
					+ "                },\r\n"
					+ "                \"de60\": {\r\n"
					+ "                    \"rvslCode\": null\r\n"
					+ "                },\r\n"
					+ "                \"de61\": {\r\n"
					+ "                    \"posTermAttendance\": null,\r\n"
					+ "                    \"posTermLoc\": null,\r\n"
					+ "                    \"posCrdhldrPrsnce\": null,\r\n"
					+ "                    \"posCrdPrsnce\": null,\r\n"
					+ "                    \"posCrdCaptCap\": null,\r\n"
					+ "                    \"posTxnSec\": null,\r\n"
					+ "                    \"catLevel\": null,\r\n"
					+ "                    \"posCrdDataTermInputCap\": null\r\n"
					+ "                },\r\n"
					+ "                \"primRsvdPriv\": {\r\n"
					+ "                    \"de62Bitmap\": null,\r\n"
					+ "                    \"authCharInd\": null,\r\n"
					+ "                    \"tranInd\": null,\r\n"
					+ "                    \"valCode\": null,\r\n"
					+ "                    \"mktSpecDataIdent\": null,\r\n"
					+ "                    \"duration\": null,\r\n"
					+ "                    \"rsvd\": null,\r\n"
					+ "                    \"purchIdent\": null,\r\n"
					+ "                    \"gatewayTxnIdent\": null,\r\n"
					+ "                    \"merchVrfnValue\": null,\r\n"
					+ "                    \"onlRiskAssessRiskScoreRsnCode\": null,\r\n"
					+ "                    \"onlRiskAssessCondCde\": null,\r\n"
					+ "                    \"prodId\": null,\r\n"
					+ "                    \"progIdentifier\": null,\r\n"
					+ "                    \"spndQualInd\": null,\r\n"
					+ "                    \"acctStatus\": null\r\n"
					+ "                },\r\n"
					+ "                \"vipPrivUseFld\": {\r\n"
					+ "                    \"rvslCode\": null,\r\n"
					+ "                    \"stip\": null,\r\n"
					+ "                    \"feePrgmInd\": null\r\n"
					+ "                },\r\n"
					+ "                \"de63\": {\r\n"
					+ "                    \"finNtwkCode\": null,\r\n"
					+ "                    \"bnetRefNum\": null\r\n"
					+ "                },\r\n"
					+ "                \"primMsgAuthenCode\": null,\r\n"
					+ "                \"extPymntData\": null,\r\n"
					+ "                \"rcvngInstCntryCode\": null,\r\n"
					+ "                \"authAgentInstCntryCode\": null,\r\n"
					+ "                \"msgNo\": null,\r\n"
					+ "                \"dataRecord\": null,\r\n"
					+ "                \"txnDestInstIdentCode\": null,\r\n"
					+ "                \"txnOrigInstIdentCode\": null,\r\n"
					+ "                \"keyMgmtData\": null,\r\n"
					+ "                \"rcvngInstIdentCode\": null,\r\n"
					+ "                \"fromAcctNo\": null,\r\n"
					+ "                \"toAcctNo\": null,\r\n"
					+ "                \"rsvdPrvtUse123\": null,\r\n"
					+ "                \"visaPvtUseFlds\": {\r\n"
					+ "                    \"srvInd\": null,\r\n"
					+ "                    \"posEnv\": null,\r\n"
					+ "                    \"dcci\": null\r\n"
					+ "                },\r\n"
					+ "                \"rsvdPrvtUse127\": null,\r\n"
					+ "                \"secMAC\": null,\r\n"
					+ "                \"responseCode\": \"00\",\r\n"
					+ "                \"orgRrn\": null,\r\n"
					+ "                \"ForwdInstIdCode\": \"56789249\",\r\n"
					+ "                \"ServiceCode\": null,\r\n"
					+ "                \"OrigDatTimLocalTxn\": null,\r\n"
					+ "                \"OrigAcqInstIdentCode\": null\r\n"
					+ "            },\r\n"
					+ "            \"DB\": {\r\n"
					+ "                \"merchID\": \"AKA000HDFC10489\",\r\n"
					+ "                \"merchBusinessName\": \"Services5\",\r\n"
					+ "                \"merchWebURL\": null,\r\n"
					+ "                \"merchAddr1\": \"Flat No.5,Victoria Garden,106 J.N. Salai\",\r\n"
					+ "                \"merchPostalCode\": null,\r\n"
					+ "                \"merchCity\": null,\r\n"
					+ "                \"merchState\": null,\r\n"
					+ "                \"merchCntry\": null,\r\n"
					+ "                \"merchMobileNo\": null,\r\n"
					+ "                \"merchEmailID\": null,\r\n"
					+ "                \"merchCrncyCde\": null,\r\n"
					+ "                \"merchCntryCde\": null,\r\n"
					+ "                \"merchEnableEMI\": null,\r\n"
					+ "                \"merchBusinessAddr\": null,\r\n"
					+ "                \"paymentInstrument\": \"Debit\",\r\n"
					+ "                \"interchangeID\": \"Master\",\r\n"
					+ "                \"transactionMode\": \"HOSTED\",\r\n"
					+ "                \"payeeVPA\": null,\r\n"
					+ "                \"payeeName\": null,\r\n"
					+ "                \"tenantCode\": \"HDF\"\r\n"
					+ "            },\r\n"
					+ "            \"AddnlFlds\": {\r\n"
					+ "                \"urn\": \"237367879208\",\r\n"
					+ "                \"channel\": \"Merchant\",\r\n"
					+ "                \"txnSrc\": \"TS001\",\r\n"
					+ "                \"invoiceNum\": null,\r\n"
					+ "                \"batchNum\": null,\r\n"
					+ "                \"dccCrncy\": null,\r\n"
					+ "                \"dccAmt\": null,\r\n"
					+ "                \"dccConvRate\": null,\r\n"
					+ "                \"dccConvMarkUpRate\": null,\r\n"
					+ "                \"pgPmntId\": \"759668562397275156\",\r\n"
					+ "                \"merchTrackId\": \"6467281099\",\r\n"
					+ "                \"pgTxnID\": \"0e685c3dfb324fb3b256664715f95149\",\r\n"
					+ "                \"pmntMthdIden\": null,\r\n"
					+ "                \"pmntMthdAggrIden\": null,\r\n"
					+ "                \"pmntMthdAggrTranID\": null,\r\n"
					+ "                \"authEntity\": null,\r\n"
					+ "                \"authSrc\": null,\r\n"
					+ "                \"authCode\": null,\r\n"
					+ "                \"tranID\": null,\r\n"
					+ "                \"rqstRcvdTime\": null,\r\n"
					+ "                \"rqstSentTime\": null,\r\n"
					+ "                \"respRcvdTime\": null,\r\n"
					+ "                \"respSentTime\": null,\r\n"
					+ "                \"brandID\": \"4\",\r\n"
					+ "                \"langID\": null,\r\n"
					+ "                \"merchSuccResURL\": null,\r\n"
					+ "                \"merchFailResURL\": null,\r\n"
					+ "                \"merchPmntInitTim\": \"1214094409\",\r\n"
					+ "                \"merchPmntRespTim\": null,\r\n"
					+ "                \"crdHldrName\": null,\r\n"
					+ "                \"emiFlag\": null,\r\n"
					+ "                \"cardCountryCode\": \"356\",\r\n"
					+ "                \"payerName\": null,\r\n"
					+ "                \"payerVPA\": null,\r\n"
					+ "                \"npciTransId\": null,\r\n"
					+ "                \"pspRefNo\": null,\r\n"
					+ "                \"refundType\": null,\r\n"
					+ "                \"balanceAmount\": null,\r\n"
					+ "                \"udf1\": null,\r\n"
					+ "                \"udf2\": null,\r\n"
					+ "                \"udf3\": null,\r\n"
					+ "                \"udf4\": null,\r\n"
					+ "                \"udf5\": null,\r\n"
					+ "                \"udf6\": null,\r\n"
					+ "                \"udf7\": null,\r\n"
					+ "                \"udf8\": null,\r\n"
					+ "                \"udf9\": null,\r\n"
					+ "                \"udf10\": null,\r\n"
					+ "                \"udf11\": null,\r\n"
					+ "                \"udf12\": null,\r\n"
					+ "                \"udf13\": null,\r\n"
					+ "                \"udf14\": null,\r\n"
					+ "                \"udf15\": null,\r\n"
					+ "                \"udf16\": null,\r\n"
					+ "                \"udf17\": null,\r\n"
					+ "                \"udf18\": null,\r\n"
					+ "                \"udf19\": null,\r\n"
					+ "                \"udf20\": null,\r\n"
					+ "                \"udf21\": null,\r\n"
					+ "                \"udf22\": null,\r\n"
					+ "                \"udf23\": null,\r\n"
					+ "                \"udf24\": null,\r\n"
					+ "                \"udf25\": null,\r\n"
					+ "                \"svcFee\": null,\r\n"
					+ "                \"fixedFeeCrncy\": null,\r\n"
					+ "                \"fixedFeeConvRateValue\": null,\r\n"
					+ "                \"fixedFeeAmt\": null,\r\n"
					+ "                \"svcFeeAmt\": \"000000000000\",\r\n"
					+ "                \"svcFeeTaxType\": null,\r\n"
					+ "                \"svcFeeTaxAmt\": null,\r\n"
					+ "                \"ttlFeeAmt\": null,\r\n"
					+ "                \"storeCode\": \"SAKA000HDFC10489\",\r\n"
					+ "                \"ucafInd\": null,\r\n"
					+ "                \"eci\": null,\r\n"
					+ "                \"actionCode\": \"PURCHASE\",\r\n"
					+ "                \"sli\": \"212\",\r\n"
					+ "                \"mskCardNum\": \"XXXXXXXXXXXX4361\",\r\n"
					+ "                \"ip\": null\r\n"
					+ "            }\r\n"
					+ "        }\r\n"
					+ "    },\r\n"
					+ "    \"time\": null,\r\n"
					+ "    \"specversion\": \"1.0\",\r\n"
					+ "    \"subject\": \"tranlog.insert\",\r\n"
					+ "    \"data_base64\": null\r\n"
					+ "}";
			TransactionDTO transactionDTO = new TransactionDTO() ;//TxnDtoGenerator.trxParser(rawTrx);
			
			transactionDTO.getData().getBody().getTxnEnrData().setBinProductCode("01"); // ALL
			transactionDTO.getData().getBody().getTxnEnrData().setBinExternalCardType("ALL");
			transactionDTO.getData().getBody().getTxnEnrData().setBinIssuerCountry("IND");
			transactionDTO.getData().getBody().getTxnEnrData().setBinIssuerRegion("R004");
			//transactionDTO.getData().getBody().getTxnEnrData().getBinCardType();
			//transactionDTO.getData().getBody().getTxnEnrData().setAcquirerRegionCode("R004");
			transactionDTO.getData().getBody().getStdFlds().setPtSvcEntryMde("10");
			transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().setEcomInd("6");
			transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().setTermEntryCapability("ALL");
			transactionDTO.getData().getBody().getStdFlds().setMerchType("ALL");
			transactionDTO.getData().getBody().getAddnlFlds().setAuthCode("ALL");
			//transactionDTO.getData().getBody().getTxnEnrData().setCurrentBusinessdate("2023-12-14 09:44:09");
			
			
			
			/*****************************************************************************************************
			 * Kafka source configuration: we need to specify the kafka topic name,
			 * host details and group id in kafka source configuration so that we can obtain the incoming data stream.
			 *****************************************************************************************************/
			KafkaSource<String> kafkaSource = KafkaSourceFactory.getKafkaSource(Constants.KAFKA_SETTLEMENT_TXN_HOST, Constants.KAFKA_EXCEPTION_TOPIC_NAME, Constants.KAFKA_GROUP_ID);
			
			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :kafka datasource creation completed");
			
			// Adding Kafka source to the environment and specifying the WatermarkStrategy for kafka source and obtaining kafka stream
			DataStream<String> kafkaStream = env.fromSource(kafkaSource, watermarkStrategy,Constants.KAFKA_DATA_SOURCE_NAME);
			
			/*****************************************************************************************************
			 * Step Execution starts here with the help of ProcescPresettlementSteps custom defined sink function.
			 *****************************************************************************************************/
			kafkaStream.addSink(new ProcessPresettlementExceptionSteps());
			
			env.execute("Transaction extractor");
			
		} catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());
			TxnExceptionlogger.techErrTransactions( "ProcessPreSettlementBatch"+Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * This method provides the time stamp based on current event.
	 * @return timestamp (long).
	 * 
	 */
	private static long extractTimestamp() {
		// Extract timestamp from the event
		return System.currentTimeMillis();
	}
	
}
