
package com.fss.presettlement.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.Duration;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.main.steps.ProcessPresettlementExceptionSteps;
import com.fss.presettlement.util.KafkaSourceFactory;
import com.fss.presettlement.util.TxnExceptionlogger;
import com.fss.presettlement.util.TxnTypeMapFetcher;

/**
 * 
 * This class contains environment executer for settlement transaction
 * processing job.
 * @see <a https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3285455/AMM+B0003+-+0002-0001+Transaction+Extraction+of+PG">Confluence Page</a>
 * @since 2023
 *
 */

public class ProcessPreSettlementExceptionProducer {

	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(ProcessPreSettlementExceptionProducer.class);
	
	/**
	 * 
	 * This method provides the starter functions of pre-settlement transaction
	 * processing job.
	 * @exception Exception (generic)
	 * 
	 */
	public static void main(String[] args) {

		try {

			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :Started");
			
			
			StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
			
			/*****************************************************************************************************
			 *  defining job restarting strategy, on job termination auto job restart
			 *  will takes place based on this configuration, fixedDelayRestart accepts 2 parameters which are
			 *  restart attempts and time delay between each restart event
			 *****************************************************************************************************/
			
			env.setRestartStrategy(RestartStrategies.fixedDelayRestart(Constants.FIXED_RESTART_ATTEMPTS, Constants.FIXED_RESTART_DELAY));
			
			/*****************************************************************************************************
			 * defining parallelism at environment level will take care of executing independent tasks parallely.
			 * Parallelism count should be passed to this method and this count should not exceed the available 
			 * slots in flink cluster
			 *****************************************************************************************************/
			env.setParallelism(Constants.PARALLELISM);

			
			/*****************************************************************************************************
			 * Enable check pointing for fault-tolerance - TODO validate 10 mili sec case
			 * below mentioned check point specific configuration will take care of creating the checkpoints at given time intervals
			 * it basically capture the job environment state and store it to the specified path on given time interval.
			 * we can set checkpoint modes as well in the configuration.
			 *****************************************************************************************************/
			env.enableCheckpointing(Constants.CHECKPOINT_TIME);
			env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
			env.getCheckpointConfig().setCheckpointStorage(Constants.LOCAL_DIRECTORY);

			/*****************************************************************************************************
			 * WatermarkStrategy declaration: basically helps us to create watermarks between processed packets from kafkatopics
			 * on specified time interval to keep the packets in-line.
			 *****************************************************************************************************/
			WatermarkStrategy<String> watermarkStrategy = WatermarkStrategy
					.<String>forBoundedOutOfOrderness(Duration.ofSeconds(Constants.WATERMARK_TIME))
					.withTimestampAssigner((event, timestamp) -> extractTimestamp());

			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :env specific implementations completed");
			
			KafkaSource<String> kafkaSource = KafkaSourceFactory.getKafkaSource(Constants.KAFKA_SETTLEMENT_TXN_HOST, Constants.KAFKA_EXCEPTION_TOPIC_NAME, Constants.KAFKA_GROUP_ID);
			
			logger.logInfo(traceId, "ProcessPreSettlementExceptionBatch :kafka datasource creation completed");
			
			// Adding Kafka source to the environment and specifying the WatermarkStrategy for kafka source and obtaining kafka stream
			DataStream<String> kafkaStream = env.fromSource(kafkaSource, watermarkStrategy,Constants.KAFKA_DATA_SOURCE_NAME);
			
			/*****************************************************************************************************
			 * Step Execution starts here with the help of ProcescPresettlementSteps custom defined sink function.
			 *****************************************************************************************************/
			kafkaStream.addSink(new ProcessPresettlementExceptionSteps());
			
			env.execute("Transaction extractor");
			
		} catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());
			TxnExceptionlogger.techErrTransactions( "ProcessPreSettlementBatch"+Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * This method provides the time stamp based on current event.
	 * @return timestamp (long).
	 * 
	 */
	private static long extractTimestamp() {
		// Extract timestamp from the event
		return System.currentTimeMillis();
	}
	
}
