package com.fss.presettlement.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Standard fields
 * @since 2023
 *
 */
@Getter
@Setter
public class StdFlds{
    private String mti;
    private String secBitMap;
    private String pan;
    private String procCode;
    private String txnAmt;
    private String reconAmt;
    private String chbAmt;
    private String transmissionDateTime;
    private String reconConvRate;
    private String chbConvRate;
    private String stan;
    private String localDateTime;
    private String effDate;
    private String expirationDate;
    private String setlDate;
    private String convDate;
    private String captureDate;
    private String merchType;
    private String acqInstCntryCode;
    private String forwdInstCntryCode;
    private String ptSvcEntryMde;
    private String crdSeqNum;
    private String functionCode;
    private String ptSvcCondCode;
    private String msgRsnCode;
    private String crdAccptBusCode;
    private String apprvCdeLgth;
    private String reconDate;
    private String reconInd;
    private String origAmts;
    private String settleProcFeeAmt;
    private String acqInstIdCode;
    @JsonProperty("ForwdInstIdCode")
    private String forwdInstIdCode; 
    private String panExtended;
    private String track2Data;
    private String track3Data;
    private String rrn;
    private String apprvCode;
    @JsonProperty("ServiceCode")
    private String serviceCode; 
    private String crdAccptTermId;
    private String crdAccptIdentificationCde;
    private CrdAccptNameLoc crdAccptNameLoc;
    private AddlRespData addlRespData;
    private String track1Data;
    private String amtFees;
    private AddlDataPDE addlDataPDE;
    private String txnCrncyCode;
    private String reconCrncyCode;
    private String chbCrncyCode;
    private String pinData;
    private String additionalAmts;
    private String emvData;
    private String origDE;
    private String origMTI;
    private String origStan;
    @JsonProperty("OrigDatTimLocalTxn")
    private String origDatTimLocalTxn;
    @JsonProperty("OrigAcqInstIdentCode")
    private String origAcqInstIdentCode;
    private String authLifeCycleCode;
    private String authAgentInstIdCode;
    private String transportData;
    private VisaAddnlPOSInfo visaAddnlPOSInfo;
    private De60 de60;
    private De61 de61;
    private PrimRsvdPriv primRsvdPriv;
    private VipPrivUseFld vipPrivUseFld;
    private De63 de63;
    private String primMsgAuthenCode;
    private String extPymntData;
    private String rcvngInstCntryCode;
    private String authAgentInstCntryCode;
    private String msgNo;
    private String dataRecord;
    private String txnDestInstIdentCode;
    private String txnOrigInstIdentCode;
    private String keyMgmtData;
    private String rcvngInstIdentCode;
    private String fromAcctNo;
    private String toAcctNo;
    private String rsvdPrvtUse123;
    private VisaPvtUseFlds visaPvtUseFlds; 
    private String rsvdPrvtUse127;
    private String secMAC;
    private String responseCode;
    private String orgRrn;
}
