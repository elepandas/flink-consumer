package com.fss.presettlement.util;



import java.sql.Connection;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TxnEnrDataDTO;
import com.fss.presettlement.exception.handlers.FormatExceptions;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.persistence.TxnMerchantStatus;
import com.fss.presettlement.persistence.TxnSettlementExc;
/**
 * 
 * This class contains business logic to generate TransactionDTO out of incoming transaction data.
 * @since 2023
 *
 */
public class PresettlementExceptionPersister {

	private PresettlementExceptionPersister() {} 
    
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(PresettlementExceptionPersister.class);

	/**
	 * 
	 * This class contains business logic to parse the transaction data to respective dto object.
	 * @return TransactionDTO.
	 * @exception JsonProcessingException
	 *
	 */
    public static void trxParser(String rawTrx, Connection connection) {
    	logger.logInfo(traceId, "PresettlementExceptionPersister : trxParser :Started");
    	
    	final ObjectMapper objectMapper = new ObjectMapper();
        try {
   
            // Convert JSON to a generic Map to extract the "identifier" field
        	TypeReference<Map<String, Object>> mapType = new TypeReference<>() {};
            Map<String, Object> jsonMap = objectMapper.readValue(rawTrx, mapType);
            String identifier = (String) jsonMap.get(Constants.IDENTIFIER);
            
            // Determine the DTO class type based on the "identifier" field
            if (identifier != null && identifier.equals(Constants.TECH_EXEC_MSG)) {
            	TechenicalExceptionDTO techenicalExceptionDTO =  objectMapper.readValue(rawTrx, TechenicalExceptionDTO.class);
            	
            	//public TxnSettlementExc(String traceId, TransactionDTO transactionDTO, Connection connection)
            	TransactionDTO transactionDTO = trxParser(techenicalExceptionDTO.getTransactionRecord());
            	if(techenicalExceptionDTO !=null && !techenicalExceptionDTO.getTransactionRecord().isEmpty()) {
            		new TxnSettlementExc(traceId,transactionDTO,connection);
            		logger.logInfo(traceId, "PresettlementExceptionPersister : trxParser : TxnSettlementExc: complete");
            		transactionDTO.getData().getBody().getTxnEnrData().setIsTechnicalException(Constants.TECH_EXEC_Y);
            		transactionDTO.getData().getBody().getTxnEnrData().setHasTransactionFlow(Constants.HAS_TRX_FLOW_N);
            		new TxnMerchantStatus(traceId, transactionDTO, connection);
            	}
            	
            	
            
            } else if (identifier != null && identifier.equals(Constants.FORMAT_EXEC_MSG)) {
            	FormatExceptionsDTO formatExceptionsDTO = objectMapper.readValue(rawTrx, FormatExceptionsDTO.class);
            	FormatExceptions.add(traceId, formatExceptionsDTO, connection);
            } else {
                throw new IllegalArgumentException("Unsupported identifier: " + identifier);
            }
        	
			
		} catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());
			// TODO - take care of offset scenerio - test 
			TxnExceptionlogger.techErrTransactions("PresettlementExceptionPersister: error at trxParser:"+ Constants.ERROR_MSG_SEPERATER + rawTrx + Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		}

        logger.logInfo(traceId, "TxnDtoGenerator : trxParser :completed");
    }
    
    
    /**
	 * 
	 * This class contains business logic to parse the transaction data to respective dto object.
	 * @return TransactionDTO.
	 * @exception JsonProcessingException
	 *
	 */
    public static TransactionDTO trxParser(String rawTrx) throws TechnicalException {
    	logger.logInfo(traceId, "TxnDtoGenerator : trxParser :Started");
    	
    	TransactionDTO response = null ;
    	
    	ObjectMapper objectMapper = new ObjectMapper();
        try {
        	
			TransactionDTO transactionDTO = objectMapper.readValue(rawTrx, TransactionDTO.class);
			transactionDTO.getData().getBody().setTxnEnrData(new TxnEnrDataDTO());
			transactionDTO.getData().getBody().getTxnEnrData().setRawTransaction(rawTrx);
			response = transactionDTO; 
			
		} catch (JsonProcessingException e) {
			logger.logError(traceId, e.getLocalizedMessage());
	    	TxnExceptionlogger.techErrTransactions("PresettlementExceptionPersister: error at trxParser:"+ Constants.ERROR_MSG_SEPERATER + rawTrx + Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		}

        logger.logInfo(traceId, "TxnDtoGenerator : trxParser :completed");
        return response;
    }
    
}
