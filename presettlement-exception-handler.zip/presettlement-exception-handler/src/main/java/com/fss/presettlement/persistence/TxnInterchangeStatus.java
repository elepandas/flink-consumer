package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnInterchangeStatus {
	

	private static CommonLogger logger = new CommonLogger(TxnInterchangeStatus.class);
	
	/**
	 * 
	 * Custom constructor which invokes the below method to persist or update the txn_interchange_status info
	 * by accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public TxnInterchangeStatus(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		this.persistOrUpdateTxnInterchangeStatus(traceId, transactionDTO, connection);
	}

	/**
	 * 
	 * This method provides the implementation to persist or update the txn_interchange_status table by
	 * accepting the traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @exception SQLException
	 * @throws TechnicalException
	 * 
	 */
	public void persistOrUpdateTxnInterchangeStatus(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnInterchangeStatus : persistOrUpdateTxnInterchangeStatus() : Started.");
		PreparedStatement preparedStatement = null;
		try {
			// Create a SQL query with placeholders for the dynamic parameters.
			String sqlQuery = "SELECT interchange_status_code FROM txn_interchange_status WHERE settlement_txn_key = ? ";
			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());

			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();
			// Check if a record is found.
			if (resultSet.next()) {
				logger.logInfo(traceId, "Updating status_code in txn_interchange_status table.");
				//Invoking method to update status_code in txn_interchange_status
				updateTransactionInterchangeStatus(traceId, transactionDTO, connection);
			} else {
				logger.logInfo(traceId, "Inserting data into int txn_interchange_status table.");
				//Invoking method to insert data into txn_interchange_status table.
				add(traceId, transactionDTO, connection);
			}
			logger.logInfo(traceId, "TxnInterchangeStatus : persistOrUpdateTxnInterchangeStatus() : Returned.");
		} catch (Exception e) {
			logger.logError(traceId, "Error while persist or update data into txn_interchange_status table: " + e.getMessage());
		
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persist or update data into txn_interchange_status table: " + e.getMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()
									+ Constants.ERROR_MSG_SEPERATER + transactionDTO.getSettlementTxnKey()
									+ Constants.ERROR_MSG_SEPERATER + e.getLocalizedMessage());
				}
			}
		}
	}

	/**
	 * 
	 * This method provides the implementation to insert the data into txn_interchange_status table by
	 * accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @exception exception
	 * 
	 */
	public static void add(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnInterchangeStatus : add() - Started.");
		PreparedStatement preparedStatement = null;

		try {
			String sql = "insert into txn_interchange_status (process_date, business_date, settlement_txn_key, interchange_status_code, tenant_code, "
					+ "dml_type, dml_by, dml_on, interchange_code, txn_settlement_exc_id, txn_settlement_id) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
			Date currentDate = new Date();
			String formattedDate = dateFormat.format(currentDate);

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, String.valueOf(LocalDate.ofInstant(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().toInstant(), 
					 ZoneId.systemDefault())));
			preparedStatement.setString(2, transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate());
			preparedStatement.setString(3, transactionDTO.getSettlementTxnKey());
			preparedStatement.setString(4, transactionDTO.getData().getBody().getTxnEnrData().getTxnInterchangeStatusCode());
			preparedStatement.setString(5, transactionDTO.getData().getBody().getDb().getTenantCode());
			preparedStatement.setString(6, Constants.DML_TYPE);
			preparedStatement.setString(7, Constants.DML_BY);
			preparedStatement.setString(8, formattedDate);
			preparedStatement.setString(9, transactionDTO.getData().getBody().getTxnEnrData().getBinInterchangeCode());
			preparedStatement.setString(10, transactionDTO.getData().getBody().getTxnEnrData().getTxnSettlementExcId());
			preparedStatement.setString(11, transactionDTO.getData().getBody().getTxnEnrData().getSettlementTxnId());
			 
			int rowsInserted = preparedStatement.executeUpdate();
			if (rowsInserted > 0) {
				logger.logInfo(traceId, "Data inserted successfully.");
			} else {
				logger.logError(traceId, "Failed to insert data into txn_interchange_status.");
			}
			logger.logInfo(traceId, "TxnInterchangeStatus : add() - Returned.");
		} catch (Exception e) {
			logger.logError(traceId, "Error while persisting data int txn_interchange_status table: " + e.getLocalizedMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data int txn_interchange_status table: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					TxnExceptionlogger
							.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()
									+ Constants.ERROR_MSG_SEPERATER + transactionDTO.getSettlementTxnKey()
									+ Constants.ERROR_MSG_SEPERATER + e.getLocalizedMessage());
				}
			}
		}
	}

	/**
	 * 
	 * This method provides the implementation to update the txn_interchange_status infor by
	 * accepting the traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @exception SQLException
	 * @throws TechnicalException
	 * 
	 */
	public static void updateTransactionInterchangeStatus(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnInterchangeStatus : updateTransactionInterchangeStatus() - Started.");
		PreparedStatement preparedStatement = null;
		try {
			// SQL statement for updating the record
			String updateSql = "update txn_interchange_status set process_date = ?, interchange_status_code = ?, txn_settlement_id = ? where settlement_txn_key = ?";

			preparedStatement = connection.prepareStatement(updateSql);
			// Set the parameters
			preparedStatement.setString(1, String.valueOf(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate()));
			preparedStatement.setString(2, transactionDTO.getData().getBody().getTxnEnrData().getTxnInterchangeStatusCode());
			preparedStatement.setString(3, transactionDTO.getData().getBody().getTxnEnrData().getSettlementTxnId());
			preparedStatement.setString(4, transactionDTO.getSettlementTxnKey());
			
			// Execute the update
			int rowsAffected = preparedStatement.executeUpdate();
			if (rowsAffected == 1) {
				logger.logInfo(traceId, "Record updated successfully.");
			} else {
				logger.logInfo(traceId, "Record not found or not updated.");
			}
			logger.logInfo(traceId, "TxnInterchangeStatus : updateTransactionInterchangeStatus() - Returned.");
		} catch (SQLException e) {
			logger.logError(traceId," Error while updating data into txn_interchange_status table: " + e.getLocalizedMessage());
		
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while updating data into txn_interchange_status table: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
			
			
		} finally {
			// Close the PreparedStatement in a finally block to ensure it's always closed
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error while updating data at updateTransactionInterchangeStatus(): "
							+ e.getLocalizedMessage());
				}
			}
		}
	}

}
