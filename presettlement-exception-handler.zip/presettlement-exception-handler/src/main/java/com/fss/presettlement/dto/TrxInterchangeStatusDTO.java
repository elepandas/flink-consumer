package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction Interchange Status fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TrxInterchangeStatusDTO {

	private long txnInterchangeStatusId;
    private Long txnSettlementId;
    private Long txnSettlementExcId;
    private Date processDate;
    private Date businessDate;
    private String settlementTxnKey;
    private String interchangeCode;
    private String interchangeStatusCode;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;
}
