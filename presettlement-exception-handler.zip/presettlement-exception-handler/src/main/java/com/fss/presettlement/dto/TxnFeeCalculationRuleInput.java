package com.fss.presettlement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnFeeCalculationRuleInput {
	
	private TxnFeeCalculationDto transaction;

}
