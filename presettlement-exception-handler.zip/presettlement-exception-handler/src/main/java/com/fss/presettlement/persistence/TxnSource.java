package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class TxnSource {
	
	private static CommonLogger logger = new CommonLogger(TxnSource.class);
	
	private TxnSource() {
		
	}
	
	/**
	 * 
	 * This method provides the implementation to fetch payment_channel_code from txn_source table by 
	 * accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @return payment_channel_code
	 * @throws TechnicalException
	 * 
	 */
	public static String getPaymentChannelCode(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnSource : getPaymentChannelCode() - Started.");
		PreparedStatement preparedStatement = null;
		try {
			// query to fetch payment_channel_code from txn_source table using txn_source_code as query parameter
			String sqlQuery = "select payment_channel_code from txn_source where txn_source_code = ?";

			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc());

			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();

			// Check if a record is found.
			if (resultSet.next()) {
				logger.logInfo(traceId, "TxnSource : getPaymentChannelCode() - Returned.");
				return resultSet.getString("payment_channel_code");				
			} else {
				logger.logInfo(traceId, "TxnSource : getPaymentChannelCode() - Payment channel code not found, returning empty string.");
				return Constants.EMPTY_STR;
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while fetching payment channel code from txn_source table: " + e.getMessage());
			TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()
					+ Constants.ERROR_MSG_SEPERATER + transactionDTO.getSettlementTxnKey() + Constants.ERROR_MSG_SEPERATER + 
					" Error while fetching payment channel code from txn_source table: "+e.getMessage());
			throw new TechnicalException("Error while fetching payment channel code from txn_source table: " + e.getMessage());
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}

}
