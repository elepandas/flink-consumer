package com.fss.presettlement.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction Enric data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnEnrDataDTO {

	//TODO suffix settle
	private String transactionType;
 	private String originalTransactionId;
    private BigDecimal originalTransactionAmount;
    private Date originalTransactionDateTime;
    private String originalTransactionMCC;
    private String originalTransactionApprovalCode;
    private String originalTransactionRRN;
    private String originalPOSConditionCode;
    private String originalTransactionType;
    private String storeCountry;
    private String storeCurrency;
    private String storeAddress;
    private String storeState;
    private String storeCity;
    private String merchantId;
    private String merchantRiskCategory;
    
    private String merchantCode;
    private String superMerchant;
    private String deliveryChannel;
    private String storeRegion;
    private String binProductInterchangeCategory;
    private String binStoreOnusIndicator;
    private String binInterchangeCode;
    private String binProductClass;
    private String binProductCode;
    private String binProduct;
    private String binRegionCode;
    private String binGCMSProduct;
    private String binCardProgramIndicator;
    private String binPayPassIndicator;
    private String binFastFundFlag;
    private String binCrossBorderFastFundFlag;
    private String binRegulatoryRateType;
    private String binRouthingInterchangeFlag;
    private String binCardLevel;
    private String binBINMessageType;
    private String binBINActivationDate;
    private String binDCICountryCodeGeoCode;
    private String binDCIDXsCode;
    private String binISOIssuerCountryCode;
    private String binISOIssuerCountry;
    private String binIssuerCountry;
    private String binISOIssuerCurrency;
    private String binIssuerCurrency;
    private String binIssuerRegion;
    private String binSMSIndicator;
    private String paymentMethod;
    private String logicalAccount;
    private String merchantSettlementAfterInterchange;
    private String settlementIndicator;
    private String feeRuleCode;
    private String feeType;
    private String feeAmount;
    private String feeCurrency;
    private String taxAmount;
    private String taxCurrency;
    private String taxPercetage;
    private String bournBy;
    private String merchantSettlementCurrency;
    private String settlementAmount;
    private String transactionFee;
    private String raIrd;
    private String tax;
    private String taxType;
    private String taxValue;
    private String taxPercentage;
    private String refundedAmount;
    private String transactionTrade;
    private String transactionTradeCategory;
    private String txnPOSEntryMdCaptureMode;
    private String txnPOSEntryMdPINEntryCapabilities;
    private String binTechnolgyIndicator;
    private BigDecimal binMemberCode;
    private String binCardType;
    private String binExternalCardType;
    private String binProductCategory;
    private String binProcessorBIN;
    private String binAccountLevelMangementParticipationIndicator;
    private String binMappingServiceIndicator;
    private String binProductTypeExtension;
    private String binDomainValue;
    private String binLicenseProductValue;
    private String binDestinationCategory;
    private String merchantSettlementFrequency;
    private String merchantSettlementType;
    private String merchantRiskCatagory;
   
    private String interchangeTransactionType;
    private String acquirerReferenceNumber;
    private String masterCardDE22;
    private String transationStatus;
    private Date currentBusinessdate;
    private String originalBusinessDate;
    //step status variable (help in updating at every step in the flow)
    private String txnMerchantStatusCode;
    private String txnInterchangeStatusCode;
    private String rawTransaction;
    private String trxTypeCode;
    private String settlementTxnId;
    private String txnSettlementExcId;
    private String trxStatus;
    
    private String txnTerminalUid;
    private String txnStoreUid;
    private String txnMerchantlUid;
    private String txnBinOnUs;
    private String txnCardBIN;
    
    
    private String cardBIN;
    private String productInterchangeCategory;
    
    private String merchantFirstTransactionDate;
    private String storeFirstTransactionDate;
    private String terminalFirstTransactionDate;
    
    //RA specific place holders
    private String acquirerRegionCode;
    private String acquirerCountryCode;
    //IRD specific place holders
    private String interchangeRegionCode;
    private String isTechnicalException;
    private String hasTransactionFlow;
}
