package com.fss.presettlement.dto;
/**
 * 
 * This is a DTO class which holds the property details of card acceptor details fields
 * @since 2023
 *
 */
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CrdAccptNameLoc{
    public String name;
    public String street;
    public String city;
    public String postalCode;
    public String region;
    public String cntryCode;
}
