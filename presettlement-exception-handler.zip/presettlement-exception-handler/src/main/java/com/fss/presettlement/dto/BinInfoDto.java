package com.fss.presettlement.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * This is the dto class to capture  bin range information details.
 * @author ramu r
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BinInfoDto implements Serializable{
    
	private static final long serialVersionUID = 1L;
	private Long binId;
    private String lowRange;
    private String highRange;
    private String interchangeCode;
    private Long rawBinFileId;
    
    private String onusIndc;
    private String tokenIndicator;
    private String issuerCountry;
    private String cardType;
    private String product;
    
    private String visaReserved1;
    private String visaReserved2;
    private String visaIssuingIdef;
    private String visaCheckDigitAlgorithm;
    private String visaAccountNumberLength;
    private String visaTokenIndc;
    private String visaReserved3;
    private String visaClientProcessingCenter;
    private String visaDomain;
    private String visaRegion;
    private String visaCountryCode;
    private String visaCountryCode2;
    private String visaComCardServiceIndc;
    private String visaTechnologyIndc;
    private String visaAccountRangeRegion;
    private String visaAccountRangeCountry;
    private String visaComCardLevel2DataIndc;
    private String visaComCardLevel3DataIndc;
    private String visaComCardPosPromptingIndc;
    private String visaVatEvidenceIndc;
    private String visaOriginalCredit;
    private String visaAccountLevelProcessingIndc;
    private String visaOriginalCreditMoneyTransfer;
    private String visaOriginalCreditOnlineGambling;
    private String visaProductId;
    private String visaComboCard;
    private String visaFastFunds;
    private String visaTravelIndc;
    private String visaB2bProgramIdef;
    private String visaPrepaidProgramIndc;
    private String visaRrr;
    private String visaAccountFundingSource;
    private String visaSettlementMatch;
    private String visaTravelAccountData;
    private String visaAccountRestrictedUse;
    private String visaNnssIndc;
    private String visaProductSubtype;
    private String visaAlternateAtm;
    private String visaReserved4;
    private String visaReserved5;
    private String rupayParticipantId;
    private String rupayPanLength;
    private String rupayBinMessageType;
    private String rupayCardType;
    private String rupayCardProduct;
    private String rupayCardVariant;
    private String rupayCardTechnology;
    private String rupaySchemeCode;
    private String rupayDomainUsage;
    private String rupayBinCurrencyCode;
    private String rupayBinActivationDate;
    private String rupayStatusFlag;
    private String msEffectiveTimestamp;
    private String msActiveInactiveCode;
    private String msTableCode;
    private String msGcmsProductCode;
    private String msCardProgramIdef;
    private String msPriorityCode;
    private BigDecimal msMemberCode;
    private BigDecimal msProductTypeCode;
    private BigDecimal msEndpoint;
    private String msRegion;
    private String msProductClass;
    private String msTxnRoutingIndc;
    private String msFirstPresentReassignSwitch;
    private String msProductReassignSwitch;
    private String msPwcbOptInSwitch;
    private String msLicensedProductId;
    private String msMappingServiceIndc;
    private String msAccountParticipationIndc;
    private String msAccountActivationDate;
    private String msChBillCurrencyDefault;
    private BigDecimal msChBillCurrencyExpoDefault;
    private String msChBillCurrency;
    private String msChBillAddnlTxnCurrency;
    private String msChBillingAddnlCurrency;
    private String msChBillingAddnlCurrencyExpo;
    private String msChipMagneticConversion;
    private String mcFloorExpirationDate;
    private String mcCoBrandParticipationSwitch;
    private String mcSpendControlSwitch;
    private String mcMerchantCleansingServiceParticipation;
    private String mcMerchantCleansingActivationDate;
    private String mcContactlessEnabledIndc;
    private String mcRegulatedRateTypeIndc;
    private String mcPsnRouteIndc;
    private String mcCashbackWithoutPurchaseIndc;
    private String mcFiller1;
    private String mcRepowerReloadParticipationIndc;
    private String mcMoneysendIndc;
    private String mcDurbinRegulatedRateIndc;
    private String mcCashAccessParticipatingIndc;
    private String mcAuthenticationIndc;
    private String mcFiller2;
    private String mcTargetMarketProgramIndc;
    private String mcPostDateServiceIndc;
    private String mcMealVoucherIndc;
    private String mcNonReloadablePrepaidSwitch;
    private String mcFasterFundsIndc;
    private String mcAnonymousPrepaidIndc;
    private String mcChCurrencyIndc;
    private String mcPbaParticipationIndc;
    private String mcGameParticipationIndc;
    private String mcEmbeddedFlexInterchangeIndc;
    private String mcFiller3;
    
	}