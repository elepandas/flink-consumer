package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TrxMerchantStatusDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;

/**
 * 
 * This class contains environment executer jdbc operations
 * 
 * @since 2023
 *
 */
public class TxnMerchantStatus {

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnMerchantStatus.class);

	/**
	 * 
	 * This class contains environment executer jdbc operations on
	 * txn_merchant_status table
	 * 
	 * @param settlementTxnKey
	 * @exception SQLException
	 * @throws TechnicalException
	 */
	public static TrxMerchantStatusDTO getTxnMerchantStatusCode(String settlementTxnKey, String rawTrx,
			Connection connection) throws SQLException, TechnicalException {
		logger.logInfo(traceId, "TxnMerchantStatusRetriever: fetchTxnMerchantStatusData:Started");

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {

			// Create a SQL query with placeholders for the dynamic parameters.
			String sqlQuery = "SELECT txn_merchant_status_id, txn_status_code FROM txn_merchant_status WHERE settlement_txn_key = ? ";

			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, settlementTxnKey);

			// Execute the query.
			resultSet = preparedStatement.executeQuery();

			// Check if a record is found.
			if (resultSet.next()) {
				// Populate a TxnUniqueDataDTO object with the retrieved data.
				TrxMerchantStatusDTO trxMerchantStatusDTO = new TrxMerchantStatusDTO();
				trxMerchantStatusDTO.setTxnMerchantStatusId(resultSet.getLong("txn_merchant_status_id"));
				trxMerchantStatusDTO.setTxnStatusCode(resultSet.getString("txn_status_code"));

				return trxMerchantStatusDTO;
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while persisting data at fetchTxnMerchantStatusData: " + e.getMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(rawTrx));
	    	techenicalExceptionDTO.setTransactionRecord(rawTrx);
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data at fetchTxnMerchantStatusData: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
		} finally {
			// Close database resources.
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
				preparedStatement.close();
			}
		}
	}

	/**
	 * 
	 * Custom constructor which invokes the method to persist or update the
	 * txn_merchant_status info by accepting the traceId, transactionDTO and
	 * connection as input parameters
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 */
	public TxnMerchantStatus(String traceId, TransactionDTO transactionDTO, Connection connection)
			throws TechnicalException {
		this.persistOrUpdateTxnMerchantStatusInfo(traceId, transactionDTO, connection);
	}

	/**
	 * 
	 * This method provides the implementation to persist or update data into
	 * txn_merchant_status table by accepting traceId, transactionDTO and connection
	 * as input parameters.
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public void persistOrUpdateTxnMerchantStatusInfo(String traceId, TransactionDTO transactionDTO,
			Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnMerchantStatus : persistOrUpdateTxnMerchantStatusInfo() - Started.");
		PreparedStatement preparedStatement = null;
		try {
			// action-item - use PK in query rather than using txn_status_code
			String sqlQuery = "select txn_merchant_status_id from txn_merchant_status where settlement_txn_key = ? ";

			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());

			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();

			// Check if a record is found.
			if (resultSet.next()) {
				logger.logInfo(traceId, "Updating status_code in txn_merchant_status table.");
				// Invoking below sub-method to update status_code in txn_merchant_status table.
				updateTransactionMerchantStatus(traceId, transactionDTO, connection);
			} else {
				logger.logInfo(traceId, "Inserting data into int txn_merchant_status table.");
				// Invoking below sub-method to insert data into txn_merchant_status table.
				add(traceId, transactionDTO, connection);
			}
			logger.logInfo(traceId, "TxnMerchantStatus : persistOrUpdateTxnMerchantStatusInfo() - Returned.");
		} catch (Exception e) {
			logger.logError(traceId, "Error while persist/update the txn_merchant_status info : " + e.getMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persist/update the txn_merchant_status info : " + e.getMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
		
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}

	/**
	 * 
	 * This method provides the implementation to insert the data into
	 * txn_merchant_status table by accepting traceId, transactionDTO and connection
	 * as input parameters.
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @exception TechnicalException
	 * 
	 */
	public static void add(String traceId, TransactionDTO transactionDTO, Connection connection)
			throws TechnicalException {
		logger.logInfo(traceId, "TxnMerchantStatus : add() - Entered.");
		PreparedStatement preparedStatement = null;
		try {
			// Date for dml_on
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
			Date currentDate = new Date();
			String formattedDate = dateFormat.format(currentDate);
			// Insert query
			String sql = "insert into txn_merchant_status (process_date, business_date, settlement_txn_key, txn_status_code, "
					+ "tenant_code, dml_type, dml_by, dml_on, txn_settlement_exc_id, txn_settlement_id, is_technical_exception, has_transaction_flow) "
					+ "values (?,?,?,?,?,?,?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1,
					String.valueOf(LocalDate.ofInstant(
							transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().toInstant(),
							ZoneId.systemDefault())));
			preparedStatement.setString(2,
					transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate());
			preparedStatement.setString(3, transactionDTO.getSettlementTxnKey());
			preparedStatement.setString(4, transactionDTO.getData().getBody().getTxnEnrData().getTxnMerchantStatusCode());
			preparedStatement.setString(5, transactionDTO.getData().getBody().getDb().getTenantCode());
			preparedStatement.setString(6, Constants.DML_TYPE);
			preparedStatement.setString(7, Constants.DML_BY);
			preparedStatement.setString(8, formattedDate);
			preparedStatement.setString(9, transactionDTO.getData().getBody().getTxnEnrData().getTxnSettlementExcId());
			preparedStatement.setString(10, transactionDTO.getData().getBody().getTxnEnrData().getSettlementTxnId());
			preparedStatement.setString(11, transactionDTO.getData().getBody().getTxnEnrData().getIsTechnicalException());
			preparedStatement.setString(12, transactionDTO.getData().getBody().getTxnEnrData().getHasTransactionFlow());
			// fetching the db operation result
			int rowsInserted = preparedStatement.executeUpdate();
			if (rowsInserted > 0) {
				logger.logInfo(traceId, "Data inserted successfully.");
			} else {
				logger.logError(traceId, "Failed to insert data into txn_merchant_status.");
			}
			logger.logInfo(traceId, "TxnMerchantStatus : add() - Returned.");
		} catch (SQLException e) {
			logger.logError(traceId,
					"Error while persisting data into txn_merchant_status : " + e.getLocalizedMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while persisting data into txn_merchant_status : " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
	    	
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, " Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}

	/**
	 * 
	 * This method provides the implementation to update the data into
	 * txn_merchant_status table by accepting the traceId, transactionDTO,
	 * connection as input parameters.
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public static void updateTransactionMerchantStatus(String traceId, TransactionDTO transactionDTO,
			Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnMerchantStatus: updateTransactionMerchantStatus() - Started.");
		PreparedStatement preparedStatement = null;
		try {
			String sql = "update txn_merchant_status set process_date = ?, txn_status_code = ?, txn_settlement_id = ? where settlement_txn_key = ?, is_technical_exception = ?, has_transaction_flow = ?";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1,
					String.valueOf(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate()));
			preparedStatement.setString(2, transactionDTO.getData().getBody().getTxnEnrData().getTxnMerchantStatusCode());
			preparedStatement.setString(3, transactionDTO.getData().getBody().getTxnEnrData().getSettlementTxnId());
			preparedStatement.setString(4, transactionDTO.getSettlementTxnKey());
			preparedStatement.setString(5, transactionDTO.getData().getBody().getTxnEnrData().getIsTechnicalException());
			preparedStatement.setString(6, transactionDTO.getData().getBody().getTxnEnrData().getHasTransactionFlow());
			
			int rowsUpdated = preparedStatement.executeUpdate();
			if (rowsUpdated > 0) {
				logger.logInfo(traceId, "Data updated successfully.");
			} else {
				logger.logError(traceId, "Failed to update data in txn_merchant_status.");
			}
			logger.logInfo(traceId, "TxnMerchantStatus: updateTransactionMerchantStatus() - Returned.");
		} catch (SQLException e) {
			logger.logError(traceId,
					"Error while updating data into txn_merchant_status table: " + e.getLocalizedMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException("Error while updating data into txn_merchant_status table: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
	    	
			
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}

}
