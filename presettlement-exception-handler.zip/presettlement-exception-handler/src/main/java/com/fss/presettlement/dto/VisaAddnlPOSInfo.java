package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Visa Additional POS Information fields
 * @since 2023
 *
 */
@Getter
@Setter
public class VisaAddnlPOSInfo{
    public String termType;
    public String termEntryCapability;
    public String chipCondCodes;
    public String splCondInd;
    public String chipTxnInd;
    public String chipCrdAuthRelInd;
    public String motoEcomInd;
    public String crdhldrIDMthdInd;
    public String addnlAuthInds;
}
