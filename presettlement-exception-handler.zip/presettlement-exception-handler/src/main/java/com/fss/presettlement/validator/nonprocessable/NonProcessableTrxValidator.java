package com.fss.presettlement.validator.nonprocessable;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TrxMerchantStatusDTO;
import com.fss.presettlement.dto.TxnEnrDataDTO;
import com.fss.presettlement.dto.TxnSettlementDTO;
import com.fss.presettlement.dto.TxnUniqueDataDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.persistence.TxnMerchantStatus;
import com.fss.presettlement.persistence.TxnSettlementRetriver;
import com.fss.presettlement.persistence.TxnUniqueData;
import com.fss.presettlement.util.TxnExceptionlogger;
import com.fss.presettlement.util.TxnTypeMapFetcher;

/**
 * 
 * This class contains the implementation of non processable checks on incoming transaction data
 * @since 2023
 * @see <a href="https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3284540/AMM+B0003+-+0002-0017+PG+Transaction+Non-Processable+exception+check">Confluence Page</a>
 * 
 */
public class NonProcessableTrxValidator {
	
	private NonProcessableTrxValidator() {}
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(NonProcessableTrxValidator.class);
	

	/**
	 * 
	 * This method takes care of performing non processable check validation on incoming transactions.
	 * @param TransactionDTO .
	 * @return Map<String, String>
	 * @throws SQLException 
	 * @throws ValidationException 
	 * 
	 */
	public static Map<String, String> nonProcessableCheck(TransactionDTO transactionDTO, Map<String,String> txnSrcCode, List<String> tenantCode, Connection connection) throws SQLException, ValidationException{
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator nonProcessableCheck:Started");
		HashMap<String, String> errorMap = new HashMap<>() ;
		errorMap.clear();
		nonProcessableTxnCommonValidator( errorMap, transactionDTO,  txnSrcCode, tenantCode, connection);
		logger.logInfo(traceId, "NonProcessableTrxValidator nonProcessableCheck:Ended");
		errorMap.clear();
		return errorMap;
		
	}

	/**
	 * 
	 * This method takes care of performing non processable check on incoming transactions.
	 * @param TransactionDTO .
	 * @throws SQLException 
	 * @throws ValidationException 
	 * 
	 */
	
	private static void nonProcessableTxnCommonValidator( HashMap<String, String> errorMap, TransactionDTO transactionDTO, Map<String,String> txnSrcCode, List<String> tenantCode, Connection connection) throws SQLException, ValidationException {
		logger.logInfo(traceId, "NonProcessableTrxValidator nonProcessableTxnCommonValidator:Started");
		traceId = transactionDTO.getSettlementTxnKey();
		validateTxnTypeCheck(transactionDTO,errorMap, connection);
		validateRefundTransaction(transactionDTO, errorMap, connection);
		validateCvv2ResultCode(transactionDTO, errorMap);
		validateTerminalEntryCapability(transactionDTO, errorMap);
		validateChipConditionCode(transactionDTO, errorMap);
		validateMotoEcomInd(transactionDTO, errorMap);
		validateAvsResp(transactionDTO, errorMap);
		validatePosTerminalAttendance(transactionDTO, errorMap);
		validatePosCrdhldrPrsnce(transactionDTO, errorMap);
		validateUcafIndicator(transactionDTO, errorMap);
		validateOrigMTI(transactionDTO, errorMap);
		validatePtSvcEntryMde(transactionDTO, errorMap);
		validateCrdhldrVfnMthd(transactionDTO, errorMap);
		validateMti( transactionDTO, errorMap);
		validateTxnSrcCode(transactionDTO, errorMap, txnSrcCode);
		validateTenantCode(transactionDTO, errorMap, tenantCode);
		
		logger.logInfo(traceId, "NonProcessableTrxValidator nonProcessableTxnCommonValidator:Ended");
	}
	
	/**
	 * 
	 * This method takes care of performing non processable TxnType check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * 
	 */
	private static void validateTxnTypeCheck(TransactionDTO transactionDTO, HashMap<String, String> errorMap, Connection connection) throws ValidationException{
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateTxnTypeCheck:Started");
		try {
			String processingCode = transactionDTO.getData().getBody().getStdFlds().getProcCode();
			String txnSourceCode = transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc();
			String  txnTypeCode = TxnTypeMapFetcher.fetchTxnTypeCode(processingCode, txnSourceCode, connection);
			
			if (txnTypeCode == null || txnTypeCode.isEmpty()) {
				logger.logInfo(traceId, "NonProcessableTrxValidator Txn Type check:"+ Constants.ERR_MSG_NPERR000001);
			    errorMap.put(Constants.NPERR000001, Constants.ERR_MSG_NPERR000001);
			} else {
				 logger.logInfo(traceId, "NonProcessableTrxValidator Txn Type check: Success");
				 transactionDTO.getData().getBody().getTxnEnrData().setTrxTypeCode(txnTypeCode);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating TxnTypeCheck: " + e.getLocalizedMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
            throw new ValidationException("Error in validating TxnTypeCheck: " + e.getLocalizedMessage());
        }
		
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable Cvv2ResultCode check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * 
	 */
	private static void validateCvv2ResultCode(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException{
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateCvv2ResultCode:Started");
		try {
			String cvv2ResultCode = transactionDTO.getData().getBody().getStdFlds().getAddlRespData().getCvv2RsltCode();
			
			if (cvv2ResultCode != null && Pattern.matches(Constants.ALLOWED_CVV2RESULTCODE, cvv2ResultCode)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator cvv2ResultCode: Success");
			} else {
			    logger.logInfo(traceId, "NonProcessableTrxValidator cvv2ResultCode:"+ Constants.ERR_MSG_NPERR000004);
			    errorMap.put(Constants.NPERR000004, Constants.ERR_MSG_NPERR000004);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating Cvv2ResultCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating Cvv2ResultCode: " + e.getMessage());
        }
		
	}

	/**
	 * 
	 * This method takes care of performing non processable TerminalEntryCapability check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateTerminalEntryCapability(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateTerminalEntryCapability:Started");
		try {
			
			String termEntryCapability = transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getTermEntryCapability();
			
	
			if (termEntryCapability != null && Pattern.matches(Constants.ALLOWED_TEC, termEntryCapability)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator TerminalEntryCapability: Success");
			} else {
			    errorMap.put(Constants.NPERR000005, Constants.ERR_MSG_NPERR000005);
			    logger.logInfo(traceId, "NonProcessableTrxValidator TerminalEntryCapability: " + Constants.ERR_MSG_NPERR000005);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating TerminalEntryCapability: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating TerminalEntryCapability: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable ChipConditionCode check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateChipConditionCode(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateChipConditionCode: Started");
		try {
			
			String chipConditionCode = transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getChipCondCodes();
	
			if (chipConditionCode != null && Pattern.matches(Constants.ALLOWED_CCCODE, chipConditionCode)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator ChipConditionCode: Success");
			} else {
			    errorMap.put(Constants.NPERR000006, Constants.ERR_MSG_NPERR000006);
			    logger.logInfo(traceId, "NonProcessableTrxValidator ChipConditionCode: " + Constants.ERR_MSG_NPERR000006);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating ChipConditionCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating ChipConditionCode: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable MotoEcomInd check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateMotoEcomInd( TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateMotoEcomInd: Started");
		try {
			
			String motoEcomInd = transactionDTO.getData().getBody().getStdFlds().getVisaAddnlPOSInfo().getMotoEcomInd();
	
			if (motoEcomInd != null && Pattern.matches(Constants.ALLOWED_MOTOEI, motoEcomInd)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator MotoEcomInd check: Success");
			} else {
			    errorMap.put(Constants.NPERR000007, Constants.ERR_MSG_NPERR000007);
			    logger.logInfo(traceId, "NonProcessableTrxValidator MotoEcomInd check: failed due to " + Constants.ERR_MSG_NPERR000007);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating ChipConditionCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating ChipConditionCode: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable AvsResp check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateAvsResp(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateAvsResp: Started");
		try {
			String avsResp = transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getAvsResp();
	
			if (avsResp != null && Pattern.matches(Constants.ALLOWED_AVSRESP, avsResp.toUpperCase())) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator AvsResp check: Success");
			} else {
			    errorMap.put(Constants.NPERR000011, Constants.ERR_MSG_NPERR000011);
			    logger.logInfo(traceId, "NonProcessableTrxValidator AvsResp check: failed due to " + Constants.ERR_MSG_NPERR000011);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating AvsResp: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating AvsResp: " + e.getMessage());
        }
		
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable PosTerminalAttendance check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validatePosTerminalAttendance(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validatePosTerminalAttendance: Started");
		try {
			
			String posTerminalAttendance = transactionDTO.getData().getBody().getStdFlds().getDe61().getPosTermAttendance();
	
			if (posTerminalAttendance != null && Pattern.matches(Constants.ALLOWED_POS_TERMINAL_ATTENDENCE, posTerminalAttendance)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator PosTerminalAttendance check: Success");
			} else {
			    errorMap.put(Constants.NPERR000012, Constants.ERR_MSG_NPERR000012);
			    logger.logInfo(traceId, "NonProcessableTrxValidator PosTerminalAttendance check: failed due to " + Constants.ERR_MSG_NPERR000012);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating PosTerminalAttendance: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating PosTerminalAttendance: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable PosCrdhldrPrsnce check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validatePosCrdhldrPrsnce(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validatePosCrdhldrPrsnce: Started");
		try {
			
			String posCrdhldrPrsnce = transactionDTO.getData().getBody().getStdFlds().getDe61().getPosCrdhldrPrsnce();
	
			if (posCrdhldrPrsnce != null && Pattern.matches(Constants.ALLOWED_POS_CRD_HLDR_PRSNCE, posCrdhldrPrsnce)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator PosCrdhldrPrsnce check: Success");
			} else {
			    errorMap.put(Constants.NPERR000014, Constants.ERR_MSG_NPERR000014);
			    logger.logInfo(traceId, "NonProcessableTrxValidator PosCrdhldrPrsnce check: failed due to " + Constants.ERR_MSG_NPERR000014);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating PosTerminalAttendance: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating PosTerminalAttendance: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable UcafIndicator check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateUcafIndicator(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateUcafIndicator: Started");
		try {
			
			String ucafIndicator = transactionDTO.getData().getBody().getAddnlFlds().getUcafInd();
	
			if (ucafIndicator != null && Pattern.matches(Constants.ALLOWED_UCAF_INDICATOR, ucafIndicator)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator UcafIndicator check: Success");
			} else {
			    errorMap.put(Constants.NPERR000021, Constants.ERR_MSG_NPERR000021);
			    logger.logInfo(traceId, "NonProcessableTrxValidator UcafIndicator check: failed due to " + Constants.ERR_MSG_NPERR000021);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating UcafIndicator: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating UcafIndicator: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable OrigMTI check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateOrigMTI(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateOrigMTI: Started");
		try {
			
			String origMTI = transactionDTO.getData().getBody().getStdFlds().getOrigMTI();
	
			if (origMTI != null && Pattern.matches(Constants.ALLOWED_ORIG_MTI, origMTI)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator OrigMTI check: Success");
			} else {
			    errorMap.put(Constants.NPERR000028, Constants.ERR_MSG_NPERR000028);
			    logger.logInfo(traceId, "NonProcessableTrxValidator OrigMTI check: failed due to " + Constants.ERR_MSG_NPERR000028);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating OrigMTI: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating OrigMTI: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable PtSvcEntryMde check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validatePtSvcEntryMde(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validatePtSvcEntryMde: Started");
		try {
			
			String ptSvcEntryMde = transactionDTO.getData().getBody().getStdFlds().getPtSvcEntryMde();
	
			if(ptSvcEntryMde != null) {
				String panEntryMode = ptSvcEntryMde.substring(0, 2);
				String pinEntryCapability = ptSvcEntryMde.substring(2);
	
				if (panEntryMode != null && Pattern.matches(Constants.ALLOWED_PAN_ENTRY_MODE, panEntryMode)
				    && pinEntryCapability != null && Pattern.matches(Constants.ALLOWED_PAN_CAPABILITY, pinEntryCapability)) {
				    logger.logInfo(traceId, "NonProcessableTrxValidator PtSvcEntryMde check: Success");
				} else {
				    errorMap.put(Constants.NPERR000029, Constants.ERR_MSG_NPERR000029);
				    logger.logInfo(traceId, "NonProcessableTrxValidator PtSvcEntryMde check: failed due to " + Constants.ERR_MSG_NPERR000029);
				}
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating PtSvcEntryMde: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating PtSvcEntryMde: " + e.getMessage());
        }	
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable CrdhldrVfnMthd check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateCrdhldrVfnMthd(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validatecrdhldrVfnMthd:Started");
		try {
			
			String crdhldrVfnMthd = transactionDTO.getData().getBody().getStdFlds().getAddlDataPDE().getCrdhldrVfnMthd();
			
			if(crdhldrVfnMthd != null && !crdhldrVfnMthd.isEmpty()) {
				
				if (crdhldrVfnMthd.length() >= 9) {
					 String eighthChar = Character.toString(crdhldrVfnMthd.charAt(7)); // Extract the 8th character (index 7)
					    String ninthChar = Character.toString(crdhldrVfnMthd.charAt(8));  // Extract the 9th character (index 8)
	
					    if (Pattern.matches(Constants.ALLOWED_EIGHTH_CHAR, eighthChar) && Pattern.matches(Constants.ALLOWED_NINTH_CHAR, ninthChar)) {
					        logger.logInfo(traceId, "NonProcessableTrxValidator CrdhldrVfnMthd check: Success");
					    } else {
					        errorMap.put(Constants.NPERR000020, Constants.ERR_MSG_NPERR000020);
					        logger.logInfo(traceId, "NonProcessableTrxValidator CrdhldrVfnMthd check: failed due to " + Constants.ERR_MSG_NPERR000020);
					    }
	
		        }else {
		        	errorMap.put(Constants.NPERR000020, Constants.ERR_MSG_NPERR000020);
	    			logger.logInfo(traceId, "NonProcessableTrxValidator CrdhldrVfnMthd check :failed due to"+ Constants.ERR_MSG_NPERR000020);
	            }
				
			}else {
				errorMap.put(Constants.NPERR000020, Constants.ERR_MSG_NPERR000020);
				logger.logInfo(traceId, "NonProcessableTrxValidator CrdhldrVfnMthd check :failed due to"+ Constants.ERR_MSG_NPERR000020);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating CrdhldrVfnMthd: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating CrdhldrVfnMthd: " + e.getMessage());
        }
	}
	
	/**
	 * 
	 * This method takes care of performing non processable MTI check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */
	private static void validateMti(TransactionDTO transactionDTO, HashMap<String, String> errorMap) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateMti: Started");
		try {
			String mti = transactionDTO.getData().getBody().getStdFlds().getMti();
	
			if (mti != null && Pattern.matches(Constants.ALLOWED_MTI, mti)) {
			    logger.logInfo(traceId, "NonProcessableTrxValidator Mti check: Successful");
			} else {
			    errorMap.put(Constants.NPERR000028, Constants.ERR_MSG_NPERR000028);
			    logger.logInfo(traceId, "NonProcessableTrxValidator Mti check: failed due to " + Constants.ERR_MSG_NPERR000028);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating Mti: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating Mti: " + e.getMessage());
        }
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable TxnSrcCode check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */ 
	private static void validateTxnSrcCode(TransactionDTO transactionDTO, HashMap<String, String> errorMap, Map<String,String> txnSrcCode) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateTxnSrcCode :Started");
		try {
			
			String txnSrc = transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc(); //it should come from main body not from AddnlFlds: corrected in excel sheet
			
			if(txnSrc != null && !txnSrc.isEmpty() && (txnSrcCode.containsValue(txnSrc))) {
				
				logger.logInfo(traceId, "NonProcessableTrxValidator TxnSrcCode check :Succesful");
			}else {
				errorMap.put(Constants.NPERR000034, Constants.ERR_MSG_NPERR000034);
				logger.logInfo(traceId, "NonProcessableTrxValidator TxnSrcCode check :failed due to"+ Constants.ERR_MSG_NPERR000034);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating TxnSrcCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating TxnSrcCode: " + e.getMessage());
        }
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable TenantCode check on incoming transactions.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws ValidationException 
	 * 
	 */ 
	private static void validateTenantCode( TransactionDTO transactionDTO, HashMap<String, String> errorMap, List<String> tenantCode) throws ValidationException {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateTxnSrcCode:Started");
		try {
			
			String tntCode = transactionDTO.getData().getBody().getDb().getTenantCode();
			
			if(tenantCode != null && !tenantCode.isEmpty() && (tenantCode.contains(tntCode))) {
				
				logger.logInfo(traceId, "NonProcessableTrxValidator TenantCode check :Succesful");
			}else {
				errorMap.put(Constants.NPERR000035, Constants.ERR_MSG_NPERR000035);
				logger.logInfo(traceId, "NonProcessableTrxValidator TenantCode check :failed due to"+ Constants.ERR_MSG_NPERR000035);
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating TenantCode: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating TenantCode: " + e.getMessage());
        }
	}
	
	
	/**
	 * 
	 * This method takes care of performing non processable refund request specific checks on incoming transactions data.
	 * @param TransactionDTO .
	 * @return String (success/failure)
	 * @throws SQLException 
	 * @throws ValidationException 
	 * 
	 */ 
	private static void validateRefundTransaction(TransactionDTO transactionDTO, HashMap<String, String> errorMap, Connection connection) throws SQLException, ValidationException  {
		traceId = transactionDTO.getSettlementTxnKey();
		logger.logInfo(traceId, "NonProcessableTrxValidator validateTxnSrcCode:Started");
		try {

			String orgRrn = transactionDTO.getData().getBody().getStdFlds().getOrgRrn();
			String sid = transactionDTO.getData().getBody().getAddnlFlds().getStoreCode();
			String tenantCode = transactionDTO.getData().getBody().getDb().getTenantCode();
			String terminalId = transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId();
			
			
			if(applicableTxnType(transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode())) { 
				
				TxnUniqueDataDTO originalTxnDto = findOriginalTxn(terminalId,orgRrn,sid, tenantCode, connection); 
				
				if(originalTxnDto == null) {
					errorMap.put(Constants.NPERR000002, Constants.ERR_MSG_NPERR000002);
					logger.logInfo(traceId, "NonProcessableTrxValidator RefundTransaction check:failed due to"+ Constants.ERR_MSG_NPERR000002);
				}else {
					
					String txnStatusCode = getTxnMerchantStatus(originalTxnDto.getSettlementTxnKey(), transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(), connection);
					if(txnStatusCode != null && txnStatusCode.equalsIgnoreCase(Constants.STATUS_NPE)) {
						errorMap.put(Constants.NPERR000031, Constants.ERR_MSG_NPERR000031);
						logger.logInfo(traceId, "NonProcessableTrxValidator RefundTransaction check :failed due to"+ Constants.ERR_MSG_NPERR000031);
						
					}else if(txnStatusCode != null && txnStatusCode.equalsIgnoreCase(Constants.STATUS_PROPER) && (transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode().equalsIgnoreCase(Constants.REFUND_CODE))) {
						TxnSettlementDTO txnSettlementDTO = getTxnSettlement(originalTxnDto.getSettlementTxnKey(), transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(), connection);
						  
						BigDecimal orgSettlementTxnAmt =  txnSettlementDTO.getTxnAmt();
						BigDecimal refundTxnAmt =  convertToBigDecimal(transactionDTO.getData().getBody().getStdFlds().getTxnAmt());
						BigDecimal refundedAmt =   convertToBigDecimal(txnSettlementDTO.getBody().getTxnEnrData().getRefundedAmount());
						
						int compare = 0;
						if(refundTxnAmt != null && refundedAmt != null) {
							compare = (refundTxnAmt.add(refundedAmt)).compareTo(orgSettlementTxnAmt);
							transactionDTO.getData().getBody().getTxnEnrData().setRefundedAmount(String.valueOf(refundTxnAmt));
						}
						
						if(compare > 0 ) {
							errorMap.put(Constants.NPERR000030, Constants.ERR_MSG_NPERR000030);
							logger.logInfo(traceId, "NonProcessableTrxValidator RefundTransaction check :failed due to"+ Constants.ERR_MSG_NPERR000030);
						}
						
						transactionDTO.getData().getBody().setTxnEnrData(new TxnEnrDataDTO());
						//enrichment begins
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionId(txnSettlementDTO.getSettlementTxnKey());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionAmount(txnSettlementDTO.getTxnAmt());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionDateTime(txnSettlementDTO.getTxnDatetime());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionMCC(txnSettlementDTO.getBody().getStdFlds().getCrdAccptBusCode());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionApprovalCode(txnSettlementDTO.getBody().getTxnEnrData().getOriginalTransactionApprovalCode());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionRRN(txnSettlementDTO.getBody().getTxnEnrData().getOriginalTransactionRRN());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalPOSConditionCode(txnSettlementDTO.getBody().getStdFlds().getPtSvcCondCode());
						transactionDTO.getData().getBody().getTxnEnrData().setOriginalTransactionType(txnSettlementDTO.getTxnTypeCode());
						
					}
				}
			}
		}catch (Exception e) {
            logger.logError(traceId, "Error while validating RefundTransaction: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction() + Constants.ERROR_MSG_SEPERATER+ transactionDTO.getSettlementTxnKey()+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in validating RefundTransaction: " + e.getMessage());
        }	
	}
	
	
	private static TxnUniqueDataDTO findOriginalTxn(String terminalId,String orgRrn, String sid, String tenantCode, Connection connection) throws SQLException, ValidationException {
		return TxnUniqueData.fetchOrgTxnData(terminalId, orgRrn, sid, tenantCode, connection);
	}
	
	private static String getTxnMerchantStatus(String settlementTxnKey, String rawTrx, Connection connection) throws SQLException, TechnicalException {
		TrxMerchantStatusDTO trxMerchantStatusDTO = TxnMerchantStatus.getTxnMerchantStatusCode(settlementTxnKey, rawTrx, connection);
		return trxMerchantStatusDTO.getTxnStatusCode();
	}
	
	private static TxnSettlementDTO getTxnSettlement(String settlementTxnKey, String rawTrx, Connection connection) throws SQLException, TechnicalException {
		return TxnSettlementRetriver.fetchTxnSettlementData(settlementTxnKey, rawTrx, connection);
	}
	
	public static BigDecimal convertToBigDecimal(String input) {
        try {
            return new BigDecimal(input);
        } catch (NumberFormatException e) {
            return null;
        }
    }

	private static boolean applicableTxnType(String txnType) {
		return txnType != null && (txnType.equalsIgnoreCase(Constants.REFUND_CODE)
	            || txnType.equalsIgnoreCase(Constants.PURCHASE_VOID_CODE)
	            || txnType.equalsIgnoreCase(Constants.REFUND_VOID_CODE)
	            || txnType.equalsIgnoreCase(Constants.PURCHASE_REVERSAL_CODE)
	            || txnType.equalsIgnoreCase(Constants.REFUND_REVERSAL_CODE));
	}
	
}
