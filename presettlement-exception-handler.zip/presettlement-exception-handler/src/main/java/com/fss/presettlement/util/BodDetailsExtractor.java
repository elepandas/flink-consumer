package com.fss.presettlement.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.BusinessException;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.presettlement.constants.Constants;
/**
 * 
 * This class contains the logic to extract BOD details by making external api call.
 * @since 2023
 *
 */
public class BodDetailsExtractor {
	
	private BodDetailsExtractor() {}
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(BodDetailsExtractor.class);
	
	@Value("${property.institution.api.uri}")
    private static String institutionHostUrl;
	
	//@Value("${property.institution.api.uri.eod}")
	//property.institution.api.uri.eod = http://${ACQ_HDFC_INSTITUTION_EOD_HOST:localhost}:8080/acq/institution-eodapis/
	private static String institutionUri = "http://${ACQ_HDFC_INSTITUTION_EOD_HOST:localhost}:8080/acq/institution-eodapis/";
	
	
	public static String  bODDetailsExtractor() throws TechnicalException {
		logger.logInfo(traceId, "BodDetailsExtractor bODDetailsExtractor:Started");
		String fetchCurrBusinessDate = null;
		try {
			//Service call using web client to fetch current bod details
			fetchCurrBusinessDate = WebClient.create().get()
												.uri(institutionHostUrl+Constants.FETCH_CURRENT_BOD_END_POINT)
												.retrieve()
												.bodyToMono(String.class).block();	
		} catch (Exception e) {
			logger.logError(traceId, "Error at BodDetailsExtractor and error message is: " + e.getLocalizedMessage());
		    TxnExceptionlogger.techErrTransactions("Error at BodDetailsExtractor and error message is"+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		    throw new TechnicalException("Error at BodDetailsExtractor and error message is: " + e.getLocalizedMessage());
		}
		return fetchCurrBusinessDate;
	}
	
	
	/**
	 * This getCurrBusinessDate fetches the current business date from acq-hdfc-institution-be data from BOD table.
	 * @param tenantCode
	 * @return Date
	 * @throws BusinessException
	 * @throws TechnicalException 
	 */
	public static Date getCurrBusinessDate(String tenantCode) throws BusinessException, TechnicalException {
		try {

			if(tenantCode == null || tenantCode.isEmpty()) {
				logger.logError(traceId, "Error at BodDetailsExtractor and error message is: " + "Current business date not found");
			    TxnExceptionlogger.techErrTransactions("Error at BodDetailsExtractor and error message is"+ Constants.ERROR_MSG_SEPERATER + "Current business date not found");
			    throw new TechnicalException("Error at BodDetailsExtractor and error message is: " + "Current business date not found");
			}
			
			String jsonResponse = WebClient
					.create().get().uri(institutionUri + Constants.FETCH_CURRENT_BOD_END_POINT + "?"
							+ "tenantCode" + "=" + tenantCode)
					.retrieve().bodyToMono(String.class).onErrorComplete().block();

			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(jsonResponse);

			String currDate = jsonNode.get(Constants.BUSINESS_DATE).asText();

			logger.logInfo(traceId, "currDate:" + currDate);
			if(currDate == null || currDate.isEmpty()) {
				logger.logError(traceId, "Error at BodDetailsExtractor and error message is: " + "Current business date not found");
			    TxnExceptionlogger.techErrTransactions("Error at BodDetailsExtractor and error message is"+ Constants.ERROR_MSG_SEPERATER + "Current business date not found");
			    throw new TechnicalException("Error at BodDetailsExtractor and error message is: " + "Current business date not found");
			}
			return stringToDate(currDate, traceId);
		} catch (Exception e) {
			logger.logError(traceId, "Error at BodDetailsExtractor and error message is: " + e.getLocalizedMessage());
		    TxnExceptionlogger.techErrTransactions("Error at BodDetailsExtractor and error message is"+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		    throw new TechnicalException("Error at BodDetailsExtractor and error message is: " + e.getLocalizedMessage());
		}
	}

	
	public static Date stringToDate(String date, String traceId) throws BusinessException {
		try {
			if (date != null) {
				SimpleDateFormat sdf = new SimpleDateFormat(Constants.TXN_DATE_FORMAT);
				return sdf.parse(date);
			}
		} catch (ParseException e) {
			logger.logError(traceId, "DateValidatorUtil: Invalid Date.");
			throw new BusinessException(String.format(Constants.INVALID_DATA, "Date", date));
		}
		return null;
	}
}
