package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TerminalPaymentMethodDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class TerminalPaymentMethod {

	private TerminalPaymentMethod() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TerminalPaymentMethod.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on terminal table 
	 * @param terminalUid, tenantCode
	 * @exception SQLException 
	 * @throws ValidationException 
	 */
    public static TerminalPaymentMethodDTO fetchTerminalPaymentMethodData(String terminalUid, String tenantCode, Connection connection) throws SQLException, ValidationException {
    	
    	logger.logInfo(traceId, "TerminalPaymentMethod: fetchTerminalPaymentMethodData:Started");
    	
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establish a JDBC connection.

            String sqlQuery = "SELECT terminal_payment_method_id, payment_method_code FROM terminal_payment_method WHERE terminal_uid = ? and tenant_code = ? ";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, terminalUid);
            preparedStatement.setString(2, tenantCode);

            // Execute the query.
            resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
                // Create a new TerminalDTO instance
            	TerminalPaymentMethodDTO terminalPaymentMethodDTO = new TerminalPaymentMethodDTO();
                terminalPaymentMethodDTO.setTerminalPaymentMethodId(resultSet.getString("terminal_payment_method_id"));
                terminalPaymentMethodDTO.setPaymentMethodCode(resultSet.getString("payment_method_code"));
             
                resultSet.close();
                preparedStatement.close();

                return terminalPaymentMethodDTO;
            } else {
                return null;
            }
        } catch (Exception e) {
            logger.logError(traceId, "Error while fetchTerminalPaymentMethodData: " + e.getMessage());
            TxnExceptionlogger.techErrTransactions(terminalUid + Constants.ERROR_MSG_SEPERATER+ tenantCode+ Constants.ERROR_MSG_SEPERATER +  e.getMessage());
            throw new ValidationException("Error in fetchTerminalPaymentMethodData: " + e.getMessage());
        } finally {
            // Close database resources.
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            
        }
    }
}
