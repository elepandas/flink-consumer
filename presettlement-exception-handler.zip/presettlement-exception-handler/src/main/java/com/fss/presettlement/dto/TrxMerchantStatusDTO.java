package com.fss.presettlement.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction Merchant Status fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TrxMerchantStatusDTO {
	
	private Long txnMerchantStatusId;
    private Long txnSettlementId;
    private Long txnSettlementExcId;
    private Date processDate;
    private Date businessDate;
    private String settlementTxnKey;
    private String txnStatusCode;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;

}
