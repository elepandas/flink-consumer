package com.fss.presettlement.validator.processable;

import java.util.Map;
import java.util.Set;
import java.util.HashSet;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.data.redis.core.RedisTemplate;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.TechnicalException;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.BinInfoDto;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.util.AESEncryptionDecryption;
import com.fss.presettlement.util.BinDetailsExtractor;
import com.fss.presettlement.util.TxnExceptionlogger;

import redis.clients.jedis.Jedis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import java.math.BigInteger;

import java.nio.charset.StandardCharsets;
/**
 * 
 * This class contains the implementation of bin data check and data enrichmant 
 * @since 2023
 * @see <a href="https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3284540/AMM+B0003+-+0002-0017+PG+Transaction+Non-Processable+exception+check">Confluence Page</a>
 * 
 */
public class BinDataValidator {
	
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(BinDataValidator.class);
	
	RedisTemplate<String, Object> redisTemplate;
	
	public void validateAndEnrichBinDetails(Map<String, String> errorMap, TransactionDTO transactionDTO) throws TechnicalException, JsonProcessingException, ValidationException {
		logger.logInfo(traceId, "BinDataValidator: validateAndEnrichBinDetails: Started");
		
		String cardNumber = getDecryptedPan(transactionDTO.getData().getPan());
		
		BinInfoDto binInfoDto = getBinInfo(cardNumber);
		
		if(binInfoDto != null) {
			enrichBinData(transactionDTO, binInfoDto, errorMap,cardNumber);
		}else {
			logger.logInfo(traceId, "BinDataValidator : Bin data check:"+ Constants.ERR_MSG_PRERR000008);
		    errorMap.put(Constants.PRERR000008, Constants.ERR_MSG_PRERR000008);
		}
		
	}

	/**
	 * 
	 * This method contains the implementation of getting Decrypted pan
	 * @param pan (string)
	 * @return String decrepted pan
	 */
	private static String getDecryptedPan(String pan) {
		
		logger.logInfo(traceId, "BinDataValidator: getDecryptedPan: Started");
		return AESEncryptionDecryption.decryptAES256Safe(pan, Constants.SECRET_KEY);
		
    }
	
	/**
	 * 
	 * This method contains the implementation of enriching Bin data to TxnDto
	 * @param BinInfoDto
	 * @throws TechnicalException 
	 */
	private static void enrichBinData(TransactionDTO transactionDTO, BinInfoDto binInfoDto, Map<String, String> errorMap,String cardNumber) throws TechnicalException {
		
		logger.logInfo(traceId, "BinDataValidator: getDecryptedPan: Started");
		
		try {
			
			transactionDTO.getData().getBody().getTxnEnrData().setBinInterchangeCode(binInfoDto.getInterchangeCode());
			transactionDTO.getData().getBody().getTxnEnrData().setBinProductCode(binInfoDto.getProduct()); 
			transactionDTO.getData().getBody().getTxnEnrData().setBinIssuerCountry(binInfoDto.getIssuerCountry());
			transactionDTO.getData().getBody().getTxnEnrData().setBinISOIssuerCountryCode(getCurrencyCode());
			transactionDTO.getData().getBody().getTxnEnrData().setBinIssuerRegion(binInfoDto.getIssuerCountry());
			transactionDTO.getData().getBody().getTxnEnrData().setBinCardType(binInfoDto.getCardType());
			transactionDTO.getData().getBody().getTxnEnrData().setBinProductCategory(binInfoDto.getProduct());
						
			enrichBinInformation(transactionDTO, binInfoDto);
			
			binActivationDateValidator( transactionDTO,  binInfoDto, errorMap);
			
			if(transactionDTO.getData().getBody().getStdFlds().getResponseCode().equalsIgnoreCase(Constants.DOUBLE_ZERO)) {
				transactionDTO.getData().getBody().getTxnEnrData().setTrxStatus(Constants.PROPER);
			}else {
				transactionDTO.getData().getBody().getTxnEnrData().setTrxStatus(Constants.DECLINE);
			}
			
			transactionDTO.getData().getBody().getTxnEnrData().setTxnBinOnUs(binInfoDto.getOnusIndc());
			
			if(cardNumber != null) {
				transactionDTO.getData().getBody().getTxnEnrData().setTxnCardBIN(getFirstSixCharacters(cardNumber));
			}
			
		} catch (Exception e) {
			logger.logError(traceId, "Error at enrichBinData and error message is: " + e.getLocalizedMessage());
		    TxnExceptionlogger.techErrTransactions("Error at enrichBinData and error message is"+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		    throw new TechnicalException("Error at enrichBinData and error message is: " + e.getLocalizedMessage());
		}
		
    }

	private static void enrichBinInformation(TransactionDTO transactionDTO, BinInfoDto binInfoDto) {
		if(transactionDTO.getData().getBody().getTxnEnrData().getBinInterchangeCode().equals(Constants.VISA)) {
			enrichVisaBinInformation(transactionDTO, binInfoDto);
			
		}else if(transactionDTO.getData().getBody().getTxnEnrData().getBinInterchangeCode().equals(Constants.RUPAY)) {
			enrichRupayBinInformation(transactionDTO, binInfoDto);
			
		}else if(transactionDTO.getData().getBody().getTxnEnrData().getBinInterchangeCode().equals(Constants.MASTERCARD)) {
			enrichMasterBinInformation(transactionDTO, binInfoDto);
		}
	}

	private static void enrichMasterBinInformation(TransactionDTO transactionDTO, BinInfoDto binInfoDto) {
		transactionDTO.getData().getBody().getTxnEnrData().setBinProductClass(binInfoDto.getMsProductClass());
		transactionDTO.getData().getBody().getTxnEnrData().setBinCardProgramIndicator(binInfoDto.getMsCardProgramIdef());
		transactionDTO.getData().getBody().getTxnEnrData().setBinGCMSProduct(binInfoDto.getMsGcmsProductCode());
		transactionDTO.getData().getBody().getTxnEnrData().setBinPayPassIndicator(binInfoDto.getMcContactlessEnabledIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinCrossBorderFastFundFlag(binInfoDto.getMcFasterFundsIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinRegulatoryRateType(binInfoDto.getMcRegulatedRateTypeIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinBINActivationDate(binInfoDto.getMsAccountActivationDate());
		transactionDTO.getData().getBody().getTxnEnrData().setBinISOIssuerCurrency(binInfoDto.getMsChBillCurrencyDefault());
		
		if(binInfoDto.getMsCardProgramIdef().equalsIgnoreCase(Constants.MASTER_DEBIT_CARD) || binInfoDto.getMsCardProgramIdef().equalsIgnoreCase(Constants.MASTER_CREDIT_CARD)) {
			transactionDTO.getData().getBody().getTxnEnrData().setBinSMSIndicator(Constants.NO);
		}else {
			transactionDTO.getData().getBody().getTxnEnrData().setBinSMSIndicator(Constants.YES);
		}
		transactionDTO.getData().getBody().getTxnEnrData().setBinMemberCode(binInfoDto.getMsMemberCode());
		transactionDTO.getData().getBody().getTxnEnrData().setBinExternalCardType(binInfoDto.getMsCardProgramIdef());
		transactionDTO.getData().getBody().getTxnEnrData().setBinAccountLevelMangementParticipationIndicator(binInfoDto.getMsAccountParticipationIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinMappingServiceIndicator(binInfoDto.getMsMappingServiceIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinLicenseProductValue(binInfoDto.getMsLicensedProductId());
		
		if(transactionDTO.getData().getBody().getTxnEnrData().getBinIssuerCountry().equalsIgnoreCase(transactionDTO.getData().getBody().getTxnEnrData().getStoreCountry())) {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.DOMESTIC);
		}else {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.INTERNATIONAL);
		}
	}

	private static void enrichRupayBinInformation(TransactionDTO transactionDTO, BinInfoDto binInfoDto) {
		transactionDTO.getData().getBody().getTxnEnrData().setBinBINActivationDate(binInfoDto.getRupayBinActivationDate());
		transactionDTO.getData().getBody().getTxnEnrData().setBinISOIssuerCurrency(binInfoDto.getRupayBinCurrencyCode());
		
		if(binInfoDto.getRupayBinMessageType().equalsIgnoreCase(Constants.RUPAY_D)) {
			transactionDTO.getData().getBody().getTxnEnrData().setBinSMSIndicator(Constants.NO);
		}else if(binInfoDto.getRupayBinMessageType().equalsIgnoreCase(Constants.RUPAY_S)){
			transactionDTO.getData().getBody().getTxnEnrData().setBinSMSIndicator(Constants.YES);
		}
		transactionDTO.getData().getBody().getTxnEnrData().setBinTechnolgyIndicator(binInfoDto.getRupayCardTechnology());
		transactionDTO.getData().getBody().getTxnEnrData().setBinExternalCardType(binInfoDto.getRupayCardVariant());
		transactionDTO.getData().getBody().getTxnEnrData().setBinDomainValue(binInfoDto.getRupayDomainUsage());
		
		if(binInfoDto.getRupaySchemeCode().equalsIgnoreCase(Constants.RUPAY_DEBIT_CARD)
				||binInfoDto.getRupaySchemeCode().equalsIgnoreCase(Constants.RUPAY_CREDIT_CARD)
				||binInfoDto.getRupaySchemeCode().equalsIgnoreCase(Constants.RUPAY_PREPAID_CARD)) {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.DOMESTIC);
		}else {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.INTERNATIONAL);
		}
	}

	private static void enrichVisaBinInformation(TransactionDTO transactionDTO, BinInfoDto binInfoDto) {
		transactionDTO.getData().getBody().getTxnEnrData().setBinCrossBorderFastFundFlag(binInfoDto.getVisaFastFunds());
		transactionDTO.getData().getBody().getTxnEnrData().setBinTechnolgyIndicator(binInfoDto.getVisaTechnologyIndc());
		transactionDTO.getData().getBody().getTxnEnrData().setBinExternalCardType(binInfoDto.getVisaAccountFundingSource());
		transactionDTO.getData().getBody().getTxnEnrData().setBinProcessorBIN(binInfoDto.getVisaClientProcessingCenter());
		transactionDTO.getData().getBody().getTxnEnrData().setBinDomainValue(binInfoDto.getVisaDomain());
		
		if(transactionDTO.getData().getBody().getTxnEnrData().getBinIssuerCountry().equalsIgnoreCase(transactionDTO.getData().getBody().getTxnEnrData().getStoreCountry())) {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.DOMESTIC);
		}else {
			transactionDTO.getData().getBody().getTxnEnrData().setBinDestinationCategory(Constants.INTERNATIONAL);
		}
		transactionDTO.getData().getBody().getTxnEnrData().setBinSMSIndicator(Constants.NO);
	}
	
	
	/**
	 * 
	 * This method contains the implementation of bin activation date validating logic
	 * @param TransactionDTO , BinInfoDto , Map<String, String> 
	 * @throws TechnicalException 
	 */
	private static void binActivationDateValidator(TransactionDTO transactionDTO, BinInfoDto binInfoDto, Map<String, String> errorMap) throws TechnicalException {
		
		logger.logInfo(traceId, "binActivationDateValidator: getDecryptedPan: Started");
		
		try {
			
			if(binInfoDto.getInterchangeCode().equals(Constants.MASTERCARD) || binInfoDto.getInterchangeCode().equals(Constants.RUPAY)) {
				if(binInfoDto.getMsAccountActivationDate() != null 	) {
					if(binInfoDto.getMsAccountActivationDate() == transactionDTO.getData().getTranDatTim()) {
						errorMap.put(Constants.PRERR000015, Constants.ERR_MSG_PRERR000015);
					}
				}else if(binInfoDto.getRupayBinActivationDate() != null ) {
					if(binInfoDto.getRupayBinActivationDate() == transactionDTO.getData().getTranDatTim()) {
						errorMap.put(Constants.PRERR000015, Constants.ERR_MSG_PRERR000015);
					}
				}
				
				// Compare the two dates using the compareTo method
		        // Returns a positive value if dateA is later than dateB
		        // Returns 0 if the dates are equal
		        // Returns a negative value if dateA is earlier than dateB
//				if(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate().compareTo( extractDate(transactionDTO.getData().getTranDatTim()))>0) {
//					logger.logInfo(traceId, "TransactionDataCheck:"+ Constants.ERR_MSG_PRERR000009);
//				    errorMap.put(Constants.PRERR000009, Constants.ERR_MSG_PRERR000009);
//				}
			}
			
			
		} catch (Exception e) {
			logger.logError(traceId, "Error at binActivationDateValidator and error message is: " + e.getLocalizedMessage());
		    TxnExceptionlogger.techErrTransactions("Error at binActivationDateValidator and error message is"+ Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
		    throw new TechnicalException("Error at binActivationDateValidator and error message is: " + e.getLocalizedMessage());
		}
		
    }
	
	
	/**
	 * 
	 * This method contains the implementation of getting Bin information based on passed pan/card number
	 * @param cardNumber (string)
	 * @return BinInfoDto
	 * @throws TechnicalException 
	 * @throws JsonProcessingException 
	 * @throws ValidationException 
	 * @throws JsonMappingException 
	 */
	private  BinInfoDto getBinInfo(String cardNumber) throws TechnicalException, ValidationException {
		
		logger.logInfo(traceId, "BinDataValidator: getBinInfo: Started");
		BinInfoDto binInfoDto = null;
		binInfoDto = getBinDetails(cardNumber);
		
		if(binInfoDto == null) {
			binInfoDto = BinDetailsExtractor.getBinData(cardNumber);
		}
		return binInfoDto;
		
    }
	
	/**
	 * 
	 * This method accepts below mentioned parameters as input parameter and return bin range information from cache.
	 * @param interchange Card Number.
	 * @throws ValidationException 
	 *
	 */
	private BinInfoDto getBinDetails(String interchangeCardNumber) throws ValidationException {
		
		logger.logInfo(traceId, "InterchangeServiceImpl: getBinDetails start");
		BinInfoDto binInfoDto = null ;
		
		Set<String> kaySet = getAllKeys();
		
		// this is workaround logic, it may fail in future 
		if(!kaySet.isEmpty()) {
			
			for (String key : kaySet) {

				String[] parts = key.split(Constants.SPLIT_KEY_PATTERN);
				BigInteger low = new BigInteger(parts[0]);
				BigInteger high = new BigInteger(parts[1]);
				String interchangeCode = parts[2];
				interchangeCardNumber = String.format("%-19s", interchangeCardNumber).replace(' ', '0');
				BigInteger cardNumber = new BigInteger(interchangeCardNumber);

				if (cardNumber.compareTo(low) >= 0 && cardNumber.compareTo(high) <= 0) {
					key = Constants.KEY_FORMAT_PATTERN+low+Constants.SPLIT_KEY_PATTERN+high+Constants.KEY_FORMAT_PATTERN+interchangeCode;
					binInfoDto = (BinInfoDto) loadFromCache(key);
				}
			}
		}
			
		logger.logInfo(traceId, "InterchangeServiceImpl: getBinDetails end");
		return binInfoDto;
		
	}
	
	/**
	 * 
	 * This method provides all the keys from redis cache.
	 * @throws ValidationException 
	 * @return Set
	 *
	 */
	public Set<String> getAllKeys() throws ValidationException {
		
		  Set<String> keyList = new HashSet<>();
		  
		  try (Jedis jedis = new Jedis("localhost", Constants.REDIS_PORT)) {
	            // Retrieve the keys from Redis
	            Set<byte[]> keyBytesSet = jedis.keys(Constants.KEY_PATTERN.getBytes());

	            // Decode and print the keys
	            for (byte[] keyBytes : keyBytesSet) {
	                String decodedKey = new String(keyBytes, StandardCharsets.UTF_8);
	                // Find the indices of the delimiters "$#"
	                int startIndex = decodedKey.indexOf(Constants.KEY_FORMAT_PATTERN);
	                int endIndex = decodedKey.indexOf(Constants.KEY_FORMAT_PATTERN, startIndex + 2);
	                // Extract the substring between the delimiters
	                int codeStartIndex = endIndex+2;
	                int codeEndIndex = keyBytes.length;
	                String interchangeCode = decodedKey.substring(codeStartIndex, codeEndIndex);
	                String result = decodedKey.substring(startIndex + 2, endIndex)+Constants.SPLIT_KEY_PATTERN+interchangeCode;
	                keyList.add(result);
	                
	            }
	        }catch (Exception e) {
	        	 logger.logError(traceId, e.getLocalizedMessage());
				 throw new ValidationException(e.getLocalizedMessage());
			}
		 
		return keyList;
		
	}
	
	/**
	 * 
	 * This method provides all the keys from redis cache.
	 * @throws ValidationException 
	 * @return Set
	 *
	 */
	public Object loadFromCache(String key) {
		Object obj = null;
		try {
			long timeIn = System.currentTimeMillis();
			obj = redisTemplate.opsForValue().get(key);
			logger.logInfo(key,"Time taken to load from cache: "+(System.currentTimeMillis()-timeIn)+"ms");
		} catch (Exception e) {
			logger.logInfo(null, "inside storeInCache key " + ExceptionUtils.getStackTrace(e));
		}
		return obj;
	}
	
	/**
	 * 
	 * This method provides all the currency code.
	 * @throws ValidationException 
	 * @return Set
	 *
	 */
	private static String getCurrencyCode() throws ValidationException {
		String obj = null;
		try {
			return obj;
		} catch (Exception e) {
			logger.logInfo(null, "inside getCurrencyCode " + ExceptionUtils.getStackTrace(e));
			logger.logError(traceId, e.getLocalizedMessage());
			throw new ValidationException(e.getLocalizedMessage());
		}
	}
	
	/**
	 * 
	 * This method provides First Six Characters of input string.
	 * @param cardNumber
	 * @throws ValidationException 
	 * @return String
	 *
	 */
	private static String getFirstSixCharacters(String cardNumber) throws ValidationException {
        // Check if the card number is not null and has at least 6 characters
        if (cardNumber != null && cardNumber.length() >= 6) {
            // Use substring to get the first 6 characters
            return cardNumber.substring(0, 6);
        } else {
        	logger.logError(traceId, "getFirstSixCharacters: Invalid card number");
			throw new ValidationException("getFirstSixCharacters: Invalid card number");
        }
    }
}
