package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.AggregationSameMerchantLocationSameAmountDto;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.CacheService;
import com.fss.presettlement.util.CardHashing;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

public class AggregationSameMerchantLocationSameAmount {
	
	private static CommonLogger logger = new CommonLogger(AggregationSameMerchantLocationSameAmount.class);
	
	private AggregationSameMerchantLocationSameAmount() {
		
	}
	
	/**
	 * 
	 * This method provides the implementation to persist data into store_txndate_card_amt_cnt by accepting
	 * traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public static void add(String traceId, TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "StoreTxndateCardAmtCnt : add() - Started.");
	    PreparedStatement preparedStatement = null;
	    
        try {
        	//Date for dml_on
        	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
            Date currentDate = new Date();
            String formattedCurrentDate = dateFormat.format(currentDate);
			
			//txn_settlement custom insert query 
			String sql = "insert into store_txndate_card_amt_cnt " +
                     "(merchant_id, store_id, terminal_id, txn_date, encrypt_card_no, hash_key, txn_currency, txn_amt, no_of_swipes, tenant_code, dml_type, dml_by, dml_on) " +
                     "values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			 
			 logger.logInfo(traceId, "Inserting data into int store_txndate_card_amt_cnt table.");
			 
			 //Declaring prepared statement
			 preparedStatement = connection.prepareStatement(sql);
			 preparedStatement.setString(1, transactionDTO.getData().getMerchantId());
		     preparedStatement.setString(2, transactionDTO.getData().getBody().getAddnlFlds().getStoreCode());
		     preparedStatement.setString(3, transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId());
		     preparedStatement.setString(4, transactionDTO.getData().getTranDatTim());
		     preparedStatement.setString(5, transactionDTO.getData().getPan());
		     
		     String concatenatedString = transactionDTO.getData().getMerchantId() + transactionDTO.getData().getBody().getAddnlFlds().getStoreCode() +
		    		 transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId() + transactionDTO.getData().getTranDatTim() + 
		    		 transactionDTO.getData().getPan() + transactionDTO.getData().getBody().getStdFlds().getTxnCrncyCode() + 
		    		 transactionDTO.getData().getAmt();
		     String hashKey = CardHashing.getHashValue(concatenatedString);
		     if(!concatenatedString.isEmpty()) {
		    	 preparedStatement.setString(6, hashKey);
		     }
		     
		     Long noOfSwipes = getNoOfSwipes(traceId, transactionDTO, connection, hashKey);
		     if(null != noOfSwipes && noOfSwipes > 0) {
		    	 preparedStatement.setString(7, String.valueOf(noOfSwipes + 1));
		     } else {
		    	 preparedStatement.setString(7, String.valueOf(1));
		     }
		     
		     String cacheHashKey = String.valueOf(CacheService.getFromCache(hashKey, transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(),traceId));
		     if(null != cacheHashKey && !cacheHashKey.isEmpty()) {
		    	 CacheService.deleteFromCache(hashKey, transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(),traceId);
		     }
		     
		     preparedStatement.setString(8, transactionDTO.getData().getBody().getStdFlds().getTxnCrncyCode());
		     preparedStatement.setString(9, transactionDTO.getData().getAmt());
		     preparedStatement.setString(10, transactionDTO.getData().getBody().getDb().getTenantCode());
		     preparedStatement.setString(11, Constants.DML_TYPE);
		     preparedStatement.setString(12, Constants.DML_BY);
		     preparedStatement.setString(13, formattedCurrentDate);
		     
		     //Executing the insert operation using prepared statement
		     int rowsInserted = preparedStatement.executeUpdate(); 
		     //Validating the result
		     if (rowsInserted > 0) {
		    	 logger.logInfo(traceId, "Data inserted successfully.");
		     } else {
		    	 logger.logError(traceId, "Failed to insert data into store_txndate_card_amt_cnt.");
		     }
		     logger.logInfo(traceId, "StoreTxndateCardAmtCnt : add() - Returned.");
        } catch (Exception e) {
        	logger.logError(traceId, "Error while persisting data into store_txndate_card_amt_cnt table: " + e.getLocalizedMessage());
		
        	TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException("Error while persisting data into store_txndate_card_amt_cnt table: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
        
        } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, " Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
	}
	
	
	/**
	 * 
	 * This method provides the implementation to get noOfSwipes from store_txndate_card_amt_cnt table by 
	 * accepting traceId, transactionDTO and connection as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @param hashKey
	 * @return noOfSwipes
	 * @throws TechnicalException
	 * 
	 */
	public static Long getNoOfSwipes(String traceId, TransactionDTO transactionDTO, Connection connection, String hashKey) throws TechnicalException {
		logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getNoOfSwipes() - Started.");
		PreparedStatement preparedStatement = null;
		Long noOfSwipes = null;
		try {
			// action-item - use PK in query rather than using txn_status_code
			String sqlQuery = "select no_of_swipes from store_txndate_card_amt_cnt where hash_key = ?";

			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, hashKey);

			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();

			// Check if a record is found.
			if (resultSet.next()) {
				noOfSwipes = resultSet.getLong("no_of_swipes");
				logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getNoOfSwipes() - Returned.");
				return noOfSwipes;
			} else {
				logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getNoOfSwipes() - Returned.");
				return noOfSwipes;
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while fetching no_of_swipes from store_txndate_card_amt_cnt table: " + e.getMessage());

			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException("Error while fetching no_of_swipes from store_txndate_card_amt_cnt table: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
		
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
	}
	
	
	/**
	 * 
	 * This method provides the implementation to fetch store_txndate_card_amt_cnt details from store_txndate_card_amt_cnt table 
	 * by accepting traceId, transactionDTO, connection and hashKey as input parameters.
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @param hashKey
	 * @return StoreTxndateCardAmtCntDto
	 * @throws TechnicalException
	 * 
	 */
	public static AggregationSameMerchantLocationSameAmountDto getStoreTxndateCardAmtCntDetails(String traceId, TransactionDTO transactionDTO, 
			Connection connection, String hashKey) throws TechnicalException {
		logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getStoreTxndateCardAmtCntDetails() - Entered.");
		PreparedStatement preparedStatement = null;
		AggregationSameMerchantLocationSameAmountDto aggregationSameMerchantLocationSameAmountDto = new AggregationSameMerchantLocationSameAmountDto();
		try {
			// action-item - use PK in query rather than using txn_status_code
			String sqlQuery = "select * from store_txndate_card_amt_cnt where hash_key = ?";
			// Prepare the statement with the query and set the parameters.
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, hashKey);
			// Execute the query.
			ResultSet resultSet = preparedStatement.executeQuery();
			// Check if a record is found.
			if (resultSet.next()) {
				aggregationSameMerchantLocationSameAmountDto.setStoreTxndateCardCntId(resultSet.getLong("store_txndate_card_cnt_id"));
				aggregationSameMerchantLocationSameAmountDto.setMerchantId(resultSet.getString("merchant_id"));
				aggregationSameMerchantLocationSameAmountDto.setStoreId(resultSet.getString("store_id"));
				aggregationSameMerchantLocationSameAmountDto.setTerminalId(resultSet.getString("terminal_id"));
				aggregationSameMerchantLocationSameAmountDto.setTxnDate(LocalDate.parse(resultSet.getString("txn_date")));
				aggregationSameMerchantLocationSameAmountDto.setEncryptCardNo(resultSet.getString("encrypt_card_no"));
				aggregationSameMerchantLocationSameAmountDto.setHashKey(resultSet.getString("hash_key"));
				aggregationSameMerchantLocationSameAmountDto.setTxnCurrency(resultSet.getString("txn_currency"));
				aggregationSameMerchantLocationSameAmountDto.setTxnAmt(resultSet.getDouble("txn_amt"));
				aggregationSameMerchantLocationSameAmountDto.setNoOfSwipes(resultSet.getLong("no_of_swipes"));
				aggregationSameMerchantLocationSameAmountDto.setTenantCode(resultSet.getString("tenant_code"));
				aggregationSameMerchantLocationSameAmountDto.setDmlType(resultSet.getString("dml_type"));
				aggregationSameMerchantLocationSameAmountDto.setDmlBy(resultSet.getString("dml_by"));
				aggregationSameMerchantLocationSameAmountDto.setDmlOn(resultSet.getDate("dml_on"));
				logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getStoreTxndateCardAmtCntDetails() - Returned.");
				return aggregationSameMerchantLocationSameAmountDto;
			} else {
				logger.logInfo(traceId, "StoreTxndateCardAmtCnt : getStoreTxndateCardAmtCntDetails() - Returned.");
				aggregationSameMerchantLocationSameAmountDto = null;
				return aggregationSameMerchantLocationSameAmountDto;
			}
		} catch (Exception e) {
			logger.logError(traceId, "Error while fetching store_txndate_card_amt_cnt data from database: " + e.getMessage());
			
			TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
 	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction()));
 	    	techenicalExceptionDTO.setTransactionRecord(transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction());
 	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
 	    	throw new TechnicalException("Error while fetching store_txndate_card_amt_cnt data from database: " + e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
 			
		
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
				}
			}
		}
		
	}

}
