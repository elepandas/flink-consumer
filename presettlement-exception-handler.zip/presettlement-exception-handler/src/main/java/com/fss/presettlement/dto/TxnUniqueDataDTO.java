package com.fss.presettlement.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction unique data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnUniqueDataDTO {
    private Long txnUniqueDataId;
    private String settlementTxnKey;
    private Date processDate;
    private Date businessDate;
    private String pgPaymentId;
    private String storeId;
    private String terminalId;
    private String txnSourceCode;
    private String rrn;
    private String stan;
    private String processingCode;
    private String hashCardNo;
    private Date txnDate;
    private String txnTime;
    private BigDecimal txnAmt;
    private String hashKey;
    private String tenantCode;
    private String dmlType;
    private String dmlBy;
    private Date dmlOn;

}
