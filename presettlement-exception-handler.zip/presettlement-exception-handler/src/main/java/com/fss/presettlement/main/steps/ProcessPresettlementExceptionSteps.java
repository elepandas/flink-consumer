package com.fss.presettlement.main.steps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.FormatExceptionsDTO;
import com.fss.presettlement.dto.TechenicalExceptionDTO;
import com.fss.presettlement.exception.handlers.FormatException;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.PreSettlementCommonUtilty;
import com.fss.presettlement.util.TxnExceptionlogger;

/**
 * 
 * This class contains the PG/POS Txn Extractor step execution logic implementation
 * @see <a a https://fssplatform.atlassian.net/wiki/spaces/ACQ/pages/3285455/AMM+B0003+-+0002-0001+Transaction+Extraction+of+PG">Confluence Page</a>
 * @since 2023
 *
 */
public class ProcessPresettlementExceptionSteps implements SinkFunction<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(ProcessPresettlementExceptionSteps.class);
	
	/**
	 * 
	 * This method provides the logic implementation of connection creation
	 * @throws SQLException 
	 * TODO - check on connection pool implementation
	 */
	protected static Connection getConnection() throws SQLException  {
		logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: beginTransaction:Started");
		Connection connection = DriverManager.getConnection(Constants.DB_HOST, Constants.DB_USR_NAME, Constants.DB_PASS);
        connection.setAutoCommit(false);
        return connection;
	}

	
	/**
	 * 
	 * This method provides the logic implementation of commiting the transaction
	 * @param  Connection
	 * @throws SQLException 
	 * 
	 */
	protected static void commit(Connection connection) throws SQLException {
		logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: commit:Started");
		 try {
			 if(connection != null) {
				 connection.commit();
			 }
			 
	        } catch (Exception e) {
	        	logger.logError(traceId, "Error while persisting data at ProcessPresettlementExceptionSteps: commit:" + e.getLocalizedMessage());
				TxnExceptionlogger.techErrTransactions( e.getLocalizedMessage());
	        } finally {
	            closeConnection(connection);
	        }	
	}

	/**
	 * 
	 * This method provides the logic implementation of aborting the connection.
	 * @param  Connection
	 * @throws SQLException 
	 * 
	 */
	protected static void abort(Connection connection) {
		logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: abort:Started");
		try {
			 if(connection != null) {
				 connection.rollback();
			 }
			
        } catch (Exception e) {
        	logger.logError(traceId, "Error while persisting data at ProcessPresettlementExceptionSteps: abort : " + e.getMessage());
			TxnExceptionlogger.techErrTransactions(e.getLocalizedMessage());
        } finally {
        	logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: abort: finally method:Started");
            closeConnection(connection);
        }	
		
	}
	
	/**
	 * 
	 * This method provides the logic implementation of pre settlement step execution.
	 * @param  Connection, String
	 * @throws SQLException 
	 * @throws TechnicalException
	 * @throws ValidationException
	 * @throws FormatException 
	 */
	public static void executePresettlementSteps(String rawTrx, Connection connection) throws TechnicalException, SQLException, ValidationException, FormatException {
		logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: executePresettlementSteps:Started");
		
		try {
			
			PGPOSTxnExtractor.txnExtractorProcess(rawTrx, connection);
		
		} catch (FormatException e) {
	    	logger.logError(traceId, e.getLocalizedMessage());
	    	
	    	FormatExceptionsDTO formatExceptionsDTO = new FormatExceptionsDTO();
	    	formatExceptionsDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(rawTrx));
	    	formatExceptionsDTO.setTransactionRecord(rawTrx);
	    	formatExceptionsDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
			throw new FormatException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, formatExceptionsDTO);
		}catch (Exception e) {
			e.fillInStackTrace();
			abort(connection);
		    logger.logError(traceId, "Error at OLTPTransactionsExtractor and error message is: " + e.getMessage());
		    TechenicalExceptionDTO techenicalExceptionDTO = new TechenicalExceptionDTO();
	    	techenicalExceptionDTO.setTenantCode(PreSettlementCommonUtilty.extractTenantCodeFromRawTrx(rawTrx));
	    	techenicalExceptionDTO.setTransactionRecord(rawTrx);
	    	techenicalExceptionDTO.setTopicName(Constants.KAFKA_EXCEPTION_TOPIC_NAME);
	    	throw new TechnicalException(e.getLocalizedMessage(), traceId, Constants.KAFKA_SETTLEMENT_TXN_HOST, techenicalExceptionDTO);
		}
		
	}
	
	
	
	 /**
   	 * 
   	 * This method contains the logic to close the connection 
   	 * @param Connection
     * @throws SQLException 
   	 */
    private static void closeConnection(Connection connection) {
    	logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: closeConnection:Started");
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
            	logger.logError(traceId, "CollectMarkProcessableExec: Error while closeConnection: " + e.getLocalizedMessage());
    			TxnExceptionlogger.techErrTransactions(e.getLocalizedMessage());
            }
        }
    }
    
    
    /**
   	 * 
   	 * This is default method of SinkFunction, we have defined the step execution logic in it 
   	 * @param String , context
   	 */
    @Override
    public void invoke(String rawTxn, Context context) {
        // Start a transaction
    	logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: invoke:Started");
        Connection connection = null;

        try {

        	connection = getConnection();
        	executePresettlementSteps(rawTxn, connection);
        	commit(connection);
        } catch (Exception e) {
			logger.logError(traceId, e.getLocalizedMessage());
			abort(connection);
			TxnExceptionlogger.techErrTransactions( "ProcessPresettlementExceptionSteps"+Constants.ERROR_MSG_SEPERATER +  e.getMessage());
			e.printStackTrace();
		} finally {
			logger.logInfo(traceId, "ProcessPresettlementExceptionSteps: invoke: finally method:Started");
			closeConnection(connection);
        }
    }

}
