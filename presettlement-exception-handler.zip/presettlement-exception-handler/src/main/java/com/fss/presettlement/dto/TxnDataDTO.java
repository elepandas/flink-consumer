package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction data fields
 * @since 2023
 *
 */
@Getter
@Setter
public class TxnDataDTO {
	
	private String transactionType;
    private String originalTransactionId;
    private String originalTransactionAmount;
    private String originalTransactionDateTime;
    private String originalTransactionMCC;
    private String originalTransactionApprovalCode;
    private String originalTransactionRRN;
    private String originalPOSConditionCode;
    private String originalTransactionType;
    private String storeCountry;
    private String storeCurrency;
   
    private String merchantCode;
    private String superMerchant;
    private String deliveryChannel;
    private String storeRegion;
    private String binProductInterchangeCategory;
    private String binStoreOnusIndicator;
    
    private String paymentMethod;
    private String logicalAccount;
    private String merchantSettlementAfterInterchangeSettlementIndicator;
    private String merchantSettlementCurrency;
    private String settlementAmount;
    private String transactionFee;
    private String raIrd;
    private String tax;
    private String taxType;
    private String taxValue;
    private String taxPercentage;
    private String refundedAmount;
    
}
