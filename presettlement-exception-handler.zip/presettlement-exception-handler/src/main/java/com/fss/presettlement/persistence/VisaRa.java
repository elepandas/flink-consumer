package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

import com.fss.logger.CommonLogger;
import com.fss.platform.exception.type.ValidationException;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.VisaRaDTO;
import com.fss.presettlement.util.TxnExceptionlogger;

public class VisaRa {

	private VisaRa() {}

	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(VisaRa.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	/**
	 * 
	 * This method contains the implementation of jdbc operations on Visa_Ra table 
	 * @param 
	 * @exception SQLException 
	 * @throws ValidationException 
	 */
    public static List<VisaRaDTO> fetchVisaRaData(TransactionDTO transactionDTO, Connection connection) throws SQLException, ValidationException {
    	
    	logger.logInfo(traceId, "VisaRa: fetchStoreData:Started");
    	List<VisaRaDTO> visaRaList = new ArrayList<>();

    	try (PreparedStatement preparedStatement = connection.prepareStatement(
			 "SELECT pos_entry_mode,moto_indc,pos_terminal_capability,mcc,authorization_code,cpd_timelines,ra " +
			            "FROM VISA_RA " +
			            "WHERE (product_code LIKE ? OR product_code = 'ALL') " + //TODO - convert all to constant
			            "AND (card_type_code LIKE ? OR card_type_code = 'ALL') " +
			            "AND (interchange_trade_category_code LIKE ? OR interchange_trade_category_code = 'ALL') " +
			            "AND country_code = ? " +
			            "AND (interchange_region_code LIKE ? OR interchange_region_code = 'ALL') " +
			            "ORDER BY priority ASC")) {
    		
			preparedStatement.setString(1, "%" + transactionDTO.getData().getBody().getTxnEnrData().getBinProductCode() + "%");
			preparedStatement.setString(2, "%" + transactionDTO.getData().getBody().getTxnEnrData().getBinExternalCardType() + "%");
			preparedStatement.setString(3, "%" + transactionDTO.getData().getBody().getTxnEnrData().getTransactionTradeCategory() + "%");
			preparedStatement.setString(4, transactionDTO.getData().getBody().getTxnEnrData().getAcquirerCountryCode());
			preparedStatement.setString(5, "%" +transactionDTO.getData().getBody().getTxnEnrData().getAcquirerRegionCode() + "%");


    	    try (ResultSet resultSet = preparedStatement.executeQuery()) {
    	        while (resultSet.next()) {
    	            VisaRaDTO visaRaDTO = new VisaRaDTO();
    	            
    	            visaRaDTO.setRa(resultSet.getString("ra"));
    	            visaRaDTO.setPosEntryMode(resultSet.getString("pos_entry_mode"));
    	            visaRaDTO.setMotoIndc(resultSet.getString("moto_indc"));
    	            visaRaDTO.setPosTerminalCapability(resultSet.getString("pos_terminal_capability"));
    	            visaRaDTO.setCpdTimelines(resultSet.getString("cpd_timelines"));
    	            visaRaDTO.setMcc(resultSet.getString("mcc"));
    	            visaRaDTO.setAuthorizationCode(resultSet.getString("authorization_code"));
    	            
    	            visaRaList.add(visaRaDTO);
    	        }
    	    }
    	} catch (Exception e) {
            logger.logError(traceId, "Error while fetchVisaRaData: " + e.getLocalizedMessage());
            TxnExceptionlogger.techErrTransactions(Constants.ERROR_MSG_SEPERATER +  e.getLocalizedMessage());
            throw new ValidationException("Error in fetchVisaRaData: " + e.getLocalizedMessage());
        } 
    	
    	return visaRaList;
    }
}
 
