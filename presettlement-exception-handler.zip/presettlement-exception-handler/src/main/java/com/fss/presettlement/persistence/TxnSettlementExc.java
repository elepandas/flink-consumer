package com.fss.presettlement.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fss.logger.CommonLogger;
import com.fss.presettlement.constants.Constants;
import com.fss.presettlement.dto.TransactionDTO;
import com.fss.presettlement.dto.TxnSettlementExcDto;
import com.fss.presettlement.exception.handlers.TechnicalException;
import com.fss.presettlement.util.TxnExceptionlogger;
/**
 * 
 * This class contains environment executer jdbc operations
 * @since 2023
 *
 */
public class TxnSettlementExc {
	
	private static String traceId = Constants.EMPTY_STR;
	private static CommonLogger logger = new CommonLogger(TxnSettlementExc.class);
	
	@Value("${datasource.driver-class-name}")
    private static String dataDriver;
	
	@Value("${datasource.url}")
    private static String dataUrl;
	
	@Value("${datasource.username}")
    private static String dataUser;
	
	@Value("${datasource.password}")
    private static String dataPass;
	
	@Value("${jdbc.batch.size}")
    private static int batchSize;
	
	@Value("${jdbc.batch.interval.ms}")
    private static int batchInterval;
	
	@Value("${jdbc.with.max.retries}")
    private static int maxRetries;
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on txn_settlement table 
	 * @param transactionDTO, rawTrx
	 * @exception Exception 
	 */
	public static void add(TransactionDTO transactionDTO, Connection connection) throws TechnicalException {
	    logger.logInfo(traceId, "TxnSettlementExc: add: Started");
	    
	    PreparedStatement preparedStatement = null;
	    
	    try {
	        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
	        Date currentDate = new Date();
	        String formattedCurrentDate = dateFormat.format(currentDate);
	        ObjectMapper objectMapper = new ObjectMapper();
	        String txnData = objectMapper.writeValueAsString(transactionDTO.getData().getBody());
	        
	        String sql = "INSERT INTO txn_settlement_exc " +
	                     "(settlement_txn_key, process_date, business_date, pg_payment_id, merchant_track_id, discriminant, " +
	                     "txn_datetime, txn_amt, acquirer_institution_id, primary_account_no, merchant_id, store_id, " +
	                     "terminal_id, payment_code, txn_source_code, txn_type_code, response_code, sub_channel, " +
	                     "sub_channel_request_id, txn_data, tenant_code, dml_type, dml_by, dml_on, processing_code, issuer_institution_id, is_publish) " +
	                     "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	        
	        preparedStatement = connection.prepareStatement(sql);
	        preparedStatement.setString(1, transactionDTO.getSettlementTxnKey());
	        preparedStatement.setString(2, String.valueOf(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate()));
	        preparedStatement.setString(3, transactionDTO.getData().getBody().getTxnEnrData().getOriginalBusinessDate());
	        preparedStatement.setString(4, transactionDTO.getData().getBody().getAddnlFlds().getPgPmntId());
	        preparedStatement.setString(5, transactionDTO.getData().getBody().getAddnlFlds().getMerchTrackId());
	        preparedStatement.setString(6, transactionDTO.getData().getDiscrim());
	        preparedStatement.setString(7, transactionDTO.getData().getBody().getStdFlds().getLocalDateTime());
	        preparedStatement.setString(8, transactionDTO.getData().getBody().getStdFlds().getTxnAmt());
	        preparedStatement.setString(9, transactionDTO.getData().getBody().getStdFlds().getAcqInstIdCode());
	        preparedStatement.setString(10, transactionDTO.getData().getPan());
	        preparedStatement.setString(11, transactionDTO.getData().getBody().getDb().getMerchID());
	        preparedStatement.setString(12, transactionDTO.getData().getBody().getAddnlFlds().getStoreCode());
	        preparedStatement.setString(13, transactionDTO.getData().getBody().getStdFlds().getCrdAccptTermId());
	        preparedStatement.setString(14, transactionDTO.getData().getPaymentCode());
	        preparedStatement.setString(15, transactionDTO.getData().getBody().getAddnlFlds().getTxnSrc());
	        preparedStatement.setString(16, transactionDTO.getData().getBody().getTxnEnrData().getTrxTypeCode());
	        preparedStatement.setString(17, transactionDTO.getData().getBody().getStdFlds().getResponseCode());
	        preparedStatement.setString(18, transactionDTO.getData().getSubChannel());
	        preparedStatement.setString(19, transactionDTO.getData().getSubChannelRequestId());
	        preparedStatement.setString(20, txnData);
	        preparedStatement.setString(21, transactionDTO.getData().getBody().getDb().getTenantCode());
	        preparedStatement.setString(22, Constants.DML_TYPE);
	        preparedStatement.setString(23, Constants.DML_BY);
	        preparedStatement.setString(24, formattedCurrentDate);
	        preparedStatement.setString(25, transactionDTO.getData().getBody().getStdFlds().getProcCode());
	        preparedStatement.setString(26, transactionDTO.getData().getBody().getStdFlds().getForwdInstIdCode());
	        preparedStatement.setString(27, Constants.PUBLISH_FLAG_N);
	        
	        int rowsInserted = preparedStatement.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            logger.logInfo(traceId, "Data inserted successfully.");
	        } else {
	            logger.logError(traceId, "Failed to insert data into txn_settlement_exc.");
	        }
	    } catch (SQLException | JsonProcessingException e) {
	        logger.logError(traceId, "Error while persisting data at TxnSettlementExc: " + e.getLocalizedMessage());
	       
	    	TxnExceptionlogger
			.techErrTransactions("TxnSettlementExc: add: TxnsettlementTxnKey"
					+ Constants.ERROR_MSG_SEPERATER + transactionDTO.getSettlementTxnKey()
					+ Constants.ERROR_MSG_SEPERATER
					+"Error while persisting data at TxnSettlementExc: " + e.getLocalizedMessage());
	    	
	        
	    } finally {
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                logger.logError(traceId, "TxnSettlementExc: add:Error closing PreparedStatement: " + e.getLocalizedMessage());
	            }
	        }
	    }
	}
	
	
	/**
	 * 
	 * This class contains environment executer jdbc operations on TxnSettlementExc table 
	 * @param settlementTxnKey
	 * @exception SQLException 
	 * @throws TechnicalException 
	 */
    public static TxnSettlementExcDto getTxnSettlementExc(String settlementTxnKey, String rawTrx, Connection connection) throws SQLException, TechnicalException {
    	logger.logInfo(traceId, "TxnSettlementExc: getTxnSettlementExc:Started");
    	
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establish a JDBC connection.

            // Create a SQL query with placeholders for the dynamic parameters.
            String sqlQuery = "SELECT txn_settlement_exc_id FROM txn_settlement_exc WHERE settlement_txn_key = ? ";

            // Prepare the statement with the query and set the parameters.
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, settlementTxnKey);

            // Execute the query.
            resultSet = preparedStatement.executeQuery();

            // Check if a record is found.
            if (resultSet.next()) {
                // Populate a TxnUniqueDataDTO object with the retrieved data.
            	TxnSettlementExcDto txnSettlementExcDto = new TxnSettlementExcDto();
                txnSettlementExcDto.setTxnSettlementExcId(resultSet.getLong("txn_settlement_exc_id"));
                return txnSettlementExcDto;
            } else {
                return null;
            }
        } catch(Exception e) {
			logger.logError(traceId, "TxnSettlementExc: getTxnSettlementExc: Error while persisting data at fetchTxnSettlementExc: " + e.getLocalizedMessage());
	       
	    	TxnExceptionlogger
			.techErrTransactions("TxnSettlementExc: getTxnSettlementExc: TxnsettlementTxnKey"
					+ Constants.ERROR_MSG_SEPERATER + settlementTxnKey
					+ Constants.ERROR_MSG_SEPERATER
					+ "Error while persisting data at fetchTxnSettlementExc: " + e.getLocalizedMessage());
	    	return null;
		}
    }
	
    
    /**
	 * 
	 * This method contains the logic to update txn_settlement_exc table 
	 * @param settlementTxnKey
	 * @exception SQLException 
	 * @throws TechnicalException 
	 */
	
    public static void updateTransactionSettlementExc(String settlementTxnKey, String newProcessDate, String newPublishFlag, Connection connection, TransactionDTO transactionDTO) throws TechnicalException {
        logger.logInfo(traceId, "TxnSettlementExc: updateTransactionStatus: Started");

        PreparedStatement preparedStatement = null;

        try {
            String sql = "UPDATE txn_settlement_exc SET process_date = ?, is_publish = ? WHERE settlement_txn_key = ?";

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, newProcessDate);
            preparedStatement.setString(2, newPublishFlag); // "N"
            preparedStatement.setString(3, settlementTxnKey);

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                logger.logInfo(traceId, "Data updated successfully.");
            } else {
                logger.logError(traceId, "Failed to update data in txn_settlement_exc.");
            }
        } catch (SQLException e) {
            logger.logError(traceId, "TxnSettlementExc:updateTransactionSettlementExc: Error while updating data at updateTransactionStatus: " + e.getLocalizedMessage());

	    	TxnExceptionlogger
			.techErrTransactions("TxnSettlementExc: updateTransactionSettlementExc: TxnsettlementTxnKey"
					+ Constants.ERROR_MSG_SEPERATER + settlementTxnKey
					+ Constants.ERROR_MSG_SEPERATER
					+"Error while persisting data at TxnSettlementExc: " + e.getLocalizedMessage());
            
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.logError(traceId, "Error closing PreparedStatement: " + e.getLocalizedMessage());
                }
            }
        }
    }
	
  
    
    // exception related implementaton
    
    
    /**
	 * 
	 * Custom constructor which invokes the method to persist or update the
	 * txn_merchant_status info by accepting the traceId, transactionDTO and
	 * connection as input parameters
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 */
	public TxnSettlementExc(String traceId, TransactionDTO transactionDTO, Connection connection)
			throws TechnicalException {
		this.persistOrUpdateTxnSettlementExcInfo(traceId, transactionDTO, connection);
	}

	/**
	 * 
	 * This method provides the implementation to persist or update data into
	 * txn_merchant_status table by accepting traceId, transactionDTO and connection
	 * as input parameters.
	 * 
	 * @param traceId
	 * @param transactionDTO
	 * @param connection
	 * @throws TechnicalException
	 * 
	 */
	public void persistOrUpdateTxnSettlementExcInfo(String traceId, TransactionDTO transactionDTO,
			Connection connection) throws TechnicalException {
		logger.logInfo(traceId, "TxnSettlementExc : persistOrUpdateTxnSettlementExcInfo() - Started.");
		try {
			TxnSettlementExcDto txnSettlementExcDto = TxnSettlementExc.getTxnSettlementExc(transactionDTO.getSettlementTxnKey(), transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(), connection);
	    	
	    	if(txnSettlementExcDto != null && txnSettlementExcDto.getTxnSettlementExcId() != 0) {
	    		transactionDTO.getData().getBody().getTxnEnrData().setTxnSettlementExcId( Long.toString(txnSettlementExcDto.getTxnSettlementExcId()));
	    		logger.logInfo(traceId, "TxnSettlementExc: persistOrUpdateTxnSettlementExcInfo:Started");
	        	TxnSettlementExc.updateTransactionSettlementExc(transactionDTO.getSettlementTxnKey(),String.valueOf(transactionDTO.getData().getBody().getTxnEnrData().getCurrentBusinessdate()),Constants.PUBLISH_FLAG_N, connection, transactionDTO);
	        	
	    	}else {
	    		
	    		TxnSettlementExc.add(transactionDTO, connection); 
	    		txnSettlementExcDto = TxnSettlementExc.getTxnSettlementExc(transactionDTO.getSettlementTxnKey(), transactionDTO.getData().getBody().getTxnEnrData().getRawTransaction(), connection);
	        	transactionDTO.getData().getBody().getTxnEnrData().setTxnSettlementExcId( Long.toString(txnSettlementExcDto.getTxnSettlementExcId()));
	    	}
			logger.logInfo(traceId, "TxnSettlementExc : persistOrUpdateTxnSettlementExcInfo() - Returned.");
		} catch (Exception e) {
			logger.logError(traceId, "TxnSettlementExc: persistOrUpdateTxnSettlementExcInfo: Error while persist/update the txn_settlement_exc info : " + e.getMessage());
			
			TxnExceptionlogger
			.techErrTransactions("TxnSettlementExc: persistOrUpdateTxnSettlementExcInfo: TxnsettlementTxnKey"
					+ Constants.ERROR_MSG_SEPERATER + transactionDTO.getSettlementTxnKey()
					+ Constants.ERROR_MSG_SEPERATER
					+"Error while persisting data at TxnSettlementExc: " + e.getLocalizedMessage());
		} 
	}
    
    

}
