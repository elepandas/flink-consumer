package com.fss.presettlement.util;


import com.fss.logger.CommonLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

@Component
public class CardHashing {
    // Setting Hashkey for hashing implementation
    private static String HASH_KEY = "SHA-256";


    @Value("${aes.secret.key}")
    private String SECRET_KEY;

    @Value("${aes.secret.salt}")
    private String SALTVALUE;

    CommonLogger logger = new CommonLogger(CardHashing.class);



    public String getDecrypt(String encryptString) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        /* Declare a byte array. */
        byte[] iv = new byte[16];
        IvParameterSpec ivspec = new IvParameterSpec(iv);
        /* Create factory for secret keys. */
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        /* PBEKeySpec class implements KeySpec interface. */
        KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALTVALUE.getBytes(), 65536, 256);
        SecretKey tmp = factory.generateSecret(spec);
        SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
        /* Retruns decrypted value. */
        return new String(cipher.doFinal(Base64.getDecoder().decode(encryptString)));
    }


    // Hashing method for hashing the string

    public static synchronized String getHashValue(String plainText) {
        String algorithm = HASH_KEY;
        byte[] shaInBytes = digest(plainText.getBytes(StandardCharsets.UTF_8), algorithm);
        return bytesToHex(shaInBytes);
    }

    public static byte[] digest(byte[] input, String algorithm) {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
        byte[] result = md.digest(input);
        return result;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}


