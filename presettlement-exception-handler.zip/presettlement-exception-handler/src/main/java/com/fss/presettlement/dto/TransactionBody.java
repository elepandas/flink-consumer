package com.fss.presettlement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of Transaction Body fields
 * @since 2023
 *
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionBody {
	
	private StdFlds stdFlds;
	private DB db;
	private AddnlFlds addnlFlds;
}
