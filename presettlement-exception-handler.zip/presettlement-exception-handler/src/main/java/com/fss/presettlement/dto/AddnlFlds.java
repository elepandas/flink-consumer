package com.fss.presettlement.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a DTO class which holds the property details of additional fields
 * @since 2023
 *
 */
@Getter
@Setter
public class AddnlFlds{
    private String urn;
    private String channel;
    private String txnSrc;
    private String invoiceNum;
    private String batchNum;
    private String dccCrncy;
    private String dccAmt;
    private String dccConvRate;
    private String dccConvMarkUpRate;
    private String pgPmntId;
    private String merchTrackId;
    private String pgTxnID;
    private String pmntMthdIden;
    private String pmntMthdAggrIden;
    private String pmntMthdAggrTranID;
    private String authEntity;
    private String authSrc;
    private String authCode;
    private String tranID;
    private String rqstRcvdTime;
    private String rqstSentTime;
    private String respRcvdTime;
    private String respSentTime;
    private String brandID;
    private String langID;
    private String merchSuccResURL;
    private String merchFailResURL;
    private String merchPmntInitTim;
    private String merchPmntRespTim;
    private String crdHldrName;
    private String emiFlag;
    private String cardCountryCode;
    private String payerName;
    private String payerVPA;
    private String npciTransId;
    private String pspRefNo;
    private String refundType;
    private Double balanceAmount;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private String udf9;
    private String udf10;
    private String udf11;
    private String udf12;
    private String udf13;
    private String udf14;
    private String udf15;
    private String udf16;
    private String udf17;
    private String udf18;
    private String udf19;
    private String udf20;
    private String udf21;
    private String udf22;
    private String udf23;
    private String udf24;
    private String udf25;
    private String svcFee;
    private String fixedFeeCrncy;
    private String fixedFeeConvRateValue;
    private String fixedFeeAmt;
    private String svcFeeAmt;
    private String svcFeeTaxType;
    private String svcFeeTaxAmt;
    private String ttlFeeAmt;
    private String storeCode;
    private String ucafInd;
    private String eci;
    private String actionCode;
    private String sli;
    private String mskCardNum;
    private String ip;
}
